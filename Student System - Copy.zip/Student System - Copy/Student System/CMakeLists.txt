cmake_minimum_required(VERSION 3.16)
project(attendx_server CXX C)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

# Compiler optimization and warnings
if(MSVC)
    add_compile_options(/W4 /EHsc /DNOMINMAX /D_CRT_SECURE_NO_WARNINGS)
else()
    add_compile_options(-Wall -Wextra -Wno-unused-parameter -pthread -O2)
endif()

# Include directories
include_directories(
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party
    ${CMAKE_CURRENT_SOURCE_DIR}/backend
)

# Backend source files
set(SOURCES
    backend/main.cpp
    backend/database/Database.cpp
    backend/utils/Sha256.cpp
    backend/utils/Validation.cpp
    backend/utils/ResponseUtils.cpp
    backend/utils/AuthUtils.cpp
    backend/repositories/UserRepository.cpp
    backend/repositories/ClassRepository.cpp
    backend/repositories/StudentRepository.cpp
    backend/repositories/SubjectRepository.cpp
    backend/repositories/AttendanceRepository.cpp
    backend/services/AuthService.cpp
    backend/services/ClassService.cpp
    backend/services/StudentService.cpp
    backend/services/SubjectService.cpp
    backend/services/AttendanceService.cpp
    backend/services/ReportService.cpp
    backend/services/SeedService.cpp
    backend/routes/AuthRoutes.cpp
    backend/routes/StudentRoutes.cpp
    backend/routes/ClassRoutes.cpp
    backend/routes/SubjectRoutes.cpp
    backend/routes/AttendanceRoutes.cpp
    backend/routes/ReportRoutes.cpp
    backend/routes/DashboardRoutes.cpp
    backend/routes/SeedRoutes.cpp
    third_party/sqlite3.c
)

# Define executable
add_executable(attendx_server ${SOURCES})

# Link libraries
if(WIN32)
    target_link_libraries(attendx_server PRIVATE
        ws2_32
        bcrypt
    )
else()
    target_link_libraries(attendx_server PRIVATE
        pthread
    )
    if(APPLE)
        target_link_libraries(attendx_server PRIVATE "-framework CoreFoundation")
    endif()
endif()
