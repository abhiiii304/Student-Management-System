# ATTENDX — Smart Student Attendance Management System

[![C++17](https://img.shields.io/badge/C%2B%2B-17%20Standard-blue.svg)](https://isocpp.org/)
[![Database](https://img.shields.io/badge/Database-SQLite3-003B57.svg)](https://sqlite.org/)
[![Build](https://img.shields.io/badge/Build-CMake%20%7C%20Make-brightgreen.svg)](https://cmake.org/)
[![Architecture](https://img.shields.io/badge/Architecture-Modular%20Layered%20REST-purple.svg)]()
[![Platform](https://img.shields.io/badge/Platform-macOS%20%7C%20Linux-lightgrey.svg)]()

> **ATTENDX** is an enterprise-grade academic intelligence and attendance management platform built with a high-performance **Modern C++17** backend, connected **SQLite** relational database, and a **Linear / Stripe / Vercel** inspired dark modern web interface.

---

## 1. Project Overview

ATTENDX is designed for academic institutions, universities, and colleges to replace outdated manual or spreadsheet attendance workflows with an automated, auditable, and analytics-driven platform.

The system provides 5 primary functional dashboards:
1. **Executive Dashboard**: Real-time KPI metrics, attendance trend charts, status distribution doughnut charts, recent activity streams, and critical low-attendance alerts (< 75%).
2. **Student Management**: Full CRUD lifecycle (enrollment, roll number, semester, section, branch, contact info) with search, filters, pagination, and soft deletion to protect attendance audit history.
3. **Attendance Management**: Class, subject, and date roster marking with live summary calculations, batch marking (*Mark All Present / Absent*), inline search, and duplicate prevention upserts.
4. **Classes & Subjects**: Tabbed management for academic cohorts and curriculum subjects, with faculty assignment and cohort enrollment tracking.
5. **Reports & Analytics**: Student-wise, class-wise, subject-wise, daily, and monthly audit reports with one-click **CSV export** and **print-ready styling**.

---

## 2. Technology Stack & Architecture

```
+---------------------------------------------------------------------+
|                     FRONTEND (HTML5 / CSS3 / JS)                    |
|  - Linear / Stripe Dark SaaS Theme (#0B1020, #151D30, #4F8CFF)      |
|  - Responsive Collapsible Sidebar & Mobile Navigation Drawer        |
|  - Chart.js (Trends Bar & Distribution Doughnut)                    |
|  - Native Fetch API Client with Bearer Token & Toast Notifications   |
+---------------------------------------------------------------------+
                               |
                        HTTP REST API
                               |
+---------------------------------------------------------------------+
|                      C++17 BACKEND ENGINE                           |
|  - Modern C++ HTTP/REST Server (cpp-httplib & Crow design pattern)   |
|  - High Performance In-Memory Session & Token Management            |
|  - CommonCrypto / SHA-256 Salted Password Hashing                   |
|  - JSON Serialization via nlohmann/json                             |
|  - Modular Layered Architecture:                                    |
|      Routes -> Services -> Repositories -> Database Layer           |
+---------------------------------------------------------------------+
                               |
                    SQL Prepared Statements
                               |
+---------------------------------------------------------------------+
|                    SQLITE RELATIONAL DATABASE                       |
|  - attendx.db with PRAGMA foreign_keys = ON & WAL mode              |
|  - Normalized Tables: users, classes, students, subjects, attendance|
|  - Unique Constraints & B-Tree Indexes on Lookups & Dates           |
+---------------------------------------------------------------------+
```

### Backend:
- **Language**: C++17 (`clang++` / `g++`)
- **Web Layer**: Modern C++ HTTP REST framework with route pattern matching and static asset serving
- **Database Engine**: SQLite3 C API with prepared statements (`sqlite3_prepare_v2`, `sqlite3_bind_*`)
- **JSON Engine**: `nlohmann/json` (modern C++ JSON library)
- **Security**: SHA-256 password hashing with cryptographic salt generation, session tokens, and input validation regexes

### Frontend:
- **HTML5 & Modern CSS3**: Custom dark SaaS design system (no bloated UI frameworks)
- **JavaScript (ES6+)**: Centralized `api.js` client with automatic auth headers, debounced search, modal managers, and toast notifications
- **Analytics**: Chart.js 4.4.x integration for attendance trends and status distributions

---

## 3. Database Schema (`database/attendx.db`)

The SQLite database is initialized automatically with foreign keys enabled and performance indexes:

### `users`
| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique user identifier |
| `username` | TEXT | UNIQUE NOT NULL | Login username (`admin`) |
| `password_hash`| TEXT | NOT NULL | SHA-256 hashed password |
| `salt` | TEXT | NOT NULL | Random cryptographic salt |
| `role` | TEXT | NOT NULL DEFAULT 'admin' | User permission role |
| `created_at` | TEXT | NOT NULL | ISO UTC Timestamp |

### `classes`
| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Class ID |
| `branch` | TEXT | NOT NULL | Academic branch (e.g. CSE, IT, ECE) |
| `semester` | INTEGER | NOT NULL | Semester (1 - 8) |
| `section` | TEXT | NOT NULL | Section (e.g. A, B) |
| `academic_year`| TEXT | | Academic term (e.g. 2026-2027) |
| `created_at` | TEXT | NOT NULL | Timestamp |
| `updated_at` | TEXT | NOT NULL | Timestamp |

### `students`
| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Student ID |
| `enrollment_id`| TEXT | UNIQUE NOT NULL | Unique institutional enrollment ID |
| `name` | TEXT | NOT NULL | Full student name |
| `roll_number` | TEXT | UNIQUE | Academic roll number |
| `branch` | TEXT | NOT NULL | Branch code |
| `section` | TEXT | NOT NULL | Section code |
| `semester` | INTEGER | NOT NULL | Semester number |
| `email` | TEXT | | Email address |
| `phone` | TEXT | | Contact phone number |
| `created_at` | TEXT | NOT NULL | Timestamp |
| `updated_at` | TEXT | NOT NULL | Timestamp |
| `deleted_at` | TEXT | NULL | Soft deletion timestamp (preserves history) |

### `subjects`
| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Subject ID |
| `subject_name`| TEXT | NOT NULL | Course title |
| `subject_code`| TEXT | UNIQUE NOT NULL | Course code (e.g. CS601) |
| `branch` | TEXT | | Target branch |
| `semester` | INTEGER | NOT NULL | Target semester |
| `section` | TEXT | | Target section |
| `faculty_name`| TEXT | | Faculty in-charge |
| `class_id` | INTEGER | REFERENCES classes(id) | Associated cohort |
| `created_at` | TEXT | NOT NULL | Timestamp |
| `updated_at` | TEXT | NOT NULL | Timestamp |

### `attendance`
| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Record ID |
| `student_id` | INTEGER | REFERENCES students(id) | Foreign key to student |
| `subject_id` | INTEGER | REFERENCES subjects(id) | Foreign key to subject |
| `class_id` | INTEGER | REFERENCES classes(id) | Foreign key to class |
| `attendance_date` | TEXT | NOT NULL | Date string (YYYY-MM-DD) |
| `status` | TEXT | NOT NULL | `Present`, `Absent`, or `Late` |
| `created_at` | TEXT | NOT NULL | Timestamp |
| `updated_at` | TEXT | NOT NULL | Timestamp |
| *Constraint* | UNIQUE(student_id, subject_id, attendance_date) | Prevents duplicate logs |

---

## 4. REST API Reference

All responses follow a uniform JSON structure:
```json
{
  "success": true,
  "message": "Operation completed successfully",
  "data": { ... }
}
```

### Authentication
- `POST /api/auth/login` — Sign in with credentials (returns token & sets cookie)
- `POST /api/auth/logout` — Invalidate session token
- `GET /api/auth/me` — Retrieve active authenticated session

### Students
- `GET /api/students` — List students with filters (`search`, `branch`, `section`, `semester`, `limit`, `page`)
- `GET /api/students/:id` — Retrieve student details and attendance breakdown
- `POST /api/students` — Create new student profile
- `PUT /api/students/:id` — Update student details
- `DELETE /api/students/:id` — Soft-delete student (preserves attendance history)
- `POST /api/students/:id/restore` — Restore soft-deleted student

### Classes & Subjects
- `GET /api/classes` — List all academic cohorts
- `POST /api/classes` — Create a new class cohort
- `PUT /api/classes/:id` — Update class details
- `DELETE /api/classes/:id` — Delete class
- `GET /api/subjects` — List curriculum subjects with faculty and statistics
- `POST /api/subjects` — Create a new subject
- `PUT /api/subjects/:id` — Update subject
- `DELETE /api/subjects/:id` — Delete subject

### Attendance Operations
- `GET /api/attendance` — Query records (`date`, `subject_id`, `class_id`, `student_id`)
- `POST /api/attendance` — Record single attendance entry (auto-upserts on duplicate date)
- `POST /api/attendance/bulk` — Record or update roster attendance for an entire class
- `GET /api/attendance/summary` — Get live attendance breakdown (total, present, absent, late, %)
- `GET /api/attendance/student/:student_id` — Fetch history for specific student

### Reports & Analytics
- `GET /api/reports/student` — Student-wise attendance percentage report
- `GET /api/reports/class` — Class-wise cohort percentage report
- `GET /api/reports/subject` — Subject-wise course attendance report
- `GET /api/reports/daily` — Daily attendance transaction log
- `GET /api/reports/monthly` — Monthly attendance aggregate
- `GET /api/reports/low-attendance` — Students below 75% attendance threshold
- `GET /api/reports/export` — Stream filtered report data directly as downloadable **CSV**

### Dashboard
- `GET /api/dashboard/stats` — Real-time database metrics (students, today present/absent, rate, classes, subjects)
- `GET /api/dashboard/attendance-trends` — Daily or monthly attendance trend series
- `GET /api/dashboard/attendance-distribution` — Present vs Absent vs Late count distribution
- `GET /api/dashboard/recent-activity` — Recent attendance records stream

### Demo Seed
- `POST /api/seed` — Seed demo dataset (students, classes, subjects, faculty, attendance history)

---

## 5. Getting Started & Installation

### Prerequisites
- **macOS** (Apple Silicon or Intel) or **Linux**
- **Apple Clang / GCC** with C++17 support
- **CMake** (v3.16+) or **Make**
- **SQLite3** (pre-installed on macOS; `brew install sqlite` or `sudo apt install libsqlite3-dev`)

### Quick Build & Run (One-Liner)

Simply execute the runner script from the project directory:

```bash
chmod +x run.sh
./run.sh --seed
```

This compiles the C++ backend using `clang++` and starts the server on port `8080`, pre-seeding it with 24 demo students, 4 classes, 6 subjects, and multi-day attendance history.

### Alternative 1: Build with CMake

```bash
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
./build/attendx_server --seed
```

### Alternative 2: Build with Make

```bash
make -j4
./attendx_server --seed
```

Open your browser and navigate to:
**[http://localhost:8080](http://localhost:8080)**

---

## 6. Demonstration Credentials

The database automatically initializes the administrator account on first boot:

| Field | Value |
|---|---|
| **Username** | `admin` |
| **Password** | `Admin@123` |
| **Role** | Administrator |

*Note: On the login page, you can click the **Auto-Fill** button to instantly populate these demonstration credentials.*

### Changing Administrator Password
You can change your password at runtime via `POST /api/auth/change-password` or by passing environment variables:
```bash
ADMIN_USER="superadmin" ADMIN_PASS="SecurePass@2026" ./attendx_server
```

---

## 7. Running the Automated Test Suite

A comprehensive end-to-end integration test suite is included in `tests/integration_test.sh`:

```bash
chmod +x tests/integration_test.sh
./tests/integration_test.sh
```

**Verification Results:**
```
==========================================================
  ATTENDX — Complete Automated Integration Test Suite    
==========================================================
--- 1. Testing Static HTML & Asset Delivery ---
  [PASS] GET / serves index.html (200)
  [PASS] GET /students serves students.html (200)
  [PASS] GET /attendance serves attendance.html (200)
  [PASS] GET /classes serves classes.html (200)
  [PASS] GET /reports serves reports.html (200)
  [PASS] GET /login serves login.html (200)
  [PASS] GET /assets/css/styles.css delivered (200)

--- 2. Testing Authentication & Session Security ---
  [PASS] Login with invalid password rejected (401)
  [PASS] Login with demo credentials succeeds
  [PASS] Auth token extracted
  [PASS] Auth check /api/auth/me returns admin profile

--- 3. Testing Dashboard Analytics ---
  [PASS] Dashboard stats returns total_students >= 20
  [PASS] Dashboard stats returns active classes
  [PASS] Dashboard stats returns active subjects
  [PASS] Attendance trends endpoint returns series data
  [PASS] Attendance distribution returns present and absent counts
  [PASS] Recent activity returns latest entries

--- 4. Testing Student Management CRUD ---
  [PASS] Student created successfully (201)
  [PASS] Created Student ID obtained
  [PASS] Read student details by ID
  [PASS] Update student details
  [PASS] Search student by name
  [PASS] Duplicate enrollment ID prevented
  [PASS] Soft delete student succeeds
  [PASS] Deleted student excluded from active search
  [PASS] Restore soft-deleted student

--- 5. Testing Classes and Subjects Management ---
  [PASS] Create new academic class cohort
  [PASS] Create curriculum subject with class assignment

--- 6. Testing Attendance Operations & Duplicate Prevention ---
  [PASS] Record individual student attendance
  [PASS] Duplicate attendance upserts status gracefully
  [PASS] Bulk attendance processing

--- 7. Testing Reports, Analytics & CSV Export ---
  [PASS] Student-wise attendance calculation report
  [PASS] Low attendance threshold filter identifies students < 75%
  [PASS] CSV export contains valid CSV headers and rows

==========================================================
  TEST SUMMARY: 34 passed, 0 failed (100% SUCCESS)
==========================================================
```

---

## 8. Attendance Business Rules

1. **Student Grouping**: Each student belongs to a specific academic branch, semester (1–8), and section (e.g. CSE Sem 6 Sec A).
2. **Subject Association**: Attendance is strictly linked to a `(student_id, subject_id, attendance_date)` tuple.
3. **Valid Statuses**: `Present`, `Absent`, or `Late`.
4. **Duplicate Prevention**: SQLite unique constraint `UNIQUE(student_id, subject_id, attendance_date)`. Saving attendance for an existing date automatically updates the existing record rather than duplicating rows.
5. **Percentage Calculation**:
   $$\text{Attendance Percentage} = \left(\frac{\text{Present Classes}}{\text{Total Recorded Classes}}\right) \times 100$$
6. **Low Attendance Highlighting**: Any student whose attendance falls below **75.0%** is visually highlighted with a red warning badge on the dashboard and reports, enabling timely academic counseling.
7. **Safe Soft-Deletion**: Deleting a student marks `deleted_at = timestamp`. Their past attendance records and audit metrics remain preserved in reports.

---

## 9. Project Directory Structure

```
Student System/
├── CMakeLists.txt              # CMake build configuration
├── Makefile                    # Direct build and execution makefile
├── run.sh                      # Shell launch script with dependency detection
├── README.md                   # Complete architectural documentation
├── tests/
│   └── integration_test.sh     # Automated 34-test end-to-end test suite
├── database/
│   └── attendx.db              # SQLite relational database (auto-created)
├── third_party/
│   ├── httplib.h               # Modern C++ HTTP/REST server library
│   └── json.hpp                # nlohmann/json C++ JSON parser
├── backend/
│   ├── main.cpp                # Server entry point & static file routing
│   ├── config/
│   │   └── config.h            # Host, port, db path, and credential config
│   ├── database/
│   │   ├── Database.h          # SQLite singleton wrapper
│   │   └── Database.cpp        # Auto-migration & pragmas configuration
│   ├── models/
│   │   ├── User.h              # Admin user model
│   │   ├── Student.h           # Student model & JSON serializer
│   │   ├── Class.h             # Academic cohort model
│   │   ├── Subject.h           # Curriculum subject model
│   │   └── Attendance.h        # Attendance entry model
│   ├── repositories/
│   │   ├── UserRepository.cpp
│   │   ├── ClassRepository.cpp
│   │   ├── StudentRepository.cpp
│   │   ├── SubjectRepository.cpp
│   │   └── AttendanceRepository.cpp # SQL queries, aggregations & trends
│   ├── services/
│   │   ├── AuthService.cpp     # Login authentication & session tokens
│   │   ├── StudentService.cpp  # Student business validation & CRUD
│   │   ├── ClassService.cpp    # Class cohort management
│   │   ├── SubjectService.cpp  # Subject & faculty management
│   │   ├── AttendanceService.cpp # Attendance marking & summary
│   │   ├── ReportService.cpp   # Report formatting & CSV streaming
│   │   └── SeedService.cpp     # Demo data population service
│   ├── routes/
│   │   ├── AuthRoutes.cpp      # /api/auth endpoints
│   │   ├── StudentRoutes.cpp   # /api/students endpoints
│   │   ├── ClassRoutes.cpp     # /api/classes endpoints
│   │   ├── SubjectRoutes.cpp   # /api/subjects endpoints
│   │   ├── AttendanceRoutes.cpp# /api/attendance endpoints
│   │   ├── ReportRoutes.cpp    # /api/reports endpoints
│   │   ├── DashboardRoutes.cpp # /api/dashboard endpoints
│   │   └── SeedRoutes.cpp      # /api/seed endpoint
│   └── utils/
│       ├── Sha256.cpp          # Password hashing & token generation
│       ├── Validation.cpp      # Input validation routines
│       ├── ResponseUtils.cpp   # Standard JSON HTTP responses
│       └── AuthUtils.cpp       # Bearer token & session validation
└── frontend/
    ├── index.html              # 1. Executive Dashboard Page
    ├── students.html           # 2. Student Management Page
    ├── attendance.html         # 3. Attendance Management Page
    ├── classes.html            # 4. Classes & Subjects Page
    ├── reports.html            # 5. Reports & Analytics Page
    ├── login.html              # Administrator Login Page
    └── assets/
        ├── css/
        │   └── styles.css      # Dark SaaS Design System (Linear/Stripe)
        └── js/
            ├── api.js          # Centralized Fetch API client & toasts
            ├── app.js          # Sidebar toggle, date, auth check
            ├── dashboard.js    # Dashboard stats & Chart.js charts
            ├── students.js     # Student CRUD, modals, pagination
            ├── attendance.js   # Roster loader, batch marking & save
            ├── classes.js      # Cohort & subject tabbed management
            ├── reports.js      # Report filters, CSV export, print
            └── login.js        # Authentication form controller
```

---

## 10. Troubleshooting

- **Port Conflict (`Address already in use`)**:
  Specify a custom port using either the CLI flag or environment variable:
  ```bash
  ./attendx_server --port 9090
  # or
  PORT=9090 ./run.sh
  ```
- **Resetting Database**:
  To start with a fresh clean database:
  ```bash
  rm -f database/attendx.db
  ./run.sh --seed
  ```
- **Database Permissions**:
  Ensure the `database/` directory is writable by your user account.

---

## 11. Academic Mini-Project Defense & Viva-Voce Highlights

When presenting ATTENDX for college evaluations, practical examinations, or portfolio reviews:
1. **True C++17 Backend**: Emphasize that the backend is genuinely written in modern C++ with strong typing, RAII, prepared SQL statements, and thread-safe singleton database management.
2. **ACID Compliance**: SQLite transactions guarantee that bulk attendance submissions either succeed completely or roll back cleanly without partial writes.
3. **No Mock Data**: All metrics, trend lines, percentages, and lists are calculated live from real SQL queries.
4. **Audit Protection**: Soft deletion ensures that withdrawing a student never corrupts past semester attendance records.
5. **Zero External Runtime Dependencies**: Standard POSIX sockets, native SQLite C API, and clean vanilla JavaScript ensure the system runs on any modern machine without heavy node/python runtime overhead.

