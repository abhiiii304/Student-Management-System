#pragma once
#include <string>
#include <cstdlib>

namespace attendx {
namespace config {

inline std::string getEnvOrDefault(const char* var, const std::string& defaultVal) {
    const char* val = std::getenv(var);
    return val ? std::string(val) : defaultVal;
}

inline int getPort() {
    std::string p = getEnvOrDefault("PORT", "8080");
    return std::atoi(p.c_str());
}

inline std::string getHost() {
    return getEnvOrDefault("HOST", "0.0.0.0");
}

inline std::string getDatabasePath() {
    return getEnvOrDefault("DB_PATH", "database/attendx.db");
}

inline std::string getStaticDir() {
    return getEnvOrDefault("STATIC_DIR", "frontend");
}

inline std::string getDefaultAdminUsername() {
    return getEnvOrDefault("ADMIN_USER", "admin");
}

inline std::string getDefaultAdminPassword() {
    return getEnvOrDefault("ADMIN_PASS", "Admin@123");
}

} // namespace config
} // namespace attendx

