#include "Database.h"
#include "../config/config.h"
#include "../utils/Sha256.h"
#include <iostream>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <sstream>

namespace attendx {
namespace database {

Database& Database::getInstance() {
    static Database instance;
    return instance;
}

Database::Database() : db_(nullptr) {}

Database::~Database() {
    close();
}

void Database::close() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (db_) {
        sqlite3_close(db_);
        db_ = nullptr;
    }
}

sqlite3* Database::getHandle() {
    return db_;
}

std::mutex& Database::getMutex() {
    return mutex_;
}

std::string Database::getCurrentTimestamp() {
    auto now = std::chrono::system_clock::now();
    auto in_time_t = std::chrono::system_clock::to_time_t(now);
    std::stringstream ss;
    ss << std::put_time(std::gmtime(&in_time_t), "%Y-%m-%d %H:%M:%S");
    return ss.str();
}

bool Database::initialize(const std::string& dbPath) {
    std::lock_guard<std::mutex> lock(mutex_);
    dbPath_ = dbPath;

    int rc = sqlite3_open(dbPath_.c_str(), &db_);
    if (rc != SQLITE_OK) {
        std::cerr << "[Database] Failed to open database " << dbPath_ << ": " 
                  << (db_ ? sqlite3_errmsg(db_) : "unknown error") << std::endl;
        return false;
    }

    // Enable foreign keys and WAL mode for better concurrency
    char* errMsg = nullptr;
    rc = sqlite3_exec(db_, "PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL;", nullptr, nullptr, &errMsg);
    if (rc != SQLITE_OK) {
        std::cerr << "[Database] Failed to configure pragmas: " << (errMsg ? errMsg : "") << std::endl;
        if (errMsg) sqlite3_free(errMsg);
    }

    if (!createTables()) return false;
    if (!createIndexes()) return false;
    if (!seedDefaultAdmin()) return false;

    std::cout << "[Database] SQLite initialized successfully at: " << dbPath_ << std::endl;
    return true;
}

bool Database::execute(const std::string& sql) {
    char* errMsg = nullptr;
    int rc = sqlite3_exec(db_, sql.c_str(), nullptr, nullptr, &errMsg);
    if (rc != SQLITE_OK) {
        std::cerr << "[Database] SQL execute error: " << (errMsg ? errMsg : "") 
                  << " in SQL: " << sql << std::endl;
        if (errMsg) sqlite3_free(errMsg);
        return false;
    }
    return true;
}

int64_t Database::lastInsertId() {
    return sqlite3_last_insert_rowid(db_);
}

bool Database::beginTransaction() {
    return execute("BEGIN TRANSACTION;");
}

bool Database::commit() {
    return execute("COMMIT;");
}

bool Database::rollback() {
    return execute("ROLLBACK;");
}

bool Database::createTables() {
    const std::string sql = R"(
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            salt TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'admin',
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS classes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            branch TEXT NOT NULL,
            semester INTEGER NOT NULL,
            section TEXT NOT NULL,
            academic_year TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            enrollment_id TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            roll_number TEXT UNIQUE,
            branch TEXT NOT NULL,
            section TEXT NOT NULL,
            semester INTEGER NOT NULL,
            email TEXT,
            phone TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            deleted_at TEXT NULL
        );

        CREATE TABLE IF NOT EXISTS subjects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject_name TEXT NOT NULL,
            subject_code TEXT UNIQUE,
            branch TEXT,
            semester INTEGER NOT NULL,
            section TEXT,
            faculty_name TEXT,
            class_id INTEGER,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            subject_id INTEGER NOT NULL,
            class_id INTEGER,
            attendance_date TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
            FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE SET NULL,
            UNIQUE(student_id, subject_id, attendance_date)
        );
    )";

    return execute(sql);
}

bool Database::createIndexes() {
    const std::string sql = R"(
        CREATE INDEX IF NOT EXISTS idx_students_enrollment ON students(enrollment_id);
        CREATE INDEX IF NOT EXISTS idx_students_roll ON students(roll_number);
        CREATE INDEX IF NOT EXISTS idx_students_deleted ON students(deleted_at);
        CREATE INDEX IF NOT EXISTS idx_students_grouping ON students(semester, branch, section);
        CREATE INDEX IF NOT EXISTS idx_classes_lookup ON classes(branch, semester, section);
        CREATE INDEX IF NOT EXISTS idx_subjects_code ON subjects(subject_code);
        CREATE INDEX IF NOT EXISTS idx_subjects_class ON subjects(class_id);
        CREATE INDEX IF NOT EXISTS idx_attendance_unique ON attendance(student_id, subject_id, attendance_date);
        CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(attendance_date);
        CREATE INDEX IF NOT EXISTS idx_attendance_subject ON attendance(subject_id);
        CREATE INDEX IF NOT EXISTS idx_attendance_student ON attendance(student_id);
        CREATE INDEX IF NOT EXISTS idx_attendance_class ON attendance(class_id);
    )";

    return execute(sql);
}

bool Database::seedDefaultAdmin() {
    sqlite3_stmt* stmt = nullptr;
    const char* countSql = "SELECT COUNT(*) FROM users;";
    if (sqlite3_prepare_v2(db_, countSql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    int count = 0;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        count = sqlite3_column_int(stmt, 0);
    }
    sqlite3_finalize(stmt);

    if (count == 0) {
        std::string username = config::getDefaultAdminUsername();
        std::string plainPass = config::getDefaultAdminPassword();
        std::string salt = utils::Sha256::generateSalt();
        std::string hash = utils::Sha256::hashPassword(plainPass, salt);
        std::string createdAt = getCurrentTimestamp();

        const char* insertSql = "INSERT INTO users (username, password_hash, salt, role, created_at) VALUES (?, ?, ?, 'admin', ?);";
        if (sqlite3_prepare_v2(db_, insertSql, -1, &stmt, nullptr) == SQLITE_OK) {
            sqlite3_bind_text(stmt, 1, username.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(stmt, 2, hash.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(stmt, 3, salt.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(stmt, 4, createdAt.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_step(stmt);
            sqlite3_finalize(stmt);
            std::cout << "[Database] Initialized default administrator: " << username << " / " << plainPass << std::endl;
        }
    }
    return true;
}

} // namespace database
} // namespace attendx

