#pragma once
#include <sqlite3.h>
#include <string>
#include <mutex>
#include <memory>
#include <vector>
#include <functional>

namespace attendx {
namespace database {

class Database {
public:
    static Database& getInstance();

    bool initialize(const std::string& dbPath);
    void close();

    sqlite3* getHandle();
    std::mutex& getMutex();

    bool execute(const std::string& sql);
    int64_t lastInsertId();

    // Helper for transaction
    bool beginTransaction();
    bool commit();
    bool rollback();

    std::string getCurrentTimestamp();

private:
    Database();
    ~Database();
    Database(const Database&) = delete;
    Database& operator=(const Database&) = delete;

    bool createTables();
    bool createIndexes();
    bool seedDefaultAdmin();

    sqlite3* db_ = nullptr;
    std::mutex mutex_;
    std::string dbPath_;
};

} // namespace database
} // namespace attendx

