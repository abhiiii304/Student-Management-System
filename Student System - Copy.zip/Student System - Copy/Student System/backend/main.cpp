#include "httplib.h"
#include "config/config.h"
#include "database/Database.h"
#include "repositories/UserRepository.h"
#include "repositories/ClassRepository.h"
#include "repositories/StudentRepository.h"
#include "repositories/SubjectRepository.h"
#include "repositories/AttendanceRepository.h"
#include "services/AuthService.h"
#include "services/ClassService.h"
#include "services/StudentService.h"
#include "services/SubjectService.h"
#include "services/AttendanceService.h"
#include "services/ReportService.h"
#include "services/SeedService.h"
#include "routes/AuthRoutes.h"
#include "routes/StudentRoutes.h"
#include "routes/ClassRoutes.h"
#include "routes/SubjectRoutes.h"
#include "routes/AttendanceRoutes.h"
#include "routes/ReportRoutes.h"
#include "routes/DashboardRoutes.h"
#include "routes/SeedRoutes.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <filesystem>
#include <csignal>

namespace fs = std::filesystem;

static httplib::Server* g_server = nullptr;

void signalHandler(int signum) {
    std::cout << "\n[AttendX] Caught signal " << signum << ". Stopping server gracefully..." << std::endl;
    if (g_server) {
        g_server->stop();
    }
}

static void serveHtmlFile(const std::string& filepath, httplib::Response& res) {
    std::ifstream file(filepath);
    if (file.is_open()) {
        std::stringstream buffer;
        buffer << file.rdbuf();
        res.set_content(buffer.str(), "text/html; charset=utf-8");
        res.status = 200;
    } else {
        res.status = 404;
        res.set_content("<h1>404 Not Found</h1><p>File " + filepath + " not found.</p>", "text/html");
    }
}

int main(int argc, char* argv[]) {
    std::signal(SIGINT, signalHandler);
    std::signal(SIGTERM, signalHandler);

    int port = attendx::config::getPort();
    std::string host = attendx::config::getHost();
    std::string dbPath = attendx::config::getDatabasePath();
    std::string staticDir = attendx::config::getStaticDir();
    bool shouldSeed = false;

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--port" && i + 1 < argc) {
            port = std::stoi(argv[++i]);
        } else if (arg == "--host" && i + 1 < argc) {
            host = argv[++i];
        } else if (arg == "--db" && i + 1 < argc) {
            dbPath = argv[++i];
        } else if (arg == "--seed") {
            shouldSeed = true;
        } else if (arg == "--help" || arg == "-h") {
            std::cout << "ATTENDX — Smart Student Attendance Management System\n"
                      << "Usage: ./attendx_server [options]\n"
                      << "Options:\n"
                      << "  --port <port>   Set HTTP port (default: 8080)\n"
                      << "  --host <host>   Set HTTP host (default: 0.0.0.0)\n"
                      << "  --db <path>     Set SQLite db path (default: database/attendx.db)\n"
                      << "  --seed          Seed database with demo data on startup\n"
                      << "  --help, -h      Show this help message\n";
            return 0;
        }
    }

    // Ensure database directory exists
    fs::path p(dbPath);
    if (p.has_parent_path()) {
        fs::create_directories(p.parent_path());
    }

    std::cout << "========================================================\n"
              << "  ATTENDX — Smart Student Attendance Management System  \n"
              << "========================================================\n";

    // Initialize Database
    auto& db = attendx::database::Database::getInstance();
    if (!db.initialize(dbPath)) {
        std::cerr << "[AttendX] Fatal error: Could not initialize database.\n";
        return 1;
    }

    // Repositories
    attendx::repositories::UserRepository userRepo;
    attendx::repositories::ClassRepository classRepo;
    attendx::repositories::StudentRepository studentRepo;
    attendx::repositories::SubjectRepository subjectRepo;
    attendx::repositories::AttendanceRepository attRepo;

    // Services
    attendx::services::AuthService authService(userRepo);
    attendx::services::ClassService classService(classRepo);
    attendx::services::StudentService studentService(studentRepo);
    attendx::services::SubjectService subjectService(subjectRepo);
    attendx::services::AttendanceService attService(attRepo);
    attendx::services::ReportService reportService(attRepo, studentRepo);
    attendx::services::SeedService seedService(studentRepo, classRepo, subjectRepo, attRepo);

    if (shouldSeed) {
        std::cout << "[AttendX] Seeding demo dataset...\n";
        seedService.seedDemoData(true);
    }

    httplib::Server svr;
    g_server = &svr;

    // CORS and General Headers
    svr.set_pre_routing_handler([](const httplib::Request& req, httplib::Response& res) {
        res.set_header("Access-Control-Allow-Origin", "*");
        res.set_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        res.set_header("Access-Control-Allow-Headers", "Content-Type, Authorization");
        if (req.method == "OPTIONS") {
            res.status = 204;
            return httplib::Server::HandlerResponse::Handled;
        }
        return httplib::Server::HandlerResponse::Unhandled;
    });

    // Register API routes
    attendx::routes::AuthRoutes::registerRoutes(svr, authService);
    attendx::routes::StudentRoutes::registerRoutes(svr, studentService);
    attendx::routes::ClassRoutes::registerRoutes(svr, classService);
    attendx::routes::SubjectRoutes::registerRoutes(svr, subjectService);
    attendx::routes::AttendanceRoutes::registerRoutes(svr, attService);
    attendx::routes::ReportRoutes::registerRoutes(svr, reportService);
    attendx::routes::DashboardRoutes::registerRoutes(svr, attService, studentService);
    attendx::routes::SeedRoutes::registerRoutes(svr, seedService);

    // Serve Frontend HTML Pages
    svr.Get("/", [staticDir](const httplib::Request&, httplib::Response& res) {
        serveHtmlFile(staticDir + "/index.html", res);
    });
    svr.Get("/index.html", [staticDir](const httplib::Request&, httplib::Response& res) {
        serveHtmlFile(staticDir + "/index.html", res);
    });
    svr.Get("/students", [staticDir](const httplib::Request&, httplib::Response& res) {
        serveHtmlFile(staticDir + "/students.html", res);
    });
    svr.Get("/students.html", [staticDir](const httplib::Request&, httplib::Response& res) {
        serveHtmlFile(staticDir + "/students.html", res);
    });
    svr.Get("/attendance", [staticDir](const httplib::Request&, httplib::Response& res) {
        serveHtmlFile(staticDir + "/attendance.html", res);
    });
    svr.Get("/attendance.html", [staticDir](const httplib::Request&, httplib::Response& res) {
        serveHtmlFile(staticDir + "/attendance.html", res);
    });
    svr.Get("/classes", [staticDir](const httplib::Request&, httplib::Response& res) {
        serveHtmlFile(staticDir + "/classes.html", res);
    });
    svr.Get("/classes.html", [staticDir](const httplib::Request&, httplib::Response& res) {
        serveHtmlFile(staticDir + "/classes.html", res);
    });
    svr.Get("/reports", [staticDir](const httplib::Request&, httplib::Response& res) {
        serveHtmlFile(staticDir + "/reports.html", res);
    });
    svr.Get("/reports.html", [staticDir](const httplib::Request&, httplib::Response& res) {
        serveHtmlFile(staticDir + "/reports.html", res);
    });
    svr.Get("/login", [staticDir](const httplib::Request&, httplib::Response& res) {
        serveHtmlFile(staticDir + "/login.html", res);
    });
    svr.Get("/login.html", [staticDir](const httplib::Request&, httplib::Response& res) {
        serveHtmlFile(staticDir + "/login.html", res);
    });

    // Mount assets directory
    svr.set_mount_point("/assets", staticDir + "/assets");

    std::cout << "[AttendX] Server listening on http://" << (host == "0.0.0.0" ? "localhost" : host)
              << ":" << port << "\n"
              << "[AttendX] Default Admin: " << attendx::config::getDefaultAdminUsername()
              << " / " << attendx::config::getDefaultAdminPassword() << "\n"
              << "[AttendX] Ready for connections...\n";

    if (!svr.listen(host.c_str(), port)) {
        std::cerr << "[AttendX] Failed to bind/listen on " << host << ":" << port << std::endl;
        return 1;
    }

    return 0;
}

