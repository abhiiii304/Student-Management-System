#pragma once
#include "json.hpp"
#include <string>

namespace attendx {
namespace models {

struct Attendance {
    int id = 0;
    int studentId = 0;
    int subjectId = 0;
    int classId = 0;
    std::string attendanceDate; // YYYY-MM-DD
    std::string status;         // Present, Absent, Late
    std::string createdAt;
    std::string updatedAt;

    // Joined metadata
    std::string studentName;
    std::string enrollmentId;
    std::string rollNumber;
    std::string subjectName;
    std::string subjectCode;
    std::string branch;
    int semester = 0;
    std::string section;

    nlohmann::json toJson() const {
        nlohmann::json j;
        j["id"] = id;
        j["student_id"] = studentId;
        j["subject_id"] = subjectId;
        j["class_id"] = (classId > 0) ? nlohmann::json(classId) : nullptr;
        j["attendance_date"] = attendanceDate;
        j["status"] = status;
        j["created_at"] = createdAt;
        j["updated_at"] = updatedAt;

        j["student_name"] = studentName;
        j["enrollment_id"] = enrollmentId;
        j["roll_number"] = rollNumber;
        j["subject_name"] = subjectName;
        j["subject_code"] = subjectCode;
        j["branch"] = branch;
        j["semester"] = semester;
        j["section"] = section;
        return j;
    }

    static Attendance fromJson(const nlohmann::json& j) {
        Attendance a;
        if (j.contains("id") && j["id"].is_number()) a.id = j["id"];
        if (j.contains("student_id") && j["student_id"].is_number()) a.studentId = j["student_id"];
        if (j.contains("subject_id") && j["subject_id"].is_number()) a.subjectId = j["subject_id"];
        if (j.contains("class_id") && j["class_id"].is_number()) a.classId = j["class_id"];
        if (j.contains("attendance_date") && j["attendance_date"].is_string()) a.attendanceDate = j["attendance_date"];
        if (j.contains("status") && j["status"].is_string()) a.status = j["status"];
        return a;
    }
};

} // namespace models
} // namespace attendx

