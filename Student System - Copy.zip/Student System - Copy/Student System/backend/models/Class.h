#pragma once
#include "json.hpp"
#include <string>

namespace attendx {
namespace models {

struct Class {
    int id = 0;
    std::string branch;
    int semester = 1;
    std::string section;
    std::string academicYear;
    std::string createdAt;
    std::string updatedAt;

    // Computed / joined fields
    int studentCount = 0;
    int subjectCount = 0;

    nlohmann::json toJson() const {
        nlohmann::json j;
        j["id"] = id;
        j["branch"] = branch;
        j["semester"] = semester;
        j["section"] = section;
        j["academic_year"] = academicYear;
        j["created_at"] = createdAt;
        j["updated_at"] = updatedAt;
        j["student_count"] = studentCount;
        j["subject_count"] = subjectCount;
        return j;
    }

    static Class fromJson(const nlohmann::json& j) {
        Class c;
        if (j.contains("id") && j["id"].is_number()) c.id = j["id"];
        if (j.contains("branch") && j["branch"].is_string()) c.branch = j["branch"];
        if (j.contains("semester") && j["semester"].is_number()) c.semester = j["semester"];
        if (j.contains("section") && j["section"].is_string()) c.section = j["section"];
        if (j.contains("academic_year") && j["academic_year"].is_string()) c.academicYear = j["academic_year"];
        return c;
    }
};

} // namespace models
} // namespace attendx

