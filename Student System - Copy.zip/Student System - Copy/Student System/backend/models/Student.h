#pragma once
#include "json.hpp"
#include <string>

namespace attendx {
namespace models {

struct Student {
    int id = 0;
    std::string enrollmentId;
    std::string name;
    std::string rollNumber;
    std::string branch;
    std::string section;
    int semester = 1;
    std::string email;
    std::string phone;
    std::string createdAt;
    std::string updatedAt;
    std::string deletedAt; // empty if active

    // Computed attendance stats
    int totalClasses = 0;
    int presentClasses = 0;
    int absentClasses = 0;
    int lateClasses = 0;
    double attendancePercentage = 0.0;

    nlohmann::json toJson() const {
        nlohmann::json j;
        j["id"] = id;
        j["enrollment_id"] = enrollmentId;
        j["name"] = name;
        j["roll_number"] = rollNumber;
        j["branch"] = branch;
        j["section"] = section;
        j["semester"] = semester;
        j["email"] = email;
        j["phone"] = phone;
        j["created_at"] = createdAt;
        j["updated_at"] = updatedAt;
        j["deleted_at"] = deletedAt.empty() ? nullptr : nlohmann::json(deletedAt);
        j["total_classes"] = totalClasses;
        j["present_classes"] = presentClasses;
        j["absent_classes"] = absentClasses;
        j["late_classes"] = lateClasses;
        j["attendance_percentage"] = attendancePercentage;
        return j;
    }

    static Student fromJson(const nlohmann::json& j) {
        Student s;
        if (j.contains("id") && j["id"].is_number()) s.id = j["id"];
        if (j.contains("enrollment_id") && j["enrollment_id"].is_string()) s.enrollmentId = j["enrollment_id"];
        if (j.contains("name") && j["name"].is_string()) s.name = j["name"];
        if (j.contains("roll_number") && j["roll_number"].is_string()) s.rollNumber = j["roll_number"];
        if (j.contains("branch") && j["branch"].is_string()) s.branch = j["branch"];
        if (j.contains("section") && j["section"].is_string()) s.section = j["section"];
        if (j.contains("semester") && j["semester"].is_number()) s.semester = j["semester"];
        if (j.contains("email") && j["email"].is_string()) s.email = j["email"];
        if (j.contains("phone") && j["phone"].is_string()) s.phone = j["phone"];
        return s;
    }
};

} // namespace models
} // namespace attendx

