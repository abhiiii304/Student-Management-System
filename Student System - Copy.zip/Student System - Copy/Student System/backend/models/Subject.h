#pragma once
#include "json.hpp"
#include <string>

namespace attendx {
namespace models {

struct Subject {
    int id = 0;
    std::string subjectName;
    std::string subjectCode;
    std::string branch;
    int semester = 1;
    std::string section;
    std::string facultyName;
    int classId = 0;
    std::string createdAt;
    std::string updatedAt;

    // Joined stats
    int studentCount = 0;
    int totalSessions = 0;
    double averageAttendance = 0.0;

    nlohmann::json toJson() const {
        nlohmann::json j;
        j["id"] = id;
        j["subject_name"] = subjectName;
        j["subject_code"] = subjectCode;
        j["branch"] = branch;
        j["semester"] = semester;
        j["section"] = section;
        j["faculty_name"] = facultyName;
        j["class_id"] = (classId > 0) ? nlohmann::json(classId) : nullptr;
        j["created_at"] = createdAt;
        j["updated_at"] = updatedAt;
        j["student_count"] = studentCount;
        j["total_sessions"] = totalSessions;
        j["average_attendance"] = averageAttendance;
        return j;
    }

    static Subject fromJson(const nlohmann::json& j) {
        Subject s;
        if (j.contains("id") && j["id"].is_number()) s.id = j["id"];
        if (j.contains("subject_name") && j["subject_name"].is_string()) s.subjectName = j["subject_name"];
        if (j.contains("subject_code") && j["subject_code"].is_string()) s.subjectCode = j["subject_code"];
        if (j.contains("branch") && j["branch"].is_string()) s.branch = j["branch"];
        if (j.contains("semester") && j["semester"].is_number()) s.semester = j["semester"];
        if (j.contains("section") && j["section"].is_string()) s.section = j["section"];
        if (j.contains("faculty_name") && j["faculty_name"].is_string()) s.facultyName = j["faculty_name"];
        if (j.contains("class_id") && j["class_id"].is_number()) s.classId = j["class_id"];
        return s;
    }
};

} // namespace models
} // namespace attendx

