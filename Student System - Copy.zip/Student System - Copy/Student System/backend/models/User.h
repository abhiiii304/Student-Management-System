#pragma once
#include "json.hpp"
#include <string>

namespace attendx {
namespace models {

struct User {
    int id = 0;
    std::string username;
    std::string passwordHash;
    std::string salt;
    std::string role;
    std::string createdAt;

    nlohmann::json toJson(bool includeSecrets = false) const {
        nlohmann::json j;
        j["id"] = id;
        j["username"] = username;
        j["role"] = role;
        j["created_at"] = createdAt;
        if (includeSecrets) {
            j["password_hash"] = passwordHash;
            j["salt"] = salt;
        }
        return j;
    }
};

} // namespace models
} // namespace attendx

