#include "AttendanceRepository.h"
#include "../database/Database.h"
#include <sqlite3.h>
#include <iostream>
#include <cmath>

namespace attendx {
namespace repositories {

std::vector<models::Attendance> AttendanceRepository::findByFilters(
    const std::string& date,
    int subjectId,
    int classId,
    int studentId
) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    std::string sql = R"(
        SELECT a.id, a.student_id, a.subject_id, a.class_id, a.attendance_date, a.status, a.created_at, a.updated_at,
               s.name AS student_name, s.enrollment_id, s.roll_number, s.branch, s.semester, s.section,
               sub.subject_name, sub.subject_code
        FROM attendance a
        JOIN students s ON s.id = a.student_id
        JOIN subjects sub ON sub.id = a.subject_id
        WHERE 1=1
    )";

    if (!date.empty()) {
        sql += " AND a.attendance_date = ?";
    }
    if (subjectId > 0) {
        sql += " AND a.subject_id = ?";
    }
    if (classId > 0) {
        sql += " AND (a.class_id = ? OR (s.branch = (SELECT c.branch FROM classes c WHERE c.id = ?) AND s.semester = (SELECT c.semester FROM classes c WHERE c.id = ?) AND s.section = (SELECT c.section FROM classes c WHERE c.id = ?)))";
    }
    if (studentId > 0) {
        sql += " AND a.student_id = ?";
    }
    sql += " ORDER BY a.attendance_date DESC, s.roll_number ASC, s.name ASC;";

    sqlite3_stmt* stmt = nullptr;
    std::vector<models::Attendance> result;
    if (sqlite3_prepare_v2(db.getHandle(), sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        return result;
    }

    int paramIdx = 1;
    if (!date.empty()) {
        sqlite3_bind_text(stmt, paramIdx++, date.c_str(), -1, SQLITE_TRANSIENT);
    }
    if (subjectId > 0) {
        sqlite3_bind_int(stmt, paramIdx++, subjectId);
    }
    if (classId > 0) {
        sqlite3_bind_int(stmt, paramIdx++, classId);
        sqlite3_bind_int(stmt, paramIdx++, classId);
        sqlite3_bind_int(stmt, paramIdx++, classId);
        sqlite3_bind_int(stmt, paramIdx++, classId);
    }
    if (studentId > 0) {
        sqlite3_bind_int(stmt, paramIdx++, studentId);
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        models::Attendance a;
        a.id = sqlite3_column_int(stmt, 0);
        a.studentId = sqlite3_column_int(stmt, 1);
        a.subjectId = sqlite3_column_int(stmt, 2);
        a.classId = sqlite3_column_type(stmt, 3) != SQLITE_NULL ? sqlite3_column_int(stmt, 3) : 0;
        a.attendanceDate = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        a.status = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        a.createdAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 6));
        a.updatedAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 7));

        a.studentName = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 8));
        a.enrollmentId = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 9));
        const char* rn = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 10));
        a.rollNumber = rn ? rn : "";
        a.branch = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 11));
        a.semester = sqlite3_column_int(stmt, 12);
        a.section = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 13));

        a.subjectName = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 14));
        const char* sc = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 15));
        a.subjectCode = sc ? sc : "";

        result.push_back(a);
    }
    sqlite3_finalize(stmt);
    return result;
}

std::optional<models::Attendance> AttendanceRepository::findById(int id) {
    auto list = findByFilters("", 0, 0, 0);
    for (const auto& a : list) {
        if (a.id == id) return a;
    }
    return std::nullopt;
}

std::optional<models::Attendance> AttendanceRepository::findExisting(int studentId, int subjectId, const std::string& date) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "SELECT id, student_id, subject_id, class_id, attendance_date, status, created_at, updated_at FROM attendance WHERE student_id = ? AND subject_id = ? AND attendance_date = ? LIMIT 1;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return std::nullopt;
    }

    sqlite3_bind_int(stmt, 1, studentId);
    sqlite3_bind_int(stmt, 2, subjectId);
    sqlite3_bind_text(stmt, 3, date.c_str(), -1, SQLITE_TRANSIENT);

    std::optional<models::Attendance> result;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        models::Attendance a;
        a.id = sqlite3_column_int(stmt, 0);
        a.studentId = sqlite3_column_int(stmt, 1);
        a.subjectId = sqlite3_column_int(stmt, 2);
        a.classId = sqlite3_column_type(stmt, 3) != SQLITE_NULL ? sqlite3_column_int(stmt, 3) : 0;
        a.attendanceDate = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        a.status = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        a.createdAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 6));
        a.updatedAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 7));
        result = a;
    }
    sqlite3_finalize(stmt);
    return result;
}

bool AttendanceRepository::record(int studentId, int subjectId, int classId, const std::string& date, const std::string& status, int& outId) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    // Use INSERT OR REPLACE / UPSERT to prevent duplicates
    const char* sql = R"(
        INSERT INTO attendance (student_id, subject_id, class_id, attendance_date, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(student_id, subject_id, attendance_date) 
        DO UPDATE SET status = excluded.status, class_id = excluded.class_id, updated_at = excluded.updated_at;
    )";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    std::string now = db.getCurrentTimestamp();
    sqlite3_bind_int(stmt, 1, studentId);
    sqlite3_bind_int(stmt, 2, subjectId);
    if (classId > 0) {
        sqlite3_bind_int(stmt, 3, classId);
    } else {
        sqlite3_bind_null(stmt, 3);
    }
    sqlite3_bind_text(stmt, 4, date.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 5, status.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 6, now.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 7, now.c_str(), -1, SQLITE_TRANSIENT);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);

    if (rc == SQLITE_DONE) {
        outId = static_cast<int>(sqlite3_last_insert_rowid(db.getHandle()));
        return true;
    }
    return false;
}

bool AttendanceRepository::updateStatus(int id, const std::string& status) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "UPDATE attendance SET status = ?, updated_at = ? WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    std::string now = db.getCurrentTimestamp();
    sqlite3_bind_text(stmt, 1, status.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, now.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 3, id);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

bool AttendanceRepository::bulkRecord(const std::vector<models::Attendance>& records, int& updatedCount, int& insertedCount) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    db.beginTransaction();
    updatedCount = 0;
    insertedCount = 0;

    for (const auto& rec : records) {
        // Check if exists
        const char* checkSql = "SELECT id FROM attendance WHERE student_id = ? AND subject_id = ? AND attendance_date = ? LIMIT 1;";
        sqlite3_stmt* checkStmt = nullptr;
        bool exists = false;
        if (sqlite3_prepare_v2(db.getHandle(), checkSql, -1, &checkStmt, nullptr) == SQLITE_OK) {
            sqlite3_bind_int(checkStmt, 1, rec.studentId);
            sqlite3_bind_int(checkStmt, 2, rec.subjectId);
            sqlite3_bind_text(checkStmt, 3, rec.attendanceDate.c_str(), -1, SQLITE_TRANSIENT);
            if (sqlite3_step(checkStmt) == SQLITE_ROW) {
                exists = true;
            }
            sqlite3_finalize(checkStmt);
        }

        const char* sql = R"(
            INSERT INTO attendance (student_id, subject_id, class_id, attendance_date, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(student_id, subject_id, attendance_date) 
            DO UPDATE SET status = excluded.status, class_id = excluded.class_id, updated_at = excluded.updated_at;
        )";
        sqlite3_stmt* stmt = nullptr;
        if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) == SQLITE_OK) {
            std::string now = db.getCurrentTimestamp();
            sqlite3_bind_int(stmt, 1, rec.studentId);
            sqlite3_bind_int(stmt, 2, rec.subjectId);
            if (rec.classId > 0) sqlite3_bind_int(stmt, 3, rec.classId);
            else sqlite3_bind_null(stmt, 3);
            sqlite3_bind_text(stmt, 4, rec.attendanceDate.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(stmt, 5, rec.status.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(stmt, 6, now.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(stmt, 7, now.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_step(stmt);
            sqlite3_finalize(stmt);

            if (exists) updatedCount++;
            else insertedCount++;
        }
    }

    db.commit();
    return true;
}

AttendanceSummary AttendanceRepository::getSummary(const std::string& date, int subjectId, int classId) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    std::string sql = R"(
        SELECT 
            COUNT(id) AS total,
            SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS present,
            SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) AS absent,
            SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) AS late
        FROM attendance
        WHERE 1=1
    )";

    if (!date.empty()) sql += " AND attendance_date = ?";
    if (subjectId > 0) sql += " AND subject_id = ?";
    if (classId > 0) sql += " AND class_id = ?";

    sqlite3_stmt* stmt = nullptr;
    AttendanceSummary sum;
    if (sqlite3_prepare_v2(db.getHandle(), sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        return sum;
    }

    int idx = 1;
    if (!date.empty()) sqlite3_bind_text(stmt, idx++, date.c_str(), -1, SQLITE_TRANSIENT);
    if (subjectId > 0) sqlite3_bind_int(stmt, idx++, subjectId);
    if (classId > 0) sqlite3_bind_int(stmt, idx++, classId);

    if (sqlite3_step(stmt) == SQLITE_ROW) {
        sum.total = sqlite3_column_int(stmt, 0);
        sum.present = sqlite3_column_int(stmt, 1);
        sum.absent = sqlite3_column_int(stmt, 2);
        sum.late = sqlite3_column_int(stmt, 3);
        if (sum.total > 0) {
            sum.percentage = (static_cast<double>(sum.present) / sum.total) * 100.0;
        }
    }
    sqlite3_finalize(stmt);
    return sum;
}

DashboardStats AttendanceRepository::getDashboardStats(const std::string& todayDate) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    DashboardStats stats;

    // Total active students
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), "SELECT COUNT(*) FROM students WHERE deleted_at IS NULL;", -1, &stmt, nullptr) == SQLITE_OK) {
        if (sqlite3_step(stmt) == SQLITE_ROW) stats.totalStudents = sqlite3_column_int(stmt, 0);
        sqlite3_finalize(stmt);
    }

    // Total classes
    if (sqlite3_prepare_v2(db.getHandle(), "SELECT COUNT(*) FROM classes;", -1, &stmt, nullptr) == SQLITE_OK) {
        if (sqlite3_step(stmt) == SQLITE_ROW) stats.totalClasses = sqlite3_column_int(stmt, 0);
        sqlite3_finalize(stmt);
    }

    // Total subjects
    if (sqlite3_prepare_v2(db.getHandle(), "SELECT COUNT(*) FROM subjects;", -1, &stmt, nullptr) == SQLITE_OK) {
        if (sqlite3_step(stmt) == SQLITE_ROW) stats.totalSubjects = sqlite3_column_int(stmt, 0);
        sqlite3_finalize(stmt);
    }

    // Today's attendance stats (if no records today, get latest recorded date stats)
    std::string queryDate = todayDate;
    if (sqlite3_prepare_v2(db.getHandle(), "SELECT COUNT(*) FROM attendance WHERE attendance_date = ?;", -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, todayDate.c_str(), -1, SQLITE_TRANSIENT);
        int todayRecords = 0;
        if (sqlite3_step(stmt) == SQLITE_ROW) todayRecords = sqlite3_column_int(stmt, 0);
        sqlite3_finalize(stmt);

        if (todayRecords == 0) {
            // Find latest date in attendance
            if (sqlite3_prepare_v2(db.getHandle(), "SELECT MAX(attendance_date) FROM attendance;", -1, &stmt, nullptr) == SQLITE_OK) {
                if (sqlite3_step(stmt) == SQLITE_ROW && sqlite3_column_text(stmt, 0)) {
                    queryDate = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
                }
                sqlite3_finalize(stmt);
            }
        }
    }

    const char* todaySql = R"(
        SELECT 
            SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS present,
            SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) AS absent,
            SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) AS late
        FROM attendance
        WHERE attendance_date = ?;
    )";
    if (sqlite3_prepare_v2(db.getHandle(), todaySql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, queryDate.c_str(), -1, SQLITE_TRANSIENT);
        if (sqlite3_step(stmt) == SQLITE_ROW) {
            stats.todayPresent = sqlite3_column_int(stmt, 0);
            stats.todayAbsent = sqlite3_column_int(stmt, 1);
            stats.todayLate = sqlite3_column_int(stmt, 2);
        }
        sqlite3_finalize(stmt);
    }

    // Overall attendance rate across all time
    const char* rateSql = R"(
        SELECT 
            COUNT(id) AS total,
            SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS present
        FROM attendance;
    )";
    if (sqlite3_prepare_v2(db.getHandle(), rateSql, -1, &stmt, nullptr) == SQLITE_OK) {
        if (sqlite3_step(stmt) == SQLITE_ROW) {
            int total = sqlite3_column_int(stmt, 0);
            int pres = sqlite3_column_int(stmt, 1);
            if (total > 0) {
                stats.overallAttendanceRate = (static_cast<double>(pres) / total) * 100.0;
            }
        }
        sqlite3_finalize(stmt);
    }

    return stats;
}

std::vector<TrendPoint> AttendanceRepository::getAttendanceTrends(const std::string& range, int limit) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    std::vector<TrendPoint> points;
    std::string sql;

    if (range == "monthly") {
        sql = R"(
            SELECT 
                SUBSTR(attendance_date, 1, 7) AS period,
                SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS present,
                SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) AS absent,
                SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) AS late,
                COUNT(id) AS total
            FROM attendance
            GROUP BY SUBSTR(attendance_date, 1, 7)
            ORDER BY period DESC
            LIMIT ?;
        )";
    } else {
        // daily
        sql = R"(
            SELECT 
                attendance_date AS period,
                SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS present,
                SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) AS absent,
                SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) AS late,
                COUNT(id) AS total
            FROM attendance
            GROUP BY attendance_date
            ORDER BY attendance_date DESC
            LIMIT ?;
        )";
    }

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        return points;
    }

    sqlite3_bind_int(stmt, 1, limit > 0 ? limit : 7);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        TrendPoint tp;
        tp.date = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
        tp.present = sqlite3_column_int(stmt, 1);
        tp.absent = sqlite3_column_int(stmt, 2);
        tp.late = sqlite3_column_int(stmt, 3);
        int total = sqlite3_column_int(stmt, 4);
        if (total > 0) {
            tp.percentage = (static_cast<double>(tp.present) / total) * 100.0;
        }
        points.push_back(tp);
    }
    sqlite3_finalize(stmt);

    // Reverse so chronologically ascending for charts
    std::reverse(points.begin(), points.end());
    return points;
}

AttendanceSummary AttendanceRepository::getAttendanceDistribution() {
    return getSummary();
}

std::vector<models::Attendance> AttendanceRepository::getRecentActivity(int limit) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    std::string sql = R"(
        SELECT a.id, a.student_id, a.subject_id, a.class_id, a.attendance_date, a.status, a.created_at, a.updated_at,
               s.name AS student_name, s.enrollment_id, s.roll_number, s.branch, s.semester, s.section,
               sub.subject_name, sub.subject_code
        FROM attendance a
        JOIN students s ON s.id = a.student_id
        JOIN subjects sub ON sub.id = a.subject_id
        ORDER BY a.updated_at DESC, a.id DESC
        LIMIT ?;
    )";

    sqlite3_stmt* stmt = nullptr;
    std::vector<models::Attendance> result;
    if (sqlite3_prepare_v2(db.getHandle(), sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        return result;
    }

    sqlite3_bind_int(stmt, 1, limit > 0 ? limit : 10);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        models::Attendance a;
        a.id = sqlite3_column_int(stmt, 0);
        a.studentId = sqlite3_column_int(stmt, 1);
        a.subjectId = sqlite3_column_int(stmt, 2);
        a.classId = sqlite3_column_type(stmt, 3) != SQLITE_NULL ? sqlite3_column_int(stmt, 3) : 0;
        a.attendanceDate = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        a.status = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        a.createdAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 6));
        a.updatedAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 7));

        a.studentName = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 8));
        a.enrollmentId = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 9));
        const char* rn = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 10));
        a.rollNumber = rn ? rn : "";
        a.branch = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 11));
        a.semester = sqlite3_column_int(stmt, 12);
        a.section = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 13));

        a.subjectName = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 14));
        const char* sc = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 15));
        a.subjectCode = sc ? sc : "";

        result.push_back(a);
    }
    sqlite3_finalize(stmt);
    return result;
}

nlohmann::json AttendanceRepository::getStudentReport(int studentId, int classId, int subjectId, const std::string& startDate, const std::string& endDate) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    std::string sql = R"(
        SELECT 
            s.id AS student_id,
            s.enrollment_id,
            s.name AS student_name,
            s.roll_number,
            s.branch,
            s.semester,
            s.section,
            sub.id AS subject_id,
            sub.subject_name,
            sub.subject_code,
            COUNT(a.id) AS total_classes,
            SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present_count,
            SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_count,
            SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late_count
        FROM students s
        CROSS JOIN subjects sub
        LEFT JOIN attendance a ON a.student_id = s.id AND a.subject_id = sub.id
    )";

    sql += " WHERE s.deleted_at IS NULL";
    if (studentId > 0) sql += " AND s.id = ?";
    if (subjectId > 0) sql += " AND sub.id = ?";
    if (classId > 0) {
        sql += " AND s.branch = (SELECT c.branch FROM classes c WHERE c.id = ?) AND s.semester = (SELECT c.semester FROM classes c WHERE c.id = ?) AND s.section = (SELECT c.section FROM classes c WHERE c.id = ?)";
    }
    if (!startDate.empty()) sql += " AND (a.attendance_date IS NULL OR a.attendance_date >= ?)";
    if (!endDate.empty()) sql += " AND (a.attendance_date IS NULL OR a.attendance_date <= ?)";

    sql += " GROUP BY s.id, sub.id HAVING total_classes > 0 ORDER BY s.roll_number ASC, sub.subject_code ASC;";

    sqlite3_stmt* stmt = nullptr;
    nlohmann::json rows = nlohmann::json::array();
    if (sqlite3_prepare_v2(db.getHandle(), sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        return rows;
    }

    int idx = 1;
    if (studentId > 0) sqlite3_bind_int(stmt, idx++, studentId);
    if (subjectId > 0) sqlite3_bind_int(stmt, idx++, subjectId);
    if (classId > 0) {
        sqlite3_bind_int(stmt, idx++, classId);
        sqlite3_bind_int(stmt, idx++, classId);
        sqlite3_bind_int(stmt, idx++, classId);
    }
    if (!startDate.empty()) sqlite3_bind_text(stmt, idx++, startDate.c_str(), -1, SQLITE_TRANSIENT);
    if (!endDate.empty()) sqlite3_bind_text(stmt, idx++, endDate.c_str(), -1, SQLITE_TRANSIENT);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        nlohmann::json row;
        row["student_id"] = sqlite3_column_int(stmt, 0);
        row["enrollment_id"] = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        row["student_name"] = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
        const char* rn = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        row["roll_number"] = rn ? rn : "";
        row["branch"] = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        row["semester"] = sqlite3_column_int(stmt, 5);
        row["section"] = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 6));
        row["subject_id"] = sqlite3_column_int(stmt, 7);
        row["subject_name"] = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 8));
        const char* sc = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 9));
        row["subject_code"] = sc ? sc : "";

        int total = sqlite3_column_int(stmt, 10);
        int pres = sqlite3_column_int(stmt, 11);
        int abs = sqlite3_column_int(stmt, 12);
        int late = sqlite3_column_int(stmt, 13);

        row["total_classes"] = total;
        row["present"] = pres;
        row["absent"] = abs;
        row["late"] = late;
        row["attendance_percentage"] = total > 0 ? (static_cast<double>(pres) / total) * 100.0 : 0.0;
        row["is_low_attendance"] = row["attendance_percentage"].get<double>() < 75.0;

        rows.push_back(row);
    }
    sqlite3_finalize(stmt);
    return rows;
}

nlohmann::json AttendanceRepository::getClassReport(int classId, const std::string& startDate, const std::string& endDate) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    std::string sql = R"(
        SELECT 
            c.id AS class_id,
            c.branch,
            c.semester,
            c.section,
            COUNT(a.id) AS total_attendance_records,
            SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present_count,
            SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_count,
            SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late_count,
            COUNT(DISTINCT s.id) AS enrolled_students
        FROM classes c
        LEFT JOIN students s ON s.branch = c.branch AND s.semester = c.semester AND s.section = c.section AND s.deleted_at IS NULL
        LEFT JOIN attendance a ON a.student_id = s.id
        WHERE 1=1
    )";

    if (classId > 0) sql += " AND c.id = ?";
    if (!startDate.empty()) sql += " AND (a.attendance_date IS NULL OR a.attendance_date >= ?)";
    if (!endDate.empty()) sql += " AND (a.attendance_date IS NULL OR a.attendance_date <= ?)";

    sql += " GROUP BY c.id ORDER BY c.semester ASC, c.branch ASC, c.section ASC;";

    sqlite3_stmt* stmt = nullptr;
    nlohmann::json rows = nlohmann::json::array();
    if (sqlite3_prepare_v2(db.getHandle(), sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        return rows;
    }

    int idx = 1;
    if (classId > 0) sqlite3_bind_int(stmt, idx++, classId);
    if (!startDate.empty()) sqlite3_bind_text(stmt, idx++, startDate.c_str(), -1, SQLITE_TRANSIENT);
    if (!endDate.empty()) sqlite3_bind_text(stmt, idx++, endDate.c_str(), -1, SQLITE_TRANSIENT);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        nlohmann::json row;
        row["class_id"] = sqlite3_column_int(stmt, 0);
        row["branch"] = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        row["semester"] = sqlite3_column_int(stmt, 2);
        row["section"] = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        int total = sqlite3_column_int(stmt, 4);
        int pres = sqlite3_column_int(stmt, 5);
        int abs = sqlite3_column_int(stmt, 6);
        int late = sqlite3_column_int(stmt, 7);
        int enrolled = sqlite3_column_int(stmt, 8);

        row["total_classes"] = total;
        row["present"] = pres;
        row["absent"] = abs;
        row["late"] = late;
        row["enrolled_students"] = enrolled;
        row["attendance_percentage"] = total > 0 ? (static_cast<double>(pres) / total) * 100.0 : 0.0;
        rows.push_back(row);
    }
    sqlite3_finalize(stmt);
    return rows;
}

nlohmann::json AttendanceRepository::getSubjectReport(int subjectId, const std::string& startDate, const std::string& endDate) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    std::string sql = R"(
        SELECT 
            sub.id AS subject_id,
            sub.subject_name,
            sub.subject_code,
            sub.faculty_name,
            sub.branch,
            sub.semester,
            COUNT(a.id) AS total_attendance_records,
            SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present_count,
            SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_count,
            SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late_count,
            COUNT(DISTINCT a.attendance_date) AS total_sessions
        FROM subjects sub
        LEFT JOIN attendance a ON a.subject_id = sub.id
        WHERE 1=1
    )";

    if (subjectId > 0) sql += " AND sub.id = ?";
    if (!startDate.empty()) sql += " AND (a.attendance_date IS NULL OR a.attendance_date >= ?)";
    if (!endDate.empty()) sql += " AND (a.attendance_date IS NULL OR a.attendance_date <= ?)";

    sql += " GROUP BY sub.id ORDER BY sub.semester ASC, sub.subject_code ASC;";

    sqlite3_stmt* stmt = nullptr;
    nlohmann::json rows = nlohmann::json::array();
    if (sqlite3_prepare_v2(db.getHandle(), sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        return rows;
    }

    int idx = 1;
    if (subjectId > 0) sqlite3_bind_int(stmt, idx++, subjectId);
    if (!startDate.empty()) sqlite3_bind_text(stmt, idx++, startDate.c_str(), -1, SQLITE_TRANSIENT);
    if (!endDate.empty()) sqlite3_bind_text(stmt, idx++, endDate.c_str(), -1, SQLITE_TRANSIENT);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        nlohmann::json row;
        row["subject_id"] = sqlite3_column_int(stmt, 0);
        row["subject_name"] = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        const char* sc = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
        row["subject_code"] = sc ? sc : "";
        const char* fn = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        row["faculty_name"] = fn ? fn : "";
        const char* br = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        row["branch"] = br ? br : "";
        row["semester"] = sqlite3_column_int(stmt, 5);

        int total = sqlite3_column_int(stmt, 6);
        int pres = sqlite3_column_int(stmt, 7);
        int abs = sqlite3_column_int(stmt, 8);
        int late = sqlite3_column_int(stmt, 9);
        int sessions = sqlite3_column_int(stmt, 10);

        row["total_classes"] = total;
        row["present"] = pres;
        row["absent"] = abs;
        row["late"] = late;
        row["total_sessions"] = sessions;
        row["attendance_percentage"] = total > 0 ? (static_cast<double>(pres) / total) * 100.0 : 0.0;
        rows.push_back(row);
    }
    sqlite3_finalize(stmt);
    return rows;
}

nlohmann::json AttendanceRepository::getDailyReport(const std::string& date, int classId, int subjectId) {
    auto records = findByFilters(date, subjectId, classId, 0);
    nlohmann::json rows = nlohmann::json::array();
    for (const auto& r : records) {
        rows.push_back(r.toJson());
    }
    return rows;
}

nlohmann::json AttendanceRepository::getMonthlyReport(const std::string& yearMonth, int classId, int subjectId) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    std::string sql = R"(
        SELECT 
            s.id AS student_id,
            s.enrollment_id,
            s.name AS student_name,
            s.roll_number,
            sub.subject_name,
            sub.subject_code,
            COUNT(a.id) AS total_classes,
            SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present_count,
            SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_count,
            SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late_count
        FROM attendance a
        JOIN students s ON s.id = a.student_id
        JOIN subjects sub ON sub.id = a.subject_id
        WHERE a.attendance_date LIKE ?
    )";

    if (classId > 0) sql += " AND a.class_id = ?";
    if (subjectId > 0) sql += " AND a.subject_id = ?";

    sql += " GROUP BY s.id, sub.id ORDER BY s.roll_number ASC, sub.subject_code ASC;";

    sqlite3_stmt* stmt = nullptr;
    nlohmann::json rows = nlohmann::json::array();
    if (sqlite3_prepare_v2(db.getHandle(), sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        return rows;
    }

    std::string pattern = yearMonth + "%";
    int idx = 1;
    sqlite3_bind_text(stmt, idx++, pattern.c_str(), -1, SQLITE_TRANSIENT);
    if (classId > 0) sqlite3_bind_int(stmt, idx++, classId);
    if (subjectId > 0) sqlite3_bind_int(stmt, idx++, subjectId);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        nlohmann::json row;
        row["student_id"] = sqlite3_column_int(stmt, 0);
        row["enrollment_id"] = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        row["student_name"] = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
        const char* rn = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        row["roll_number"] = rn ? rn : "";
        row["subject_name"] = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        const char* sc = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        row["subject_code"] = sc ? sc : "";

        int total = sqlite3_column_int(stmt, 6);
        int pres = sqlite3_column_int(stmt, 7);
        int abs = sqlite3_column_int(stmt, 8);
        int late = sqlite3_column_int(stmt, 9);

        row["total_classes"] = total;
        row["present"] = pres;
        row["absent"] = abs;
        row["late"] = late;
        row["attendance_percentage"] = total > 0 ? (static_cast<double>(pres) / total) * 100.0 : 0.0;
        row["is_low_attendance"] = row["attendance_percentage"].get<double>() < 75.0;

        rows.push_back(row);
    }
    sqlite3_finalize(stmt);
    return rows;
}

} // namespace repositories
} // namespace attendx

