#pragma once
#include "../models/Attendance.h"
#include "json.hpp"
#include <optional>
#include <vector>
#include <string>

namespace attendx {
namespace repositories {

struct AttendanceSummary {
    int total = 0;
    int present = 0;
    int absent = 0;
    int late = 0;
    double percentage = 0.0;

    nlohmann::json toJson() const {
        return {
            {"total", total},
            {"present", present},
            {"absent", absent},
            {"late", late},
            {"percentage", percentage}
        };
    }
};

struct DashboardStats {
    int totalStudents = 0;
    int todayPresent = 0;
    int todayAbsent = 0;
    int todayLate = 0;
    double overallAttendanceRate = 0.0;
    int totalClasses = 0;
    int totalSubjects = 0;

    nlohmann::json toJson() const {
        return {
            {"total_students", totalStudents},
            {"today_present", todayPresent},
            {"today_absent", todayAbsent},
            {"today_late", todayLate},
            {"overall_attendance_rate", overallAttendanceRate},
            {"total_classes", totalClasses},
            {"total_subjects", totalSubjects}
        };
    }
};

struct TrendPoint {
    std::string date;
    int present = 0;
    int absent = 0;
    int late = 0;
    double percentage = 0.0;

    nlohmann::json toJson() const {
        return {
            {"date", date},
            {"present", present},
            {"absent", absent},
            {"late", late},
            {"percentage", percentage}
        };
    }
};

class AttendanceRepository {
public:
    std::vector<models::Attendance> findByFilters(
        const std::string& date = "",
        int subjectId = 0,
        int classId = 0,
        int studentId = 0
    );

    std::optional<models::Attendance> findById(int id);
    std::optional<models::Attendance> findExisting(int studentId, int subjectId, const std::string& date);

    bool record(int studentId, int subjectId, int classId, const std::string& date, const std::string& status, int& outId);
    bool updateStatus(int id, const std::string& status);
    bool bulkRecord(const std::vector<models::Attendance>& records, int& updatedCount, int& insertedCount);

    AttendanceSummary getSummary(const std::string& date = "", int subjectId = 0, int classId = 0);
    DashboardStats getDashboardStats(const std::string& todayDate);
    std::vector<TrendPoint> getAttendanceTrends(const std::string& range = "daily", int limit = 7);
    AttendanceSummary getAttendanceDistribution();
    std::vector<models::Attendance> getRecentActivity(int limit = 10);

    // Detailed Report aggregations
    nlohmann::json getStudentReport(int studentId = 0, int classId = 0, int subjectId = 0, const std::string& startDate = "", const std::string& endDate = "");
    nlohmann::json getClassReport(int classId = 0, const std::string& startDate = "", const std::string& endDate = "");
    nlohmann::json getSubjectReport(int subjectId = 0, const std::string& startDate = "", const std::string& endDate = "");
    nlohmann::json getDailyReport(const std::string& date, int classId = 0, int subjectId = 0);
    nlohmann::json getMonthlyReport(const std::string& yearMonth, int classId = 0, int subjectId = 0);
};

} // namespace repositories
} // namespace attendx

