#include "ClassRepository.h"
#include "../database/Database.h"
#include <sqlite3.h>

namespace attendx {
namespace repositories {

std::vector<models::Class> ClassRepository::findAll(const std::string& search, const std::string& branch, int semester) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    std::string sql = R"(
        SELECT c.id, c.branch, c.semester, c.section, c.academic_year, c.created_at, c.updated_at,
               (SELECT COUNT(*) FROM students s WHERE s.deleted_at IS NULL AND s.branch = c.branch AND s.semester = c.semester AND s.section = c.section) AS student_count,
               (SELECT COUNT(*) FROM subjects sub WHERE sub.class_id = c.id OR (sub.branch = c.branch AND sub.semester = c.semester AND sub.section = c.section)) AS subject_count
        FROM classes c
        WHERE 1=1
    )";

    if (!search.empty()) {
        sql += " AND (c.branch LIKE ? OR c.section LIKE ? OR c.academic_year LIKE ?)";
    }
    if (!branch.empty()) {
        sql += " AND c.branch = ?";
    }
    if (semester > 0) {
        sql += " AND c.semester = ?";
    }
    sql += " ORDER BY c.semester ASC, c.branch ASC, c.section ASC;";

    sqlite3_stmt* stmt = nullptr;
    std::vector<models::Class> result;
    if (sqlite3_prepare_v2(db.getHandle(), sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        return result;
    }

    int paramIdx = 1;
    if (!search.empty()) {
        std::string pattern = "%" + search + "%";
        sqlite3_bind_text(stmt, paramIdx++, pattern.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, paramIdx++, pattern.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, paramIdx++, pattern.c_str(), -1, SQLITE_TRANSIENT);
    }
    if (!branch.empty()) {
        sqlite3_bind_text(stmt, paramIdx++, branch.c_str(), -1, SQLITE_TRANSIENT);
    }
    if (semester > 0) {
        sqlite3_bind_int(stmt, paramIdx++, semester);
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        models::Class c;
        c.id = sqlite3_column_int(stmt, 0);
        c.branch = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        c.semester = sqlite3_column_int(stmt, 2);
        c.section = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        const char* ay = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        c.academicYear = ay ? ay : "";
        c.createdAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        c.updatedAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 6));
        c.studentCount = sqlite3_column_int(stmt, 7);
        c.subjectCount = sqlite3_column_int(stmt, 8);
        result.push_back(c);
    }
    sqlite3_finalize(stmt);
    return result;
}

std::optional<models::Class> ClassRepository::findById(int id) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = R"(
        SELECT c.id, c.branch, c.semester, c.section, c.academic_year, c.created_at, c.updated_at,
               (SELECT COUNT(*) FROM students s WHERE s.deleted_at IS NULL AND s.branch = c.branch AND s.semester = c.semester AND s.section = c.section) AS student_count,
               (SELECT COUNT(*) FROM subjects sub WHERE sub.class_id = c.id OR (sub.branch = c.branch AND sub.semester = c.semester AND sub.section = c.section)) AS subject_count
        FROM classes c
        WHERE c.id = ?
        LIMIT 1;
    )";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return std::nullopt;
    }

    sqlite3_bind_int(stmt, 1, id);

    std::optional<models::Class> result;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        models::Class c;
        c.id = sqlite3_column_int(stmt, 0);
        c.branch = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        c.semester = sqlite3_column_int(stmt, 2);
        c.section = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        const char* ay = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        c.academicYear = ay ? ay : "";
        c.createdAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        c.updatedAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 6));
        c.studentCount = sqlite3_column_int(stmt, 7);
        c.subjectCount = sqlite3_column_int(stmt, 8);
        result = c;
    }
    sqlite3_finalize(stmt);
    return result;
}

std::optional<models::Class> ClassRepository::findExact(const std::string& branch, int semester, const std::string& section) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "SELECT id, branch, semester, section, academic_year, created_at, updated_at FROM classes WHERE branch = ? AND semester = ? AND section = ? LIMIT 1;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return std::nullopt;
    }

    sqlite3_bind_text(stmt, 1, branch.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 2, semester);
    sqlite3_bind_text(stmt, 3, section.c_str(), -1, SQLITE_TRANSIENT);

    std::optional<models::Class> result;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        models::Class c;
        c.id = sqlite3_column_int(stmt, 0);
        c.branch = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        c.semester = sqlite3_column_int(stmt, 2);
        c.section = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        const char* ay = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        c.academicYear = ay ? ay : "";
        c.createdAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        c.updatedAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 6));
        result = c;
    }
    sqlite3_finalize(stmt);
    return result;
}

bool ClassRepository::create(const models::Class& cls, int& outId) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "INSERT INTO classes (branch, semester, section, academic_year, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?);";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    std::string now = db.getCurrentTimestamp();
    sqlite3_bind_text(stmt, 1, cls.branch.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 2, cls.semester);
    sqlite3_bind_text(stmt, 3, cls.section.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 4, cls.academicYear.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 5, now.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 6, now.c_str(), -1, SQLITE_TRANSIENT);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);

    if (rc == SQLITE_DONE) {
        outId = static_cast<int>(sqlite3_last_insert_rowid(db.getHandle()));
        return true;
    }
    return false;
}

bool ClassRepository::update(const models::Class& cls) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "UPDATE classes SET branch = ?, semester = ?, section = ?, academic_year = ?, updated_at = ? WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    std::string now = db.getCurrentTimestamp();
    sqlite3_bind_text(stmt, 1, cls.branch.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 2, cls.semester);
    sqlite3_bind_text(stmt, 3, cls.section.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 4, cls.academicYear.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 5, now.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 6, cls.id);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

bool ClassRepository::deleteById(int id) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "DELETE FROM classes WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    sqlite3_bind_int(stmt, 1, id);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

int ClassRepository::count() {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "SELECT COUNT(*) FROM classes;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return 0;
    }

    int total = 0;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        total = sqlite3_column_int(stmt, 0);
    }
    sqlite3_finalize(stmt);
    return total;
}

} // namespace repositories
} // namespace attendx

