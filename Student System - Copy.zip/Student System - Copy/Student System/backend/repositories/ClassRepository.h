#pragma once
#include "../models/Class.h"
#include <optional>
#include <vector>
#include <string>

namespace attendx {
namespace repositories {

class ClassRepository {
public:
    std::vector<models::Class> findAll(const std::string& search = "", const std::string& branch = "", int semester = 0);
    std::optional<models::Class> findById(int id);
    std::optional<models::Class> findExact(const std::string& branch, int semester, const std::string& section);
    bool create(const models::Class& cls, int& outId);
    bool update(const models::Class& cls);
    bool deleteById(int id);
    int count();
};

} // namespace repositories
} // namespace attendx

