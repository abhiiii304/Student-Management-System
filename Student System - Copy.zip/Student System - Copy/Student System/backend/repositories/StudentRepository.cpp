#include "StudentRepository.h"
#include "../database/Database.h"
#include <sqlite3.h>
#include <iostream>

namespace attendx {
namespace repositories {

std::vector<models::Student> StudentRepository::findAll(
    const std::string& search,
    const std::string& branch,
    const std::string& section,
    int semester,
    bool includeDeleted,
    int limit,
    int offset
) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    std::string sql = R"(
        SELECT s.id, s.enrollment_id, s.name, s.roll_number, s.branch, s.section, s.semester,
               s.email, s.phone, s.created_at, s.updated_at, s.deleted_at,
               COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id), 0) AS total_classes,
               COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id AND a.status = 'Present'), 0) AS present_classes,
               COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id AND a.status = 'Absent'), 0) AS absent_classes,
               COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id AND a.status = 'Late'), 0) AS late_classes
        FROM students s
        WHERE 1=1
    )";

    if (!includeDeleted) {
        sql += " AND s.deleted_at IS NULL";
    }
    if (!search.empty()) {
        sql += " AND (s.name LIKE ? OR s.enrollment_id LIKE ? OR s.roll_number LIKE ? OR s.email LIKE ?)";
    }
    if (!branch.empty()) {
        sql += " AND s.branch = ?";
    }
    if (!section.empty()) {
        sql += " AND s.section = ?";
    }
    if (semester > 0) {
        sql += " AND s.semester = ?";
    }
    sql += " ORDER BY s.semester ASC, s.branch ASC, s.section ASC, s.roll_number ASC";
    if (limit > 0) {
        sql += " LIMIT ? OFFSET ?";
    }
    sql += ";";

    sqlite3_stmt* stmt = nullptr;
    std::vector<models::Student> result;
    if (sqlite3_prepare_v2(db.getHandle(), sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        return result;
    }

    int paramIdx = 1;
    if (!search.empty()) {
        std::string pattern = "%" + search + "%";
        sqlite3_bind_text(stmt, paramIdx++, pattern.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, paramIdx++, pattern.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, paramIdx++, pattern.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, paramIdx++, pattern.c_str(), -1, SQLITE_TRANSIENT);
    }
    if (!branch.empty()) {
        sqlite3_bind_text(stmt, paramIdx++, branch.c_str(), -1, SQLITE_TRANSIENT);
    }
    if (!section.empty()) {
        sqlite3_bind_text(stmt, paramIdx++, section.c_str(), -1, SQLITE_TRANSIENT);
    }
    if (semester > 0) {
        sqlite3_bind_int(stmt, paramIdx++, semester);
    }
    if (limit > 0) {
        sqlite3_bind_int(stmt, paramIdx++, limit);
        sqlite3_bind_int(stmt, paramIdx++, offset);
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        models::Student s;
        s.id = sqlite3_column_int(stmt, 0);
        s.enrollmentId = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        s.name = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
        const char* rn = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        s.rollNumber = rn ? rn : "";
        s.branch = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        s.section = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        s.semester = sqlite3_column_int(stmt, 6);
        const char* em = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 7));
        s.email = em ? em : "";
        const char* ph = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 8));
        s.phone = ph ? ph : "";
        s.createdAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 9));
        s.updatedAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 10));
        const char* del = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 11));
        s.deletedAt = del ? del : "";

        s.totalClasses = sqlite3_column_int(stmt, 12);
        s.presentClasses = sqlite3_column_int(stmt, 13);
        s.absentClasses = sqlite3_column_int(stmt, 14);
        s.lateClasses = sqlite3_column_int(stmt, 15);

        if (s.totalClasses > 0) {
            // Consistent calculation: (Present + Late * 0.5) / Total * 100 or standard (Present / Total) * 100
            // Rule 9 specifies: (Present Classes / Total Recorded Classes) * 100
            s.attendancePercentage = (static_cast<double>(s.presentClasses) / s.totalClasses) * 100.0;
        } else {
            s.attendancePercentage = 0.0;
        }

        result.push_back(s);
    }
    sqlite3_finalize(stmt);
    return result;
}

int StudentRepository::count(
    const std::string& search,
    const std::string& branch,
    const std::string& section,
    int semester,
    bool includeDeleted
) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    std::string sql = "SELECT COUNT(*) FROM students s WHERE 1=1";
    if (!includeDeleted) {
        sql += " AND s.deleted_at IS NULL";
    }
    if (!search.empty()) {
        sql += " AND (s.name LIKE ? OR s.enrollment_id LIKE ? OR s.roll_number LIKE ? OR s.email LIKE ?)";
    }
    if (!branch.empty()) {
        sql += " AND s.branch = ?";
    }
    if (!section.empty()) {
        sql += " AND s.section = ?";
    }
    if (semester > 0) {
        sql += " AND s.semester = ?";
    }
    sql += ";";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        return 0;
    }

    int paramIdx = 1;
    if (!search.empty()) {
        std::string pattern = "%" + search + "%";
        sqlite3_bind_text(stmt, paramIdx++, pattern.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, paramIdx++, pattern.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, paramIdx++, pattern.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, paramIdx++, pattern.c_str(), -1, SQLITE_TRANSIENT);
    }
    if (!branch.empty()) {
        sqlite3_bind_text(stmt, paramIdx++, branch.c_str(), -1, SQLITE_TRANSIENT);
    }
    if (!section.empty()) {
        sqlite3_bind_text(stmt, paramIdx++, section.c_str(), -1, SQLITE_TRANSIENT);
    }
    if (semester > 0) {
        sqlite3_bind_int(stmt, paramIdx++, semester);
    }

    int total = 0;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        total = sqlite3_column_int(stmt, 0);
    }
    sqlite3_finalize(stmt);
    return total;
}

std::optional<models::Student> StudentRepository::findById(int id, bool includeDeleted) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    std::string sql = R"(
        SELECT s.id, s.enrollment_id, s.name, s.roll_number, s.branch, s.section, s.semester,
               s.email, s.phone, s.created_at, s.updated_at, s.deleted_at,
               COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id), 0) AS total_classes,
               COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id AND a.status = 'Present'), 0) AS present_classes,
               COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id AND a.status = 'Absent'), 0) AS absent_classes,
               COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id AND a.status = 'Late'), 0) AS late_classes
        FROM students s
        WHERE s.id = ?
    )";
    if (!includeDeleted) {
        sql += " AND s.deleted_at IS NULL";
    }
    sql += " LIMIT 1;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        return std::nullopt;
    }

    sqlite3_bind_int(stmt, 1, id);

    std::optional<models::Student> result;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        models::Student s;
        s.id = sqlite3_column_int(stmt, 0);
        s.enrollmentId = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        s.name = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
        const char* rn = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        s.rollNumber = rn ? rn : "";
        s.branch = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        s.section = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        s.semester = sqlite3_column_int(stmt, 6);
        const char* em = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 7));
        s.email = em ? em : "";
        const char* ph = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 8));
        s.phone = ph ? ph : "";
        s.createdAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 9));
        s.updatedAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 10));
        const char* del = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 11));
        s.deletedAt = del ? del : "";

        s.totalClasses = sqlite3_column_int(stmt, 12);
        s.presentClasses = sqlite3_column_int(stmt, 13);
        s.absentClasses = sqlite3_column_int(stmt, 14);
        s.lateClasses = sqlite3_column_int(stmt, 15);

        if (s.totalClasses > 0) {
            s.attendancePercentage = (static_cast<double>(s.presentClasses) / s.totalClasses) * 100.0;
        } else {
            s.attendancePercentage = 0.0;
        }

        result = s;
    }
    sqlite3_finalize(stmt);
    return result;
}

std::optional<models::Student> StudentRepository::findByEnrollmentId(const std::string& enrollmentId) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "SELECT id, enrollment_id, name, roll_number, branch, section, semester, email, phone, created_at, updated_at, deleted_at FROM students WHERE enrollment_id = ? LIMIT 1;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return std::nullopt;
    }

    sqlite3_bind_text(stmt, 1, enrollmentId.c_str(), -1, SQLITE_TRANSIENT);

    std::optional<models::Student> result;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        models::Student s;
        s.id = sqlite3_column_int(stmt, 0);
        s.enrollmentId = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        s.name = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
        const char* rn = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        s.rollNumber = rn ? rn : "";
        s.branch = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        s.section = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        s.semester = sqlite3_column_int(stmt, 6);
        const char* em = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 7));
        s.email = em ? em : "";
        const char* ph = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 8));
        s.phone = ph ? ph : "";
        s.createdAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 9));
        s.updatedAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 10));
        const char* del = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 11));
        s.deletedAt = del ? del : "";
        result = s;
    }
    sqlite3_finalize(stmt);
    return result;
}

std::optional<models::Student> StudentRepository::findByRollNumber(const std::string& rollNumber) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "SELECT id, enrollment_id, name, roll_number, branch, section, semester, email, phone, created_at, updated_at, deleted_at FROM students WHERE roll_number = ? LIMIT 1;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return std::nullopt;
    }

    sqlite3_bind_text(stmt, 1, rollNumber.c_str(), -1, SQLITE_TRANSIENT);

    std::optional<models::Student> result;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        models::Student s;
        s.id = sqlite3_column_int(stmt, 0);
        s.enrollmentId = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        s.name = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
        const char* rn = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        s.rollNumber = rn ? rn : "";
        s.branch = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        s.section = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        s.semester = sqlite3_column_int(stmt, 6);
        const char* em = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 7));
        s.email = em ? em : "";
        const char* ph = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 8));
        s.phone = ph ? ph : "";
        s.createdAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 9));
        s.updatedAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 10));
        const char* del = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 11));
        s.deletedAt = del ? del : "";
        result = s;
    }
    sqlite3_finalize(stmt);
    return result;
}

bool StudentRepository::create(const models::Student& student, int& outId) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "INSERT INTO students (enrollment_id, name, roll_number, branch, section, semester, email, phone, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    std::string now = db.getCurrentTimestamp();
    sqlite3_bind_text(stmt, 1, student.enrollmentId.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, student.name.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 3, student.rollNumber.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 4, student.branch.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 5, student.section.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 6, student.semester);
    sqlite3_bind_text(stmt, 7, student.email.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 8, student.phone.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 9, now.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 10, now.c_str(), -1, SQLITE_TRANSIENT);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);

    if (rc == SQLITE_DONE) {
        outId = static_cast<int>(sqlite3_last_insert_rowid(db.getHandle()));
        return true;
    }
    return false;
}

bool StudentRepository::update(const models::Student& student) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "UPDATE students SET enrollment_id = ?, name = ?, roll_number = ?, branch = ?, section = ?, semester = ?, email = ?, phone = ?, updated_at = ? WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    std::string now = db.getCurrentTimestamp();
    sqlite3_bind_text(stmt, 1, student.enrollmentId.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, student.name.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 3, student.rollNumber.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 4, student.branch.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 5, student.section.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 6, student.semester);
    sqlite3_bind_text(stmt, 7, student.email.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 8, student.phone.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 9, now.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 10, student.id);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

bool StudentRepository::softDelete(int id) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "UPDATE students SET deleted_at = ?, updated_at = ? WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    std::string now = db.getCurrentTimestamp();
    sqlite3_bind_text(stmt, 1, now.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, now.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 3, id);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

bool StudentRepository::restore(int id) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "UPDATE students SET deleted_at = NULL, updated_at = ? WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    std::string now = db.getCurrentTimestamp();
    sqlite3_bind_text(stmt, 1, now.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 2, id);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

bool StudentRepository::hardDelete(int id) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "DELETE FROM students WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    sqlite3_bind_int(stmt, 1, id);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

int StudentRepository::countActive() {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "SELECT COUNT(*) FROM students WHERE deleted_at IS NULL;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return 0;
    }

    int total = 0;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        total = sqlite3_column_int(stmt, 0);
    }
    sqlite3_finalize(stmt);
    return total;
}

std::vector<models::Student> StudentRepository::getLowAttendanceStudents(double threshold) {
    auto all = findAll("", "", "", 0, false, 0, 0);
    std::vector<models::Student> low;
    for (const auto& s : all) {
        if (s.totalClasses > 0 && s.attendancePercentage < threshold) {
            low.push_back(s);
        }
    }
    return low;
}

} // namespace repositories
} // namespace attendx

