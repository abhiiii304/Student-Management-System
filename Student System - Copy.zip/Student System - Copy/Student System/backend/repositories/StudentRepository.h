#pragma once
#include "../models/Student.h"
#include <optional>
#include <vector>
#include <string>

namespace attendx {
namespace repositories {

class StudentRepository {
public:
    std::vector<models::Student> findAll(
        const std::string& search = "",
        const std::string& branch = "",
        const std::string& section = "",
        int semester = 0,
        bool includeDeleted = false,
        int limit = 100,
        int offset = 0
    );

    int count(
        const std::string& search = "",
        const std::string& branch = "",
        const std::string& section = "",
        int semester = 0,
        bool includeDeleted = false
    );

    std::optional<models::Student> findById(int id, bool includeDeleted = false);
    std::optional<models::Student> findByEnrollmentId(const std::string& enrollmentId);
    std::optional<models::Student> findByRollNumber(const std::string& rollNumber);

    bool create(const models::Student& student, int& outId);
    bool update(const models::Student& student);
    bool softDelete(int id);
    bool restore(int id);
    bool hardDelete(int id);

    int countActive();
    std::vector<models::Student> getLowAttendanceStudents(double threshold = 75.0);
};

} // namespace repositories
} // namespace attendx

