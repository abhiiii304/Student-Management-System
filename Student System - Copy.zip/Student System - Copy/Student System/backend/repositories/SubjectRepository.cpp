#include "SubjectRepository.h"
#include "../database/Database.h"
#include <sqlite3.h>

namespace attendx {
namespace repositories {

std::vector<models::Subject> SubjectRepository::findAll(
    const std::string& search,
    const std::string& branch,
    int semester,
    int classId
) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    std::string sql = R"(
        SELECT sub.id, sub.subject_name, sub.subject_code, sub.branch, sub.semester, sub.section,
               sub.faculty_name, sub.class_id, sub.created_at, sub.updated_at,
               (SELECT COUNT(DISTINCT s.id) FROM students s WHERE s.deleted_at IS NULL AND (
                   (sub.class_id IS NOT NULL AND s.branch = (SELECT c.branch FROM classes c WHERE c.id = sub.class_id) 
                    AND s.semester = (SELECT c.semester FROM classes c WHERE c.id = sub.class_id) 
                    AND s.section = (SELECT c.section FROM classes c WHERE c.id = sub.class_id))
                   OR (sub.class_id IS NULL AND s.branch = sub.branch AND s.semester = sub.semester AND (sub.section IS NULL OR sub.section = '' OR s.section = sub.section))
               )) AS student_count,
               (SELECT COUNT(DISTINCT a.attendance_date) FROM attendance a WHERE a.subject_id = sub.id) AS total_sessions,
               (SELECT CAST(SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS REAL) / NULLIF(COUNT(a.id), 0) * 100.0 FROM attendance a WHERE a.subject_id = sub.id) AS avg_att
        FROM subjects sub
        WHERE 1=1
    )";

    if (!search.empty()) {
        sql += " AND (sub.subject_name LIKE ? OR sub.subject_code LIKE ? OR sub.faculty_name LIKE ?)";
    }
    if (!branch.empty()) {
        sql += " AND sub.branch = ?";
    }
    if (semester > 0) {
        sql += " AND sub.semester = ?";
    }
    if (classId > 0) {
        sql += " AND sub.class_id = ?";
    }
    sql += " ORDER BY sub.semester ASC, sub.subject_code ASC;";

    sqlite3_stmt* stmt = nullptr;
    std::vector<models::Subject> result;
    if (sqlite3_prepare_v2(db.getHandle(), sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        return result;
    }

    int paramIdx = 1;
    if (!search.empty()) {
        std::string pattern = "%" + search + "%";
        sqlite3_bind_text(stmt, paramIdx++, pattern.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, paramIdx++, pattern.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, paramIdx++, pattern.c_str(), -1, SQLITE_TRANSIENT);
    }
    if (!branch.empty()) {
        sqlite3_bind_text(stmt, paramIdx++, branch.c_str(), -1, SQLITE_TRANSIENT);
    }
    if (semester > 0) {
        sqlite3_bind_int(stmt, paramIdx++, semester);
    }
    if (classId > 0) {
        sqlite3_bind_int(stmt, paramIdx++, classId);
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        models::Subject s;
        s.id = sqlite3_column_int(stmt, 0);
        s.subjectName = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        const char* sc = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
        s.subjectCode = sc ? sc : "";
        const char* br = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        s.branch = br ? br : "";
        s.semester = sqlite3_column_int(stmt, 4);
        const char* sec = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        s.section = sec ? sec : "";
        const char* fn = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 6));
        s.facultyName = fn ? fn : "";
        if (sqlite3_column_type(stmt, 7) != SQLITE_NULL) {
            s.classId = sqlite3_column_int(stmt, 7);
        } else {
            s.classId = 0;
        }
        s.createdAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 8));
        s.updatedAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 9));
        s.studentCount = sqlite3_column_int(stmt, 10);
        s.totalSessions = sqlite3_column_int(stmt, 11);
        if (sqlite3_column_type(stmt, 12) != SQLITE_NULL) {
            s.averageAttendance = sqlite3_column_double(stmt, 12);
        } else {
            s.averageAttendance = 0.0;
        }
        result.push_back(s);
    }
    sqlite3_finalize(stmt);
    return result;
}

std::optional<models::Subject> SubjectRepository::findById(int id) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = R"(
        SELECT sub.id, sub.subject_name, sub.subject_code, sub.branch, sub.semester, sub.section,
               sub.faculty_name, sub.class_id, sub.created_at, sub.updated_at,
               (SELECT COUNT(DISTINCT s.id) FROM students s WHERE s.deleted_at IS NULL AND (
                   (sub.class_id IS NOT NULL AND s.branch = (SELECT c.branch FROM classes c WHERE c.id = sub.class_id) 
                    AND s.semester = (SELECT c.semester FROM classes c WHERE c.id = sub.class_id) 
                    AND s.section = (SELECT c.section FROM classes c WHERE c.id = sub.class_id))
                   OR (sub.class_id IS NULL AND s.branch = sub.branch AND s.semester = sub.semester AND (sub.section IS NULL OR sub.section = '' OR s.section = sub.section))
               )) AS student_count,
               (SELECT COUNT(DISTINCT a.attendance_date) FROM attendance a WHERE a.subject_id = sub.id) AS total_sessions,
               (SELECT CAST(SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS REAL) / NULLIF(COUNT(a.id), 0) * 100.0 FROM attendance a WHERE a.subject_id = sub.id) AS avg_att
        FROM subjects sub
        WHERE sub.id = ?
        LIMIT 1;
    )";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return std::nullopt;
    }

    sqlite3_bind_int(stmt, 1, id);

    std::optional<models::Subject> result;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        models::Subject s;
        s.id = sqlite3_column_int(stmt, 0);
        s.subjectName = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        const char* sc = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
        s.subjectCode = sc ? sc : "";
        const char* br = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        s.branch = br ? br : "";
        s.semester = sqlite3_column_int(stmt, 4);
        const char* sec = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        s.section = sec ? sec : "";
        const char* fn = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 6));
        s.facultyName = fn ? fn : "";
        if (sqlite3_column_type(stmt, 7) != SQLITE_NULL) {
            s.classId = sqlite3_column_int(stmt, 7);
        } else {
            s.classId = 0;
        }
        s.createdAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 8));
        s.updatedAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 9));
        s.studentCount = sqlite3_column_int(stmt, 10);
        s.totalSessions = sqlite3_column_int(stmt, 11);
        if (sqlite3_column_type(stmt, 12) != SQLITE_NULL) {
            s.averageAttendance = sqlite3_column_double(stmt, 12);
        } else {
            s.averageAttendance = 0.0;
        }
        result = s;
    }
    sqlite3_finalize(stmt);
    return result;
}

std::optional<models::Subject> SubjectRepository::findByCode(const std::string& code) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "SELECT id, subject_name, subject_code, branch, semester, section, faculty_name, class_id, created_at, updated_at FROM subjects WHERE subject_code = ? LIMIT 1;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return std::nullopt;
    }

    sqlite3_bind_text(stmt, 1, code.c_str(), -1, SQLITE_TRANSIENT);

    std::optional<models::Subject> result;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        models::Subject s;
        s.id = sqlite3_column_int(stmt, 0);
        s.subjectName = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        const char* sc = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
        s.subjectCode = sc ? sc : "";
        const char* br = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        s.branch = br ? br : "";
        s.semester = sqlite3_column_int(stmt, 4);
        const char* sec = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        s.section = sec ? sec : "";
        const char* fn = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 6));
        s.facultyName = fn ? fn : "";
        if (sqlite3_column_type(stmt, 7) != SQLITE_NULL) {
            s.classId = sqlite3_column_int(stmt, 7);
        } else {
            s.classId = 0;
        }
        s.createdAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 8));
        s.updatedAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 9));
        result = s;
    }
    sqlite3_finalize(stmt);
    return result;
}

bool SubjectRepository::create(const models::Subject& subject, int& outId) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "INSERT INTO subjects (subject_name, subject_code, branch, semester, section, faculty_name, class_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    std::string now = db.getCurrentTimestamp();
    sqlite3_bind_text(stmt, 1, subject.subjectName.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, subject.subjectCode.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 3, subject.branch.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 4, subject.semester);
    sqlite3_bind_text(stmt, 5, subject.section.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 6, subject.facultyName.c_str(), -1, SQLITE_TRANSIENT);
    if (subject.classId > 0) {
        sqlite3_bind_int(stmt, 7, subject.classId);
    } else {
        sqlite3_bind_null(stmt, 7);
    }
    sqlite3_bind_text(stmt, 8, now.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 9, now.c_str(), -1, SQLITE_TRANSIENT);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);

    if (rc == SQLITE_DONE) {
        outId = static_cast<int>(sqlite3_last_insert_rowid(db.getHandle()));
        return true;
    }
    return false;
}

bool SubjectRepository::update(const models::Subject& subject) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "UPDATE subjects SET subject_name = ?, subject_code = ?, branch = ?, semester = ?, section = ?, faculty_name = ?, class_id = ?, updated_at = ? WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    std::string now = db.getCurrentTimestamp();
    sqlite3_bind_text(stmt, 1, subject.subjectName.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, subject.subjectCode.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 3, subject.branch.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 4, subject.semester);
    sqlite3_bind_text(stmt, 5, subject.section.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 6, subject.facultyName.c_str(), -1, SQLITE_TRANSIENT);
    if (subject.classId > 0) {
        sqlite3_bind_int(stmt, 7, subject.classId);
    } else {
        sqlite3_bind_null(stmt, 7);
    }
    sqlite3_bind_text(stmt, 8, now.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 9, subject.id);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

bool SubjectRepository::deleteById(int id) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "DELETE FROM subjects WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    sqlite3_bind_int(stmt, 1, id);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

int SubjectRepository::count() {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "SELECT COUNT(*) FROM subjects;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return 0;
    }

    int total = 0;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        total = sqlite3_column_int(stmt, 0);
    }
    sqlite3_finalize(stmt);
    return total;
}

} // namespace repositories
} // namespace attendx

