#pragma once
#include "../models/Subject.h"
#include <optional>
#include <vector>
#include <string>

namespace attendx {
namespace repositories {

class SubjectRepository {
public:
    std::vector<models::Subject> findAll(
        const std::string& search = "",
        const std::string& branch = "",
        int semester = 0,
        int classId = 0
    );

    std::optional<models::Subject> findById(int id);
    std::optional<models::Subject> findByCode(const std::string& code);

    bool create(const models::Subject& subject, int& outId);
    bool update(const models::Subject& subject);
    bool deleteById(int id);
    int count();
};

} // namespace repositories
} // namespace attendx

