#include "UserRepository.h"
#include "../database/Database.h"
#include <sqlite3.h>

namespace attendx {
namespace repositories {

std::optional<models::User> UserRepository::findByUsername(const std::string& username) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "SELECT id, username, password_hash, salt, role, created_at FROM users WHERE username = ? LIMIT 1;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return std::nullopt;
    }

    sqlite3_bind_text(stmt, 1, username.c_str(), -1, SQLITE_TRANSIENT);

    std::optional<models::User> user;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        models::User u;
        u.id = sqlite3_column_int(stmt, 0);
        u.username = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        u.passwordHash = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
        u.salt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        u.role = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        u.createdAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        user = u;
    }
    sqlite3_finalize(stmt);
    return user;
}

std::optional<models::User> UserRepository::findById(int id) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "SELECT id, username, password_hash, salt, role, created_at FROM users WHERE id = ? LIMIT 1;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return std::nullopt;
    }

    sqlite3_bind_int(stmt, 1, id);

    std::optional<models::User> user;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        models::User u;
        u.id = sqlite3_column_int(stmt, 0);
        u.username = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        u.passwordHash = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
        u.salt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        u.role = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        u.createdAt = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        user = u;
    }
    sqlite3_finalize(stmt);
    return user;
}

bool UserRepository::create(const models::User& user, int& outId) {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "INSERT INTO users (username, password_hash, salt, role, created_at) VALUES (?, ?, ?, ?, ?);";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    std::string now = db.getCurrentTimestamp();
    sqlite3_bind_text(stmt, 1, user.username.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, user.passwordHash.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 3, user.salt.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 4, user.role.empty() ? "admin" : user.role.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 5, now.c_str(), -1, SQLITE_TRANSIENT);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);

    if (rc == SQLITE_DONE) {
        outId = static_cast<int>(sqlite3_last_insert_rowid(db.getHandle()));
        return true;
    }
    return false;
}

int UserRepository::count() {
    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());

    const char* sql = "SELECT COUNT(*) FROM users;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return 0;
    }

    int total = 0;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        total = sqlite3_column_int(stmt, 0);
    }
    sqlite3_finalize(stmt);
    return total;
}

} // namespace repositories
} // namespace attendx

