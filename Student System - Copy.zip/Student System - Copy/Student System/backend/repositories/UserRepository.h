#pragma once
#include "../models/User.h"
#include <optional>
#include <vector>
#include <string>

namespace attendx {
namespace repositories {

class UserRepository {
public:
    std::optional<models::User> findByUsername(const std::string& username);
    std::optional<models::User> findById(int id);
    bool create(const models::User& user, int& outId);
    int count();
};

} // namespace repositories
} // namespace attendx

