#include "AttendanceRoutes.h"
#include "../utils/ResponseUtils.h"
#include "../utils/AuthUtils.h"

namespace attendx {
namespace routes {

void AttendanceRoutes::registerRoutes(httplib::Server& server, services::AttendanceService& attService) {
    // GET /api/attendance
    server.Get("/api/attendance", [&attService](const httplib::Request& req, httplib::Response& res) {
        std::string date = req.has_param("date") ? req.get_param_value("date") : "";
        int subjectId = req.has_param("subject_id") ? std::stoi(req.get_param_value("subject_id")) : 0;
        int classId = req.has_param("class_id") ? std::stoi(req.get_param_value("class_id")) : 0;
        int studentId = req.has_param("student_id") ? std::stoi(req.get_param_value("student_id")) : 0;

        auto list = attService.getAttendance(date, subjectId, classId, studentId);
        nlohmann::json items = nlohmann::json::array();
        for (const auto& a : list) {
            items.push_back(a.toJson());
        }
        utils::ResponseUtils::sendSuccess(res, "Attendance records retrieved", items);
    });

    // GET /api/attendance/summary
    server.Get("/api/attendance/summary", [&attService](const httplib::Request& req, httplib::Response& res) {
        std::string date = req.has_param("date") ? req.get_param_value("date") : "";
        int subjectId = req.has_param("subject_id") ? std::stoi(req.get_param_value("subject_id")) : 0;
        int classId = req.has_param("class_id") ? std::stoi(req.get_param_value("class_id")) : 0;

        auto sum = attService.getSummary(date, subjectId, classId);
        utils::ResponseUtils::sendSuccess(res, "Attendance summary calculated", sum.toJson());
    });

    // GET /api/attendance/student/:student_id
    server.Get(R"(/api/attendance/student/(\d+))", [&attService](const httplib::Request& req, httplib::Response& res) {
        int studentId = std::stoi(req.matches[1]);
        auto list = attService.getAttendance("", 0, 0, studentId);
        nlohmann::json items = nlohmann::json::array();
        for (const auto& a : list) {
            items.push_back(a.toJson());
        }
        utils::ResponseUtils::sendSuccess(res, "Student attendance retrieved", items);
    });

    // GET /api/attendance/:id
    server.Get(R"(/api/attendance/(\d+))", [&attService](const httplib::Request& req, httplib::Response& res) {
        int id = std::stoi(req.matches[1]);
        auto att = attService.getById(id);
        if (att) {
            utils::ResponseUtils::sendSuccess(res, "Attendance entry retrieved", att->toJson());
        } else {
            utils::ResponseUtils::sendNotFound(res, "Attendance entry not found");
        }
    });

    // POST /api/attendance (Single record)
    server.Post("/api/attendance", [&attService](const httplib::Request& req, httplib::Response& res) {
        utils::SessionData session;
        if (!utils::AuthUtils::requireAuth(req, res, session)) return;

        try {
            auto body = nlohmann::json::parse(req.body);
            auto result = attService.recordSingle(body);
            if (result.success) {
                utils::ResponseUtils::sendCreated(res, result.message, result.data);
            } else {
                utils::ResponseUtils::sendError(res, result.message, result.errors);
            }
        } catch (const std::exception& e) {
            utils::ResponseUtils::sendError(res, "Invalid JSON payload");
        }
    });

    // PUT /api/attendance/:id
    server.Put(R"(/api/attendance/(\d+))", [&attService](const httplib::Request& req, httplib::Response& res) {
        utils::SessionData session;
        if (!utils::AuthUtils::requireAuth(req, res, session)) return;

        int id = std::stoi(req.matches[1]);
        try {
            auto body = nlohmann::json::parse(req.body);
            std::string status = body.value("status", "");
            auto result = attService.updateSingle(id, status);
            if (result.success) {
                utils::ResponseUtils::sendSuccess(res, result.message, result.data);
            } else {
                utils::ResponseUtils::sendError(res, result.message, result.errors);
            }
        } catch (const std::exception& e) {
            utils::ResponseUtils::sendError(res, "Invalid JSON payload");
        }
    });

    // POST /api/attendance/bulk
    server.Post("/api/attendance/bulk", [&attService](const httplib::Request& req, httplib::Response& res) {
        utils::SessionData session;
        if (!utils::AuthUtils::requireAuth(req, res, session)) return;

        try {
            auto body = nlohmann::json::parse(req.body);
            auto result = attService.bulkRecord(body);
            if (result.success) {
                utils::ResponseUtils::sendSuccess(res, result.message, result.data);
            } else {
                utils::ResponseUtils::sendError(res, result.message, result.errors);
            }
        } catch (const std::exception& e) {
            utils::ResponseUtils::sendError(res, "Invalid JSON payload");
        }
    });
}

} // namespace routes
} // namespace attendx

