#pragma once
#include "httplib.h"
#include "../services/AttendanceService.h"

namespace attendx {
namespace routes {

class AttendanceRoutes {
public:
    static void registerRoutes(httplib::Server& server, services::AttendanceService& attService);
};

} // namespace routes
} // namespace attendx

