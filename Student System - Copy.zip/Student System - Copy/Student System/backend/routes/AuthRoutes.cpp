#include "AuthRoutes.h"
#include "../utils/ResponseUtils.h"
#include "../utils/AuthUtils.h"

namespace attendx {
namespace routes {

void AuthRoutes::registerRoutes(httplib::Server& server, services::AuthService& authService) {
    server.Post("/api/auth/login", [&authService](const httplib::Request& req, httplib::Response& res) {
        try {
            auto body = nlohmann::json::parse(req.body);
            std::string username = body.value("username", "");
            std::string password = body.value("password", "");

            auto result = authService.login(username, password);
            if (result.success) {
                nlohmann::json data;
                data["token"] = result.token;
                data["user"] = result.user;

                // Also set Cookie for browser convenience
                res.set_header("Set-Cookie", "attendx_token=" + result.token + "; Path=/; HttpOnly; SameSite=Lax");
                utils::ResponseUtils::sendSuccess(res, result.message, data, 200);
            } else {
                utils::ResponseUtils::sendUnauthorized(res, result.message);
            }
        } catch (const std::exception& e) {
            utils::ResponseUtils::sendError(res, "Malformed JSON request body");
        }
    });

    server.Post("/api/auth/logout", [&authService](const httplib::Request& req, httplib::Response& res) {
        std::string token = utils::AuthUtils::extractToken(req);
        if (!token.empty()) {
            authService.logout(token);
        }
        res.set_header("Set-Cookie", "attendx_token=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT");
        utils::ResponseUtils::sendSuccess(res, "Logged out successfully");
    });

    server.Get("/api/auth/me", [](const httplib::Request& req, httplib::Response& res) {
        utils::SessionData session;
        if (!utils::AuthUtils::requireAuth(req, res, session)) {
            return;
        }

        nlohmann::json data;
        data["id"] = session.userId;
        data["username"] = session.username;
        data["role"] = session.role;
        utils::ResponseUtils::sendSuccess(res, "User authenticated", data);
    });

    server.Post("/api/auth/change-password", [&authService](const httplib::Request& req, httplib::Response& res) {
        utils::SessionData session;
        if (!utils::AuthUtils::requireAuth(req, res, session)) {
            return;
        }

        try {
            auto body = nlohmann::json::parse(req.body);
            std::string oldPass = body.value("old_password", "");
            std::string newPass = body.value("new_password", "");

            std::string err;
            if (authService.changePassword(session.userId, oldPass, newPass, err)) {
                utils::ResponseUtils::sendSuccess(res, "Password changed successfully");
            } else {
                utils::ResponseUtils::sendError(res, err);
            }
        } catch (const std::exception& e) {
            utils::ResponseUtils::sendError(res, "Malformed JSON request body");
        }
    });
}

} // namespace routes
} // namespace attendx

