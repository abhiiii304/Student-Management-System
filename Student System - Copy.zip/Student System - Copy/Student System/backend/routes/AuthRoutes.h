#pragma once
#include "httplib.h"
#include "../services/AuthService.h"

namespace attendx {
namespace routes {

class AuthRoutes {
public:
    static void registerRoutes(httplib::Server& server, services::AuthService& authService);
};

} // namespace routes
} // namespace attendx

