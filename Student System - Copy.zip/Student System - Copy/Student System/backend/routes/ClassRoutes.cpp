#include "ClassRoutes.h"
#include "../utils/ResponseUtils.h"
#include "../utils/AuthUtils.h"

namespace attendx {
namespace routes {

void ClassRoutes::registerRoutes(httplib::Server& server, services::ClassService& classService) {
    server.Get("/api/classes", [&classService](const httplib::Request& req, httplib::Response& res) {
        std::string search = req.has_param("search") ? req.get_param_value("search") : "";
        std::string branch = req.has_param("branch") ? req.get_param_value("branch") : "";
        int semester = req.has_param("semester") ? std::stoi(req.get_param_value("semester")) : 0;

        auto list = classService.getAllClasses(search, branch, semester);
        nlohmann::json items = nlohmann::json::array();
        for (const auto& c : list) {
            items.push_back(c.toJson());
        }
        utils::ResponseUtils::sendSuccess(res, "Classes retrieved successfully", items);
    });

    server.Get(R"(/api/classes/(\d+))", [&classService](const httplib::Request& req, httplib::Response& res) {
        int id = std::stoi(req.matches[1]);
        auto cls = classService.getClassById(id);
        if (cls) {
            utils::ResponseUtils::sendSuccess(res, "Class details retrieved", cls->toJson());
        } else {
            utils::ResponseUtils::sendNotFound(res, "Class not found");
        }
    });

    server.Post("/api/classes", [&classService](const httplib::Request& req, httplib::Response& res) {
        utils::SessionData session;
        if (!utils::AuthUtils::requireAuth(req, res, session)) return;

        try {
            auto body = nlohmann::json::parse(req.body);
            auto result = classService.createClass(body);
            if (result.success) {
                utils::ResponseUtils::sendCreated(res, result.message, result.data);
            } else {
                utils::ResponseUtils::sendError(res, result.message, result.errors);
            }
        } catch (const std::exception& e) {
            utils::ResponseUtils::sendError(res, "Invalid JSON payload");
        }
    });

    server.Put(R"(/api/classes/(\d+))", [&classService](const httplib::Request& req, httplib::Response& res) {
        utils::SessionData session;
        if (!utils::AuthUtils::requireAuth(req, res, session)) return;

        int id = std::stoi(req.matches[1]);
        try {
            auto body = nlohmann::json::parse(req.body);
            auto result = classService.updateClass(id, body);
            if (result.success) {
                utils::ResponseUtils::sendSuccess(res, result.message, result.data);
            } else {
                utils::ResponseUtils::sendError(res, result.message, result.errors);
            }
        } catch (const std::exception& e) {
            utils::ResponseUtils::sendError(res, "Invalid JSON payload");
        }
    });

    server.Delete(R"(/api/classes/(\d+))", [&classService](const httplib::Request& req, httplib::Response& res) {
        utils::SessionData session;
        if (!utils::AuthUtils::requireAuth(req, res, session)) return;

        int id = std::stoi(req.matches[1]);
        auto result = classService.deleteClass(id);
        if (result.success) {
            utils::ResponseUtils::sendSuccess(res, result.message);
        } else {
            utils::ResponseUtils::sendError(res, result.message);
        }
    });
}

} // namespace routes
} // namespace attendx

