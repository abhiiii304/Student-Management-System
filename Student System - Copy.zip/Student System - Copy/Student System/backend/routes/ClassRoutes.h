#pragma once
#include "httplib.h"
#include "../services/ClassService.h"

namespace attendx {
namespace routes {

class ClassRoutes {
public:
    static void registerRoutes(httplib::Server& server, services::ClassService& classService);
};

} // namespace routes
} // namespace attendx

