#include "DashboardRoutes.h"
#include "../utils/ResponseUtils.h"
#include <chrono>
#include <ctime>
#include <iomanip>
#include <sstream>

namespace attendx {
namespace routes {

namespace {
std::string getTodayDate() {
    auto now = std::chrono::system_clock::now();
    auto in_time_t = std::chrono::system_clock::to_time_t(now);
    std::stringstream ss;
    ss << std::put_time(std::gmtime(&in_time_t), "%Y-%m-%d");
    return ss.str();
}
}

void DashboardRoutes::registerRoutes(
    httplib::Server& server,
    services::AttendanceService& attService,
    services::StudentService& studentService
) {
    // GET /api/dashboard/stats
    server.Get("/api/dashboard/stats", [&attService](const httplib::Request& req, httplib::Response& res) {
        std::string today = req.has_param("date") ? req.get_param_value("date") : getTodayDate();
        auto stats = attService.getDashboardStats(today);
        utils::ResponseUtils::sendSuccess(res, "Dashboard stats retrieved", stats.toJson());
    });

    // GET /api/dashboard/recent-activity
    server.Get("/api/dashboard/recent-activity", [&attService](const httplib::Request& req, httplib::Response& res) {
        int limit = req.has_param("limit") ? std::stoi(req.get_param_value("limit")) : 10;
        auto activity = attService.getRecentActivity(limit);
        nlohmann::json items = nlohmann::json::array();
        for (const auto& a : activity) {
            items.push_back(a.toJson());
        }
        utils::ResponseUtils::sendSuccess(res, "Recent activity retrieved", items);
    });

    // GET /api/dashboard/attendance-trends
    server.Get("/api/dashboard/attendance-trends", [&attService](const httplib::Request& req, httplib::Response& res) {
        std::string range = req.has_param("range") ? req.get_param_value("range") : "daily";
        auto trends = attService.getTrends(range);
        nlohmann::json items = nlohmann::json::array();
        for (const auto& t : trends) {
            items.push_back(t.toJson());
        }
        utils::ResponseUtils::sendSuccess(res, "Attendance trends retrieved", items);
    });

    // GET /api/dashboard/attendance-distribution
    server.Get("/api/dashboard/attendance-distribution", [&attService](const httplib::Request& req, httplib::Response& res) {
        auto dist = attService.getDistribution();
        utils::ResponseUtils::sendSuccess(res, "Attendance distribution retrieved", dist.toJson());
    });
}

} // namespace routes
} // namespace attendx

