#pragma once
#include "httplib.h"
#include "../services/AttendanceService.h"
#include "../services/StudentService.h"

namespace attendx {
namespace routes {

class DashboardRoutes {
public:
    static void registerRoutes(
        httplib::Server& server,
        services::AttendanceService& attService,
        services::StudentService& studentService
    );
};

} // namespace routes
} // namespace attendx

