#include "ReportRoutes.h"
#include "../utils/ResponseUtils.h"

namespace attendx {
namespace routes {

void ReportRoutes::registerRoutes(httplib::Server& server, services::ReportService& reportService) {
    // GET /api/reports/student
    server.Get("/api/reports/student", [&reportService](const httplib::Request& req, httplib::Response& res) {
        int studentId = req.has_param("student_id") ? std::stoi(req.get_param_value("student_id")) : 0;
        int classId = req.has_param("class_id") ? std::stoi(req.get_param_value("class_id")) : 0;
        int subjectId = req.has_param("subject_id") ? std::stoi(req.get_param_value("subject_id")) : 0;
        std::string startDate = req.has_param("start_date") ? req.get_param_value("start_date") : "";
        std::string endDate = req.has_param("end_date") ? req.get_param_value("end_date") : "";

        auto report = reportService.getStudentReport(studentId, classId, subjectId, startDate, endDate);
        utils::ResponseUtils::sendSuccess(res, "Student attendance report generated", report);
    });

    // GET /api/reports/class
    server.Get("/api/reports/class", [&reportService](const httplib::Request& req, httplib::Response& res) {
        int classId = req.has_param("class_id") ? std::stoi(req.get_param_value("class_id")) : 0;
        std::string startDate = req.has_param("start_date") ? req.get_param_value("start_date") : "";
        std::string endDate = req.has_param("end_date") ? req.get_param_value("end_date") : "";

        auto report = reportService.getClassReport(classId, startDate, endDate);
        utils::ResponseUtils::sendSuccess(res, "Class attendance report generated", report);
    });

    // GET /api/reports/subject
    server.Get("/api/reports/subject", [&reportService](const httplib::Request& req, httplib::Response& res) {
        int subjectId = req.has_param("subject_id") ? std::stoi(req.get_param_value("subject_id")) : 0;
        std::string startDate = req.has_param("start_date") ? req.get_param_value("start_date") : "";
        std::string endDate = req.has_param("end_date") ? req.get_param_value("end_date") : "";

        auto report = reportService.getSubjectReport(subjectId, startDate, endDate);
        utils::ResponseUtils::sendSuccess(res, "Subject attendance report generated", report);
    });

    // GET /api/reports/daily
    server.Get("/api/reports/daily", [&reportService](const httplib::Request& req, httplib::Response& res) {
        std::string date = req.has_param("date") ? req.get_param_value("date") : "";
        int classId = req.has_param("class_id") ? std::stoi(req.get_param_value("class_id")) : 0;
        int subjectId = req.has_param("subject_id") ? std::stoi(req.get_param_value("subject_id")) : 0;

        auto report = reportService.getDailyReport(date, classId, subjectId);
        utils::ResponseUtils::sendSuccess(res, "Daily report generated", report);
    });

    // GET /api/reports/monthly
    server.Get("/api/reports/monthly", [&reportService](const httplib::Request& req, httplib::Response& res) {
        std::string yearMonth = req.has_param("month") ? req.get_param_value("month") : "";
        int classId = req.has_param("class_id") ? std::stoi(req.get_param_value("class_id")) : 0;
        int subjectId = req.has_param("subject_id") ? std::stoi(req.get_param_value("subject_id")) : 0;

        auto report = reportService.getMonthlyReport(yearMonth, classId, subjectId);
        utils::ResponseUtils::sendSuccess(res, "Monthly report generated", report);
    });

    // GET /api/reports/low-attendance
    server.Get("/api/reports/low-attendance", [&reportService](const httplib::Request& req, httplib::Response& res) {
        double threshold = req.has_param("threshold") ? std::stod(req.get_param_value("threshold")) : 75.0;
        auto report = reportService.getLowAttendanceReport(threshold);
        utils::ResponseUtils::sendSuccess(res, "Low attendance students list", report);
    });

    // GET /api/reports/export (CSV export)
    server.Get("/api/reports/export", [&reportService](const httplib::Request& req, httplib::Response& res) {
        std::string reportType = req.has_param("type") ? req.get_param_value("type") : "student";
        int studentId = req.has_param("student_id") ? std::stoi(req.get_param_value("student_id")) : 0;
        int classId = req.has_param("class_id") ? std::stoi(req.get_param_value("class_id")) : 0;
        int subjectId = req.has_param("subject_id") ? std::stoi(req.get_param_value("subject_id")) : 0;
        std::string startDate = req.has_param("start_date") ? req.get_param_value("start_date") : "";
        std::string endDate = req.has_param("end_date") ? req.get_param_value("end_date") : "";
        std::string date = req.has_param("date") ? req.get_param_value("date") : "";
        std::string month = req.has_param("month") ? req.get_param_value("month") : "";

        nlohmann::json data;
        if (reportType == "class") {
            data = reportService.getClassReport(classId, startDate, endDate);
        } else if (reportType == "subject") {
            data = reportService.getSubjectReport(subjectId, startDate, endDate);
        } else if (reportType == "daily") {
            data = reportService.getDailyReport(date, classId, subjectId);
        } else if (reportType == "monthly") {
            data = reportService.getMonthlyReport(month, classId, subjectId);
        } else {
            data = reportService.getStudentReport(studentId, classId, subjectId, startDate, endDate);
        }

        std::string csv = reportService.exportToCsv(reportType, data);
        res.set_content(csv, "text/csv");
        res.set_header("Content-Disposition", "attachment; filename=\"attendx_report_" + reportType + ".csv\"");
    });
}

} // namespace routes
} // namespace attendx

