#pragma once
#include "httplib.h"
#include "../services/ReportService.h"

namespace attendx {
namespace routes {

class ReportRoutes {
public:
    static void registerRoutes(httplib::Server& server, services::ReportService& reportService);
};

} // namespace routes
} // namespace attendx

