#include "SeedRoutes.h"
#include "../utils/ResponseUtils.h"

namespace attendx {
namespace routes {

void SeedRoutes::registerRoutes(httplib::Server& server, services::SeedService& seedService) {
    server.Post("/api/seed", [&seedService](const httplib::Request& req, httplib::Response& res) {
        bool force = req.has_param("force") && req.get_param_value("force") == "true";
        std::string msg;
        if (seedService.seedDemoData(force, &msg)) {
            utils::ResponseUtils::sendSuccess(res, msg);
        } else {
            utils::ResponseUtils::sendError(res, "Failed to seed demo data");
        }
    });
}

} // namespace routes
} // namespace attendx

