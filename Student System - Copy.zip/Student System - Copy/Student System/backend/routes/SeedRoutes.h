#pragma once
#include "httplib.h"
#include "../services/SeedService.h"

namespace attendx {
namespace routes {

class SeedRoutes {
public:
    static void registerRoutes(httplib::Server& server, services::SeedService& seedService);
};

} // namespace routes
} // namespace attendx

