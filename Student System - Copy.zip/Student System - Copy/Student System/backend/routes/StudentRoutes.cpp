#include "StudentRoutes.h"
#include "../utils/ResponseUtils.h"
#include "../utils/AuthUtils.h"
#include <regex>

namespace attendx {
namespace routes {

void StudentRoutes::registerRoutes(httplib::Server& server, services::StudentService& studentService) {
    // GET /api/students
    server.Get("/api/students", [&studentService](const httplib::Request& req, httplib::Response& res) {
        std::string search = req.has_param("search") ? req.get_param_value("search") : "";
        std::string branch = req.has_param("branch") ? req.get_param_value("branch") : "";
        std::string section = req.has_param("section") ? req.get_param_value("section") : "";
        int semester = req.has_param("semester") ? std::stoi(req.get_param_value("semester")) : 0;
        bool includeDeleted = req.has_param("include_deleted") && req.get_param_value("include_deleted") == "true";
        int limit = req.has_param("limit") ? std::stoi(req.get_param_value("limit")) : 50;
        int page = req.has_param("page") ? std::stoi(req.get_param_value("page")) : 1;
        int offset = (page > 0) ? (page - 1) * limit : 0;

        auto list = studentService.getAllStudents(search, branch, section, semester, includeDeleted, limit, offset);
        int total = studentService.getStudentCount(search, branch, section, semester, includeDeleted);

        nlohmann::json data;
        nlohmann::json items = nlohmann::json::array();
        for (const auto& s : list) {
            items.push_back(s.toJson());
        }
        data["students"] = items;
        data["total"] = total;
        data["page"] = page;
        data["limit"] = limit;
        data["total_pages"] = (total + limit - 1) / (limit > 0 ? limit : 1);

        utils::ResponseUtils::sendSuccess(res, "Students retrieved successfully", data);
    });

    // GET /api/students/:id
    server.Get(R"(/api/students/(\d+))", [&studentService](const httplib::Request& req, httplib::Response& res) {
        int id = std::stoi(req.matches[1]);
        auto studentOpt = studentService.getStudentById(id, true);
        if (studentOpt) {
            utils::ResponseUtils::sendSuccess(res, "Student details retrieved", studentOpt->toJson());
        } else {
            utils::ResponseUtils::sendNotFound(res, "Student not found");
        }
    });

    // POST /api/students
    server.Post("/api/students", [&studentService](const httplib::Request& req, httplib::Response& res) {
        utils::SessionData session;
        if (!utils::AuthUtils::requireAuth(req, res, session)) return;

        try {
            auto body = nlohmann::json::parse(req.body);
            auto result = studentService.createStudent(body);
            if (result.success) {
                utils::ResponseUtils::sendCreated(res, result.message, result.data);
            } else {
                utils::ResponseUtils::sendError(res, result.message, result.errors);
            }
        } catch (const std::exception& e) {
            utils::ResponseUtils::sendError(res, "Invalid JSON payload");
        }
    });

    // PUT /api/students/:id
    server.Put(R"(/api/students/(\d+))", [&studentService](const httplib::Request& req, httplib::Response& res) {
        utils::SessionData session;
        if (!utils::AuthUtils::requireAuth(req, res, session)) return;

        int id = std::stoi(req.matches[1]);
        try {
            auto body = nlohmann::json::parse(req.body);
            auto result = studentService.updateStudent(id, body);
            if (result.success) {
                utils::ResponseUtils::sendSuccess(res, result.message, result.data);
            } else {
                utils::ResponseUtils::sendError(res, result.message, result.errors);
            }
        } catch (const std::exception& e) {
            utils::ResponseUtils::sendError(res, "Invalid JSON payload");
        }
    });

    // DELETE /api/students/:id
    server.Delete(R"(/api/students/(\d+))", [&studentService](const httplib::Request& req, httplib::Response& res) {
        utils::SessionData session;
        if (!utils::AuthUtils::requireAuth(req, res, session)) return;

        int id = std::stoi(req.matches[1]);
        bool hard = req.has_param("hard") && req.get_param_value("hard") == "true";
        auto result = studentService.deleteStudent(id, hard);
        if (result.success) {
            utils::ResponseUtils::sendSuccess(res, result.message);
        } else {
            utils::ResponseUtils::sendError(res, result.message);
        }
    });

    // POST /api/students/:id/restore
    server.Post(R"(/api/students/(\d+)/restore)", [&studentService](const httplib::Request& req, httplib::Response& res) {
        utils::SessionData session;
        if (!utils::AuthUtils::requireAuth(req, res, session)) return;

        int id = std::stoi(req.matches[1]);
        auto result = studentService.restoreStudent(id);
        if (result.success) {
            utils::ResponseUtils::sendSuccess(res, result.message);
        } else {
            utils::ResponseUtils::sendError(res, result.message);
        }
    });
}

} // namespace routes
} // namespace attendx

