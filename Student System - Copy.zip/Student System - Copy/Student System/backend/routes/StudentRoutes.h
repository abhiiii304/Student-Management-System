#pragma once
#include "httplib.h"
#include "../services/StudentService.h"

namespace attendx {
namespace routes {

class StudentRoutes {
public:
    static void registerRoutes(httplib::Server& server, services::StudentService& studentService);
};

} // namespace routes
} // namespace attendx

