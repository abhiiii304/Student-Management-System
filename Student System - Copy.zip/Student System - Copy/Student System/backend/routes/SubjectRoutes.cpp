#include "SubjectRoutes.h"
#include "../utils/ResponseUtils.h"
#include "../utils/AuthUtils.h"

namespace attendx {
namespace routes {

void SubjectRoutes::registerRoutes(httplib::Server& server, services::SubjectService& subjectService) {
    server.Get("/api/subjects", [&subjectService](const httplib::Request& req, httplib::Response& res) {
        std::string search = req.has_param("search") ? req.get_param_value("search") : "";
        std::string branch = req.has_param("branch") ? req.get_param_value("branch") : "";
        int semester = req.has_param("semester") ? std::stoi(req.get_param_value("semester")) : 0;
        int classId = req.has_param("class_id") ? std::stoi(req.get_param_value("class_id")) : 0;

        auto list = subjectService.getAllSubjects(search, branch, semester, classId);
        nlohmann::json items = nlohmann::json::array();
        for (const auto& s : list) {
            items.push_back(s.toJson());
        }
        utils::ResponseUtils::sendSuccess(res, "Subjects retrieved successfully", items);
    });

    server.Get(R"(/api/subjects/(\d+))", [&subjectService](const httplib::Request& req, httplib::Response& res) {
        int id = std::stoi(req.matches[1]);
        auto sub = subjectService.getSubjectById(id);
        if (sub) {
            utils::ResponseUtils::sendSuccess(res, "Subject details retrieved", sub->toJson());
        } else {
            utils::ResponseUtils::sendNotFound(res, "Subject not found");
        }
    });

    server.Post("/api/subjects", [&subjectService](const httplib::Request& req, httplib::Response& res) {
        utils::SessionData session;
        if (!utils::AuthUtils::requireAuth(req, res, session)) return;

        try {
            auto body = nlohmann::json::parse(req.body);
            auto result = subjectService.createSubject(body);
            if (result.success) {
                utils::ResponseUtils::sendCreated(res, result.message, result.data);
            } else {
                utils::ResponseUtils::sendError(res, result.message, result.errors);
            }
        } catch (const std::exception& e) {
            utils::ResponseUtils::sendError(res, "Invalid JSON payload");
        }
    });

    server.Put(R"(/api/subjects/(\d+))", [&subjectService](const httplib::Request& req, httplib::Response& res) {
        utils::SessionData session;
        if (!utils::AuthUtils::requireAuth(req, res, session)) return;

        int id = std::stoi(req.matches[1]);
        try {
            auto body = nlohmann::json::parse(req.body);
            auto result = subjectService.updateSubject(id, body);
            if (result.success) {
                utils::ResponseUtils::sendSuccess(res, result.message, result.data);
            } else {
                utils::ResponseUtils::sendError(res, result.message, result.errors);
            }
        } catch (const std::exception& e) {
            utils::ResponseUtils::sendError(res, "Invalid JSON payload");
        }
    });

    server.Delete(R"(/api/subjects/(\d+))", [&subjectService](const httplib::Request& req, httplib::Response& res) {
        utils::SessionData session;
        if (!utils::AuthUtils::requireAuth(req, res, session)) return;

        int id = std::stoi(req.matches[1]);
        auto result = subjectService.deleteSubject(id);
        if (result.success) {
            utils::ResponseUtils::sendSuccess(res, result.message);
        } else {
            utils::ResponseUtils::sendError(res, result.message);
        }
    });
}

} // namespace routes
} // namespace attendx

