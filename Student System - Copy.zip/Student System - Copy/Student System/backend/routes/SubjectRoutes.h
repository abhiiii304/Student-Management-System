#pragma once
#include "httplib.h"
#include "../services/SubjectService.h"

namespace attendx {
namespace routes {

class SubjectRoutes {
public:
    static void registerRoutes(httplib::Server& server, services::SubjectService& subjectService);
};

} // namespace routes
} // namespace attendx

