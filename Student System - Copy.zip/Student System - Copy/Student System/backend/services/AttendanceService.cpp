#include "AttendanceService.h"
#include "../utils/Validation.h"
#include <iostream>

namespace attendx {
namespace services {

AttendanceService::AttendanceService(repositories::AttendanceRepository& attRepo) : attRepo_(attRepo) {}

std::vector<models::Attendance> AttendanceService::getAttendance(
    const std::string& date,
    int subjectId,
    int classId,
    int studentId
) {
    return attRepo_.findByFilters(date, subjectId, classId, studentId);
}

std::optional<models::Attendance> AttendanceService::getById(int id) {
    return attRepo_.findById(id);
}

ServiceResult AttendanceService::recordSingle(const nlohmann::json& body) {
    ServiceResult res;
    int studentId = body.value("student_id", 0);
    int subjectId = body.value("subject_id", 0);
    int classId = body.value("class_id", 0);
    std::string date = body.value("attendance_date", "");
    std::string status = body.value("status", "Present");

    nlohmann::json errors = nlohmann::json::object();
    if (studentId <= 0) errors["student_id"] = "Valid student ID is required";
    if (subjectId <= 0) errors["subject_id"] = "Valid subject ID is required";
    if (!utils::Validation::isValidDate(date)) errors["attendance_date"] = "Valid date (YYYY-MM-DD) is required";
    if (!utils::Validation::isValidStatus(status)) errors["status"] = "Status must be Present, Absent, or Late";

    if (!errors.empty()) {
        res.success = false;
        res.message = "Validation failed";
        res.errors = errors;
        return res;
    }

    int outId = 0;
    if (attRepo_.record(studentId, subjectId, classId, date, status, outId)) {
        res.success = true;
        res.message = "Attendance recorded successfully";
        res.data = {
            {"id", outId},
            {"student_id", studentId},
            {"subject_id", subjectId},
            {"attendance_date", date},
            {"status", status}
        };
    } else {
        res.success = false;
        res.message = "Failed to record attendance";
    }
    return res;
}

ServiceResult AttendanceService::updateSingle(int id, const std::string& status) {
    ServiceResult res;
    if (!utils::Validation::isValidStatus(status)) {
        res.success = false;
        res.message = "Status must be Present, Absent, or Late";
        return res;
    }

    if (attRepo_.updateStatus(id, status)) {
        res.success = true;
        res.message = "Attendance status updated successfully";
        res.data = {{"id", id}, {"status", status}};
    } else {
        res.success = false;
        res.message = "Failed to update attendance";
    }
    return res;
}

ServiceResult AttendanceService::bulkRecord(const nlohmann::json& body) {
    ServiceResult res;
    int subjectId = body.value("subject_id", 0);
    int classId = body.value("class_id", 0);
    std::string date = body.value("attendance_date", "");

    if (subjectId <= 0) {
        res.success = false;
        res.message = "Subject ID is required for bulk attendance";
        return res;
    }
    if (!utils::Validation::isValidDate(date)) {
        res.success = false;
        res.message = "Valid attendance date (YYYY-MM-DD) is required";
        return res;
    }

    if (!body.contains("records") || !body["records"].is_array() || body["records"].empty()) {
        res.success = false;
        res.message = "Records list is required and cannot be empty";
        return res;
    }

    std::vector<models::Attendance> recs;
    for (const auto& item : body["records"]) {
        models::Attendance a;
        a.studentId = item.value("student_id", 0);
        a.subjectId = subjectId;
        a.classId = classId;
        a.attendanceDate = date;
        a.status = item.value("status", "Present");

        if (a.studentId > 0 && utils::Validation::isValidStatus(a.status)) {
            recs.push_back(a);
        }
    }

    int updated = 0;
    int inserted = 0;
    if (attRepo_.bulkRecord(recs, updated, inserted)) {
        res.success = true;
        res.message = "Attendance recorded successfully for " + std::to_string(recs.size()) + " students";
        res.data = {
            {"total_processed", recs.size()},
            {"inserted", inserted},
            {"updated", updated},
            {"date", date},
            {"subject_id", subjectId}
        };
    } else {
        res.success = false;
        res.message = "Failed to save bulk attendance";
    }
    return res;
}

repositories::AttendanceSummary AttendanceService::getSummary(const std::string& date, int subjectId, int classId) {
    return attRepo_.getSummary(date, subjectId, classId);
}

repositories::DashboardStats AttendanceService::getDashboardStats(const std::string& todayDate) {
    return attRepo_.getDashboardStats(todayDate);
}

std::vector<repositories::TrendPoint> AttendanceService::getTrends(const std::string& range) {
    return attRepo_.getAttendanceTrends(range, 7);
}

repositories::AttendanceSummary AttendanceService::getDistribution() {
    return attRepo_.getAttendanceDistribution();
}

std::vector<models::Attendance> AttendanceService::getRecentActivity(int limit) {
    return attRepo_.getRecentActivity(limit);
}

} // namespace services
} // namespace attendx

