#pragma once
#include "../repositories/AttendanceRepository.h"
#include "ClassService.h" // for ServiceResult
#include "json.hpp"
#include <string>
#include <vector>
#include <optional>

namespace attendx {
namespace services {

class AttendanceService {
public:
    explicit AttendanceService(repositories::AttendanceRepository& attRepo);

    std::vector<models::Attendance> getAttendance(
        const std::string& date = "",
        int subjectId = 0,
        int classId = 0,
        int studentId = 0
    );

    std::optional<models::Attendance> getById(int id);
    ServiceResult recordSingle(const nlohmann::json& body);
    ServiceResult updateSingle(int id, const std::string& status);
    ServiceResult bulkRecord(const nlohmann::json& body);

    repositories::AttendanceSummary getSummary(const std::string& date = "", int subjectId = 0, int classId = 0);
    repositories::DashboardStats getDashboardStats(const std::string& todayDate);
    std::vector<repositories::TrendPoint> getTrends(const std::string& range = "daily");
    repositories::AttendanceSummary getDistribution();
    std::vector<models::Attendance> getRecentActivity(int limit = 10);

private:
    repositories::AttendanceRepository& attRepo_;
};

} // namespace services
} // namespace attendx

