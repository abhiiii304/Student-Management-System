#include "AuthService.h"
#include "../utils/Sha256.h"
#include "../utils/AuthUtils.h"
#include "../database/Database.h"
#include <sqlite3.h>

namespace attendx {
namespace services {

AuthService::AuthService(repositories::UserRepository& userRepo) : userRepo_(userRepo) {}

LoginResult AuthService::login(const std::string& username, const std::string& password) {
    LoginResult res;
    if (username.empty() || password.empty()) {
        res.success = false;
        res.message = "Username and password are required";
        return res;
    }

    auto userOpt = userRepo_.findByUsername(username);
    if (!userOpt) {
        res.success = false;
        res.message = "Invalid username or password";
        return res;
    }

    const auto& user = *userOpt;
    if (!utils::Sha256::verifyPassword(password, user.salt, user.passwordHash)) {
        res.success = false;
        res.message = "Invalid username or password";
        return res;
    }

    std::string token = utils::AuthUtils::createSession(user.id, user.username, user.role);
    res.success = true;
    res.token = token;
    res.message = "Login successful";
    res.user = user.toJson(false);
    return res;
}

bool AuthService::logout(const std::string& token) {
    utils::AuthUtils::invalidateSession(token);
    return true;
}

bool AuthService::changePassword(int userId, const std::string& oldPass, const std::string& newPass, std::string& err) {
    if (newPass.length() < 6) {
        err = "New password must be at least 6 characters";
        return false;
    }

    auto userOpt = userRepo_.findById(userId);
    if (!userOpt) {
        err = "User not found";
        return false;
    }

    const auto& user = *userOpt;
    if (!utils::Sha256::verifyPassword(oldPass, user.salt, user.passwordHash)) {
        err = "Current password is incorrect";
        return false;
    }

    std::string newSalt = utils::Sha256::generateSalt();
    std::string newHash = utils::Sha256::hashPassword(newPass, newSalt);

    auto& db = database::Database::getInstance();
    std::lock_guard<std::mutex> lock(db.getMutex());
    const char* sql = "UPDATE users SET password_hash = ?, salt = ? WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db.getHandle(), sql, -1, &stmt, nullptr) != SQLITE_OK) {
        err = "Database error";
        return false;
    }
    sqlite3_bind_text(stmt, 1, newHash.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, newSalt.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 3, userId);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

} // namespace services
} // namespace attendx

