#pragma once
#include "../repositories/UserRepository.h"
#include "json.hpp"
#include <string>

namespace attendx {
namespace services {

struct LoginResult {
    bool success = false;
    std::string token;
    std::string message;
    nlohmann::json user;
};

class AuthService {
public:
    explicit AuthService(repositories::UserRepository& userRepo);

    LoginResult login(const std::string& username, const std::string& password);
    bool logout(const std::string& token);
    bool changePassword(int userId, const std::string& oldPass, const std::string& newPass, std::string& err);

private:
    repositories::UserRepository& userRepo_;
};

} // namespace services
} // namespace attendx

