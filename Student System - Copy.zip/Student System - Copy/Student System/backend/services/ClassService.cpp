#include "ClassService.h"
#include "../utils/Validation.h"

namespace attendx {
namespace services {

ClassService::ClassService(repositories::ClassRepository& classRepo) : classRepo_(classRepo) {}

std::vector<models::Class> ClassService::getAllClasses(const std::string& search, const std::string& branch, int semester) {
    return classRepo_.findAll(search, branch, semester);
}

std::optional<models::Class> ClassService::getClassById(int id) {
    return classRepo_.findById(id);
}

ServiceResult ClassService::createClass(const nlohmann::json& body) {
    ServiceResult res;
    models::Class c = models::Class::fromJson(body);
    c.branch = utils::Validation::toUpper(utils::Validation::trim(c.branch));
    c.section = utils::Validation::toUpper(utils::Validation::trim(c.section));

    nlohmann::json errors = nlohmann::json::object();
    if (c.branch.empty()) errors["branch"] = "Branch is required";
    if (!utils::Validation::isValidSemester(c.semester)) errors["semester"] = "Semester must be between 1 and 8";
    if (c.section.empty()) errors["section"] = "Section is required";

    if (!errors.empty()) {
        res.success = false;
        res.message = "Validation failed";
        res.errors = errors;
        return res;
    }

    // Check duplicate class
    auto existing = classRepo_.findExact(c.branch, c.semester, c.section);
    if (existing) {
        res.success = false;
        res.message = "A class with this branch, semester, and section already exists";
        return res;
    }

    int newId = 0;
    if (classRepo_.create(c, newId)) {
        c.id = newId;
        res.success = true;
        res.message = "Class created successfully";
        res.data = c.toJson();
    } else {
        res.success = false;
        res.message = "Failed to create class in database";
    }
    return res;
}

ServiceResult ClassService::updateClass(int id, const nlohmann::json& body) {
    ServiceResult res;
    auto existing = classRepo_.findById(id);
    if (!existing) {
        res.success = false;
        res.message = "Class not found";
        return res;
    }

    models::Class c = models::Class::fromJson(body);
    c.id = id;
    c.branch = utils::Validation::toUpper(utils::Validation::trim(c.branch));
    c.section = utils::Validation::toUpper(utils::Validation::trim(c.section));

    nlohmann::json errors = nlohmann::json::object();
    if (c.branch.empty()) errors["branch"] = "Branch is required";
    if (!utils::Validation::isValidSemester(c.semester)) errors["semester"] = "Semester must be between 1 and 8";
    if (c.section.empty()) errors["section"] = "Section is required";

    if (!errors.empty()) {
        res.success = false;
        res.message = "Validation failed";
        res.errors = errors;
        return res;
    }

    if (classRepo_.update(c)) {
        res.success = true;
        res.message = "Class updated successfully";
        res.data = c.toJson();
    } else {
        res.success = false;
        res.message = "Failed to update class in database";
    }
    return res;
}

ServiceResult ClassService::deleteClass(int id) {
    ServiceResult res;
    auto existing = classRepo_.findById(id);
    if (!existing) {
        res.success = false;
        res.message = "Class not found";
        return res;
    }

    if (classRepo_.deleteById(id)) {
        res.success = true;
        res.message = "Class deleted successfully";
    } else {
        res.success = false;
        res.message = "Failed to delete class";
    }
    return res;
}

} // namespace services
} // namespace attendx

