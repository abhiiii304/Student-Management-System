#pragma once
#include "../repositories/ClassRepository.h"
#include "json.hpp"
#include <string>
#include <vector>
#include <optional>

namespace attendx {
namespace services {

struct ServiceResult {
    bool success = false;
    std::string message;
    nlohmann::json data;
    nlohmann::json errors;
};

class ClassService {
public:
    explicit ClassService(repositories::ClassRepository& classRepo);

    std::vector<models::Class> getAllClasses(const std::string& search = "", const std::string& branch = "", int semester = 0);
    std::optional<models::Class> getClassById(int id);
    ServiceResult createClass(const nlohmann::json& body);
    ServiceResult updateClass(int id, const nlohmann::json& body);
    ServiceResult deleteClass(int id);

private:
    repositories::ClassRepository& classRepo_;
};

} // namespace services
} // namespace attendx

