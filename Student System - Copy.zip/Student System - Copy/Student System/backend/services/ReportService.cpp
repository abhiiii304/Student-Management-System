#include "ReportService.h"
#include <sstream>
#include <iomanip>

namespace attendx {
namespace services {

ReportService::ReportService(repositories::AttendanceRepository& attRepo, repositories::StudentRepository& studentRepo)
    : attRepo_(attRepo), studentRepo_(studentRepo) {}

nlohmann::json ReportService::getStudentReport(int studentId, int classId, int subjectId, const std::string& startDate, const std::string& endDate) {
    return attRepo_.getStudentReport(studentId, classId, subjectId, startDate, endDate);
}

nlohmann::json ReportService::getClassReport(int classId, const std::string& startDate, const std::string& endDate) {
    return attRepo_.getClassReport(classId, startDate, endDate);
}

nlohmann::json ReportService::getSubjectReport(int subjectId, const std::string& startDate, const std::string& endDate) {
    return attRepo_.getSubjectReport(subjectId, startDate, endDate);
}

nlohmann::json ReportService::getDailyReport(const std::string& date, int classId, int subjectId) {
    return attRepo_.getDailyReport(date, classId, subjectId);
}

nlohmann::json ReportService::getMonthlyReport(const std::string& yearMonth, int classId, int subjectId) {
    return attRepo_.getMonthlyReport(yearMonth, classId, subjectId);
}

nlohmann::json ReportService::getLowAttendanceReport(double threshold) {
    auto students = studentRepo_.getLowAttendanceStudents(threshold);
    nlohmann::json arr = nlohmann::json::array();
    for (const auto& s : students) {
        arr.push_back(s.toJson());
    }
    return arr;
}

std::string ReportService::exportToCsv(const std::string& reportType, const nlohmann::json& data) {
    std::ostringstream ss;

    if (reportType == "class") {
        ss << "Class ID,Branch,Semester,Section,Enrolled Students,Total Records,Present,Absent,Late,Attendance %\n";
        for (const auto& item : data) {
            ss << item.value("class_id", 0) << ","
               << "\"" << item.value("branch", "") << "\","
               << item.value("semester", 0) << ","
               << "\"" << item.value("section", "") << "\","
               << item.value("enrolled_students", 0) << ","
               << item.value("total_classes", 0) << ","
               << item.value("present", 0) << ","
               << item.value("absent", 0) << ","
               << item.value("late", 0) << ","
               << std::fixed << std::setprecision(1) << item.value("attendance_percentage", 0.0) << "%\n";
        }
    } else if (reportType == "subject") {
        ss << "Subject ID,Subject Code,Subject Name,Faculty,Branch,Semester,Sessions,Total Records,Present,Absent,Late,Attendance %\n";
        for (const auto& item : data) {
            ss << item.value("subject_id", 0) << ","
               << "\"" << item.value("subject_code", "") << "\","
               << "\"" << item.value("subject_name", "") << "\","
               << "\"" << item.value("faculty_name", "") << "\","
               << "\"" << item.value("branch", "") << "\","
               << item.value("semester", 0) << ","
               << item.value("total_sessions", 0) << ","
               << item.value("total_classes", 0) << ","
               << item.value("present", 0) << ","
               << item.value("absent", 0) << ","
               << item.value("late", 0) << ","
               << std::fixed << std::setprecision(1) << item.value("attendance_percentage", 0.0) << "%\n";
        }
    } else if (reportType == "daily") {
        ss << "ID,Date,Enrollment ID,Roll Number,Student Name,Branch,Semester,Section,Subject Code,Subject Name,Status\n";
        for (const auto& item : data) {
            ss << item.value("id", 0) << ","
               << "\"" << item.value("attendance_date", "") << "\","
               << "\"" << item.value("enrollment_id", "") << "\","
               << "\"" << item.value("roll_number", "") << "\","
               << "\"" << item.value("student_name", "") << "\","
               << "\"" << item.value("branch", "") << "\","
               << item.value("semester", 0) << ","
               << "\"" << item.value("section", "") << "\","
               << "\"" << item.value("subject_code", "") << "\","
               << "\"" << item.value("subject_name", "") << "\","
               << "\"" << item.value("status", "") << "\"\n";
        }
    } else {
        // Default: student-wise attendance report
        ss << "Enrollment ID,Roll Number,Student Name,Branch,Semester,Section,Subject Code,Subject Name,Total Classes,Present,Absent,Late,Attendance %,Status\n";
        for (const auto& item : data) {
            double pct = item.value("attendance_percentage", 0.0);
            ss << "\"" << item.value("enrollment_id", "") << "\","
               << "\"" << item.value("roll_number", "") << "\","
               << "\"" << item.value("student_name", "") << "\","
               << "\"" << item.value("branch", "") << "\","
               << item.value("semester", 0) << ","
               << "\"" << item.value("section", "") << "\","
               << "\"" << item.value("subject_code", "") << "\","
               << "\"" << item.value("subject_name", "") << "\","
               << item.value("total_classes", 0) << ","
               << item.value("present", 0) << ","
               << item.value("absent", 0) << ","
               << item.value("late", 0) << ","
               << std::fixed << std::setprecision(1) << pct << "%,"
               << (pct < 75.0 ? "Critical (Below 75%)" : "Normal") << "\n";
        }
    }

    return ss.str();
}

} // namespace services
} // namespace attendx

