#pragma once
#include "../repositories/AttendanceRepository.h"
#include "../repositories/StudentRepository.h"
#include "json.hpp"
#include <string>

namespace attendx {
namespace services {

class ReportService {
public:
    explicit ReportService(repositories::AttendanceRepository& attRepo, repositories::StudentRepository& studentRepo);

    nlohmann::json getStudentReport(int studentId = 0, int classId = 0, int subjectId = 0, const std::string& startDate = "", const std::string& endDate = "");
    nlohmann::json getClassReport(int classId = 0, const std::string& startDate = "", const std::string& endDate = "");
    nlohmann::json getSubjectReport(int subjectId = 0, const std::string& startDate = "", const std::string& endDate = "");
    nlohmann::json getDailyReport(const std::string& date, int classId = 0, int subjectId = 0);
    nlohmann::json getMonthlyReport(const std::string& yearMonth, int classId = 0, int subjectId = 0);
    nlohmann::json getLowAttendanceReport(double threshold = 75.0);

    std::string exportToCsv(const std::string& reportType, const nlohmann::json& reportData);

private:
    repositories::AttendanceRepository& attRepo_;
    repositories::StudentRepository& studentRepo_;
};

} // namespace services
} // namespace attendx

