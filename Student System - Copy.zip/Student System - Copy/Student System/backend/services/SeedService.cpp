#include "SeedService.h"
#include <iostream>
#include <vector>

namespace attendx {
namespace services {

SeedService::SeedService(
    repositories::StudentRepository& studentRepo,
    repositories::ClassRepository& classRepo,
    repositories::SubjectRepository& subjectRepo,
    repositories::AttendanceRepository& attRepo
) : studentRepo_(studentRepo), classRepo_(classRepo), subjectRepo_(subjectRepo), attRepo_(attRepo) {}

bool SeedService::seedDemoData(bool force, std::string* message) {
    if (!force && studentRepo_.countActive() >= 10) {
        if (message) *message = "Database already contains data (" + std::to_string(studentRepo_.countActive()) + " students). Skipping seed.";
        return true;
    }

    // 1. Seed Classes
    struct ClassSeed { std::string branch; int semester; std::string section; std::string year; };
    std::vector<ClassSeed> classes = {
        {"CSE", 6, "A", "2026-2027"},
        {"CSE", 6, "B", "2026-2027"},
        {"IT", 6, "A", "2026-2027"},
        {"ECE", 4, "A", "2026-2027"}
    };

    std::vector<int> classIds;
    for (const auto& cs : classes) {
        auto existing = classRepo_.findExact(cs.branch, cs.semester, cs.section);
        if (existing) {
            classIds.push_back(existing->id);
        } else {
            models::Class c;
            c.branch = cs.branch;
            c.semester = cs.semester;
            c.section = cs.section;
            c.academicYear = cs.year;
            int newId = 0;
            classRepo_.create(c, newId);
            classIds.push_back(newId);
        }
    }

    // 2. Seed Subjects
    struct SubjectSeed {
        std::string name;
        std::string code;
        std::string branch;
        int semester;
        std::string section;
        std::string faculty;
        int classIdx;
    };

    std::vector<SubjectSeed> subjects = {
        {"Advanced Database Systems", "CS601", "CSE", 6, "A", "Dr. Rajesh Sharma", 0},
        {"Cloud Computing & DevOps", "CS602", "CSE", 6, "A", "Prof. Ananya Iyer", 0},
        {"Artificial Intelligence & ML", "CS603", "CSE", 6, "A", "Dr. Vikram Seth", 0},
        {"Information Security", "CS604", "CSE", 6, "B", "Prof. Meera Nair", 1},
        {"Web Technologies", "IT601", "IT", 6, "A", "Dr. Arvind Patel", 2},
        {"Signals and Systems", "EC401", "ECE", 4, "A", "Dr. Kavita Menon", 3}
    };

    std::vector<int> subjectIds;
    for (const auto& ss : subjects) {
        auto existing = subjectRepo_.findByCode(ss.code);
        if (existing) {
            subjectIds.push_back(existing->id);
        } else {
            models::Subject s;
            s.subjectName = ss.name;
            s.subjectCode = ss.code;
            s.branch = ss.branch;
            s.semester = ss.semester;
            s.section = ss.section;
            s.facultyName = ss.faculty;
            if (ss.classIdx < static_cast<int>(classIds.size())) {
                s.classId = classIds[ss.classIdx];
            }
            int newId = 0;
            subjectRepo_.create(s, newId);
            subjectIds.push_back(newId);
        }
    }

    // 3. Seed at least 24 Students
    struct StudentSeed {
        std::string enroll;
        std::string name;
        std::string roll;
        std::string branch;
        std::string section;
        int semester;
        std::string email;
        std::string phone;
    };

    std::vector<StudentSeed> students = {
        {"EN2024001", "Aarav Sharma", "CS-01", "CSE", "A", 6, "aarav.sharma@attendx.edu", "+91 98765 43210"},
        {"EN2024002", "Diya Patel", "CS-02", "CSE", "A", 6, "diya.patel@attendx.edu", "+91 98765 43211"},
        {"EN2024003", "Rohan Verma", "CS-03", "CSE", "A", 6, "rohan.verma@attendx.edu", "+91 98765 43212"},
        {"EN2024004", "Ananya Deshmukh", "CS-04", "CSE", "A", 6, "ananya.d@attendx.edu", "+91 98765 43213"},
        {"EN2024005", "Kabir Mehta", "CS-05", "CSE", "A", 6, "kabir.mehta@attendx.edu", "+91 98765 43214"},
        {"EN2024006", "Sneha Kulkarni", "CS-06", "CSE", "A", 6, "sneha.k@attendx.edu", "+91 98765 43215"},
        {"EN2024007", "Aditya Nair", "CS-07", "CSE", "A", 6, "aditya.nair@attendx.edu", "+91 98765 43216"},
        {"EN2024008", "Pooja Reddy", "CS-08", "CSE", "A", 6, "pooja.reddy@attendx.edu", "+91 98765 43217"},
        {"EN2024009", "Varun Chopra", "CS-09", "CSE", "A", 6, "varun.c@attendx.edu", "+91 98765 43218"},
        {"EN2024010", "Isha Mukherjee", "CS-10", "CSE", "A", 6, "isha.m@attendx.edu", "+91 98765 43219"},

        // CSE Section B
        {"EN2024011", "Rhea Sengupta", "CS-11", "CSE", "B", 6, "rhea.s@attendx.edu", "+91 98765 43220"},
        {"EN2024012", "Siddharth Rao", "CS-12", "CSE", "B", 6, "siddharth.r@attendx.edu", "+91 98765 43221"},
        {"EN2024013", "Tanvi Joshi", "CS-13", "CSE", "B", 6, "tanvi.j@attendx.edu", "+91 98765 43222"},
        {"EN2024014", "Manish Pandey", "CS-14", "CSE", "B", 6, "manish.p@attendx.edu", "+91 98765 43223"},
        {"EN2024015", "Kiran Bhat", "CS-15", "CSE", "B", 6, "kiran.b@attendx.edu", "+91 98765 43224"},

        // IT Section A
        {"EN2024016", "Nikhil Pillai", "IT-01", "IT", "A", 6, "nikhil.p@attendx.edu", "+91 98765 43225"},
        {"EN2024017", "Shruti Gupta", "IT-02", "IT", "A", 6, "shruti.g@attendx.edu", "+91 98765 43226"},
        {"EN2024018", "Gaurav Roy", "IT-03", "IT", "A", 6, "gaurav.roy@attendx.edu", "+91 98765 43227"},
        {"EN2024019", "Mehak Jain", "IT-04", "IT", "A", 6, "mehak.j@attendx.edu", "+91 98765 43228"},
        {"EN2024020", "Abhishek Das", "IT-05", "IT", "A", 6, "abhishek.d@attendx.edu", "+91 98765 43229"},

        // ECE Section A
        {"EN2024021", "Pranav Bansal", "EC-01", "ECE", "A", 4, "pranav.b@attendx.edu", "+91 98765 43230"},
        {"EN2024022", "Tara Raman", "EC-02", "ECE", "A", 4, "tara.r@attendx.edu", "+91 98765 43231"},
        {"EN2024023", "Kunal Singhania", "EC-03", "ECE", "A", 4, "kunal.s@attendx.edu", "+91 98765 43232"},
        {"EN2024024", "Ritu Agrawal", "EC-04", "ECE", "A", 4, "ritu.a@attendx.edu", "+91 98765 43233"}
    };

    std::vector<int> studentIds;
    for (const auto& s : students) {
        auto existing = studentRepo_.findByEnrollmentId(s.enroll);
        if (existing) {
            studentIds.push_back(existing->id);
        } else {
            models::Student st;
            st.enrollmentId = s.enroll;
            st.name = s.name;
            st.rollNumber = s.roll;
            st.branch = s.branch;
            st.section = s.section;
            st.semester = s.semester;
            st.email = s.email;
            st.phone = s.phone;
            int newId = 0;
            studentRepo_.create(st, newId);
            studentIds.push_back(newId);
        }
    }

    // 4. Seed Attendance Records across recent dates (e.g. 2026-11-16 to 2026-11-23)
    std::vector<std::string> dates = {
        "2026-11-17",
        "2026-11-18",
        "2026-11-19",
        "2026-11-20",
        "2026-11-21",
        "2026-11-22",
        "2026-11-23"
    };

    // We generate realistic statuses:
    // Most students present (85-95%)
    // Student 3 (Rohan Verma) and Student 9 (Varun Chopra) have low attendance (<75%) to trigger the low attendance alert!
    int insertedCount = 0;
    int updatedCount = 0;
    std::vector<models::Attendance> batch;

    for (const auto& date : dates) {
        // For CSE Section A students (first 10) in CS601, CS602, CS603
        for (int i = 0; i < 10; ++i) {
            int sId = studentIds[i];
            for (int subIdx = 0; subIdx < 3; ++subIdx) {
                int subId = subjectIds[subIdx];
                models::Attendance att;
                att.studentId = sId;
                att.subjectId = subId;
                att.classId = classIds[0];
                att.attendanceDate = date;

                // Produce deliberate attendance percentages:
                if (i == 2) {
                    // Rohan Verma - below 75%
                    att.status = (date == "2026-11-18" || date == "2026-11-21") ? "Present" : "Absent";
                } else if (i == 8) {
                    // Varun Chopra - below 75%
                    att.status = (date == "2026-11-17" || date == "2026-11-20") ? "Present" : "Absent";
                } else if (i == 5) {
                    // Sneha Kulkarni - has some Late entries
                    att.status = (date == "2026-11-19" || date == "2026-11-22") ? "Late" : "Present";
                } else {
                    // Mostly present
                    att.status = (date == "2026-11-19" && i % 4 == 0) ? "Absent" : "Present";
                }
                batch.push_back(att);
            }
        }

        // For CSE Section B (students 10 to 14) in CS604
        for (int i = 10; i < 15; ++i) {
            int sId = studentIds[i];
            models::Attendance att;
            att.studentId = sId;
            att.subjectId = subjectIds[3]; // CS604
            att.classId = classIds[1];
            att.attendanceDate = date;
            att.status = (date == "2026-11-20" && i == 12) ? "Absent" : "Present";
            batch.push_back(att);
        }

        // For IT Section A (students 15 to 19) in IT601
        for (int i = 15; i < 20; ++i) {
            int sId = studentIds[i];
            models::Attendance att;
            att.studentId = sId;
            att.subjectId = subjectIds[4]; // IT601
            att.classId = classIds[2];
            att.attendanceDate = date;
            att.status = (date == "2026-11-21" && i == 18) ? "Absent" : "Present";
            batch.push_back(att);
        }

        // For ECE Section A (students 20 to 23) in EC401
        for (int i = 20; i < 24; ++i) {
            int sId = studentIds[i];
            models::Attendance att;
            att.studentId = sId;
            att.subjectId = subjectIds[5]; // EC401
            att.classId = classIds[3];
            att.attendanceDate = date;
            att.status = "Present";
            batch.push_back(att);
        }
    }

    attRepo_.bulkRecord(batch, updatedCount, insertedCount);

    if (message) {
        *message = "Successfully seeded " + std::to_string(classes.size()) + " classes, " +
                   std::to_string(subjects.size()) + " subjects, " +
                   std::to_string(students.size()) + " students, and " +
                   std::to_string(batch.size()) + " attendance entries.";
    }

    std::cout << "[SeedService] Seeded demo dataset: " << students.size() << " students, " 
              << batch.size() << " attendance records across " << dates.size() << " dates." << std::endl;
    return true;
}

} // namespace services
} // namespace attendx

