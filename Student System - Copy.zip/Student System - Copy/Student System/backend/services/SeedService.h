#pragma once
#include "../repositories/StudentRepository.h"
#include "../repositories/ClassRepository.h"
#include "../repositories/SubjectRepository.h"
#include "../repositories/AttendanceRepository.h"
#include <string>

namespace attendx {
namespace services {

class SeedService {
public:
    SeedService(
        repositories::StudentRepository& studentRepo,
        repositories::ClassRepository& classRepo,
        repositories::SubjectRepository& subjectRepo,
        repositories::AttendanceRepository& attRepo
    );

    bool seedDemoData(bool force = false, std::string* message = nullptr);

private:
    repositories::StudentRepository& studentRepo_;
    repositories::ClassRepository& classRepo_;
    repositories::SubjectRepository& subjectRepo_;
    repositories::AttendanceRepository& attRepo_;
};

} // namespace services
} // namespace attendx

