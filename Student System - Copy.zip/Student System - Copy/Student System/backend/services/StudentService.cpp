#include "StudentService.h"
#include "../utils/Validation.h"

namespace attendx {
namespace services {

StudentService::StudentService(repositories::StudentRepository& studentRepo) : studentRepo_(studentRepo) {}

std::vector<models::Student> StudentService::getAllStudents(
    const std::string& search,
    const std::string& branch,
    const std::string& section,
    int semester,
    bool includeDeleted,
    int limit,
    int offset
) {
    return studentRepo_.findAll(search, branch, section, semester, includeDeleted, limit, offset);
}

int StudentService::getStudentCount(
    const std::string& search,
    const std::string& branch,
    const std::string& section,
    int semester,
    bool includeDeleted
) {
    return studentRepo_.count(search, branch, section, semester, includeDeleted);
}

std::optional<models::Student> StudentService::getStudentById(int id, bool includeDeleted) {
    return studentRepo_.findById(id, includeDeleted);
}

ServiceResult StudentService::createStudent(const nlohmann::json& body) {
    ServiceResult res;
    models::Student s = models::Student::fromJson(body);
    s.enrollmentId = utils::Validation::toUpper(utils::Validation::trim(s.enrollmentId));
    s.name = utils::Validation::trim(s.name);
    s.rollNumber = utils::Validation::toUpper(utils::Validation::trim(s.rollNumber));
    s.branch = utils::Validation::toUpper(utils::Validation::trim(s.branch));
    s.section = utils::Validation::toUpper(utils::Validation::trim(s.section));
    s.email = utils::Validation::trim(s.email);
    s.phone = utils::Validation::trim(s.phone);

    nlohmann::json errors = nlohmann::json::object();
    if (s.name.empty()) errors["name"] = "Student name is required";
    if (s.enrollmentId.empty()) errors["enrollment_id"] = "Enrollment ID is required";
    if (s.branch.empty()) errors["branch"] = "Branch is required";
    if (s.section.empty()) errors["section"] = "Section is required";
    if (!utils::Validation::isValidSemester(s.semester)) errors["semester"] = "Semester must be between 1 and 8";
    if (!utils::Validation::isValidEmail(s.email)) errors["email"] = "Email format is invalid";
    if (!utils::Validation::isValidPhone(s.phone)) errors["phone"] = "Phone format is invalid";

    // Uniqueness checks
    if (!s.enrollmentId.empty()) {
        auto existing = studentRepo_.findByEnrollmentId(s.enrollmentId);
        if (existing) errors["enrollment_id"] = "Enrollment ID already exists";
    }
    if (!s.rollNumber.empty()) {
        auto existing = studentRepo_.findByRollNumber(s.rollNumber);
        if (existing) errors["roll_number"] = "Roll number already exists";
    }

    if (!errors.empty()) {
        res.success = false;
        res.message = "Validation failed";
        res.errors = errors;
        return res;
    }

    int newId = 0;
    if (studentRepo_.create(s, newId)) {
        s.id = newId;
        res.success = true;
        res.message = "Student created successfully";
        res.data = s.toJson();
    } else {
        res.success = false;
        res.message = "Failed to save student to database";
    }
    return res;
}

ServiceResult StudentService::updateStudent(int id, const nlohmann::json& body) {
    ServiceResult res;
    auto existingOpt = studentRepo_.findById(id, true);
    if (!existingOpt) {
        res.success = false;
        res.message = "Student not found";
        return res;
    }

    models::Student s = models::Student::fromJson(body);
    s.id = id;
    s.enrollmentId = utils::Validation::toUpper(utils::Validation::trim(s.enrollmentId));
    s.name = utils::Validation::trim(s.name);
    s.rollNumber = utils::Validation::toUpper(utils::Validation::trim(s.rollNumber));
    s.branch = utils::Validation::toUpper(utils::Validation::trim(s.branch));
    s.section = utils::Validation::toUpper(utils::Validation::trim(s.section));
    s.email = utils::Validation::trim(s.email);
    s.phone = utils::Validation::trim(s.phone);

    nlohmann::json errors = nlohmann::json::object();
    if (s.name.empty()) errors["name"] = "Student name is required";
    if (s.enrollmentId.empty()) errors["enrollment_id"] = "Enrollment ID is required";
    if (s.branch.empty()) errors["branch"] = "Branch is required";
    if (s.section.empty()) errors["section"] = "Section is required";
    if (!utils::Validation::isValidSemester(s.semester)) errors["semester"] = "Semester must be between 1 and 8";
    if (!utils::Validation::isValidEmail(s.email)) errors["email"] = "Email format is invalid";
    if (!utils::Validation::isValidPhone(s.phone)) errors["phone"] = "Phone format is invalid";

    // Uniqueness checks (excluding current student)
    if (!s.enrollmentId.empty()) {
        auto check = studentRepo_.findByEnrollmentId(s.enrollmentId);
        if (check && check->id != id) errors["enrollment_id"] = "Enrollment ID already exists";
    }
    if (!s.rollNumber.empty()) {
        auto check = studentRepo_.findByRollNumber(s.rollNumber);
        if (check && check->id != id) errors["roll_number"] = "Roll number already exists";
    }

    if (!errors.empty()) {
        res.success = false;
        res.message = "Validation failed";
        res.errors = errors;
        return res;
    }

    if (studentRepo_.update(s)) {
        res.success = true;
        res.message = "Student updated successfully";
        res.data = s.toJson();
    } else {
        res.success = false;
        res.message = "Failed to update student in database";
    }
    return res;
}

ServiceResult StudentService::deleteStudent(int id, bool hardDelete) {
    ServiceResult res;
    auto existing = studentRepo_.findById(id, true);
    if (!existing) {
        res.success = false;
        res.message = "Student not found";
        return res;
    }

    bool ok = hardDelete ? studentRepo_.hardDelete(id) : studentRepo_.softDelete(id);
    if (ok) {
        res.success = true;
        res.message = hardDelete ? "Student permanently deleted" : "Student soft-deleted successfully (attendance preserved)";
    } else {
        res.success = false;
        res.message = "Failed to delete student";
    }
    return res;
}

ServiceResult StudentService::restoreStudent(int id) {
    ServiceResult res;
    if (studentRepo_.restore(id)) {
        res.success = true;
        res.message = "Student restored successfully";
    } else {
        res.success = false;
        res.message = "Failed to restore student";
    }
    return res;
}

std::vector<models::Student> StudentService::getLowAttendanceStudents(double threshold) {
    return studentRepo_.getLowAttendanceStudents(threshold);
}

} // namespace services
} // namespace attendx

