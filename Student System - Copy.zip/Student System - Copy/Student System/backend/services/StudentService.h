#pragma once
#include "../repositories/StudentRepository.h"
#include "ClassService.h" // for ServiceResult
#include "json.hpp"
#include <string>
#include <vector>
#include <optional>

namespace attendx {
namespace services {

class StudentService {
public:
    explicit StudentService(repositories::StudentRepository& studentRepo);

    std::vector<models::Student> getAllStudents(
        const std::string& search = "",
        const std::string& branch = "",
        const std::string& section = "",
        int semester = 0,
        bool includeDeleted = false,
        int limit = 100,
        int offset = 0
    );

    int getStudentCount(
        const std::string& search = "",
        const std::string& branch = "",
        const std::string& section = "",
        int semester = 0,
        bool includeDeleted = false
    );

    std::optional<models::Student> getStudentById(int id, bool includeDeleted = false);
    ServiceResult createStudent(const nlohmann::json& body);
    ServiceResult updateStudent(int id, const nlohmann::json& body);
    ServiceResult deleteStudent(int id, bool hardDelete = false);
    ServiceResult restoreStudent(int id);
    std::vector<models::Student> getLowAttendanceStudents(double threshold = 75.0);

private:
    repositories::StudentRepository& studentRepo_;
};

} // namespace services
} // namespace attendx

