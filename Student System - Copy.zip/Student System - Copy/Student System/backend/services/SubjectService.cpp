#include "SubjectService.h"
#include "../utils/Validation.h"

namespace attendx {
namespace services {

SubjectService::SubjectService(repositories::SubjectRepository& subjectRepo) : subjectRepo_(subjectRepo) {}

std::vector<models::Subject> SubjectService::getAllSubjects(
    const std::string& search,
    const std::string& branch,
    int semester,
    int classId
) {
    return subjectRepo_.findAll(search, branch, semester, classId);
}

std::optional<models::Subject> SubjectService::getSubjectById(int id) {
    return subjectRepo_.findById(id);
}

ServiceResult SubjectService::createSubject(const nlohmann::json& body) {
    ServiceResult res;
    models::Subject s = models::Subject::fromJson(body);
    s.subjectName = utils::Validation::trim(s.subjectName);
    s.subjectCode = utils::Validation::toUpper(utils::Validation::trim(s.subjectCode));
    s.branch = utils::Validation::toUpper(utils::Validation::trim(s.branch));
    s.section = utils::Validation::toUpper(utils::Validation::trim(s.section));
    s.facultyName = utils::Validation::trim(s.facultyName);

    nlohmann::json errors = nlohmann::json::object();
    if (s.subjectName.empty()) errors["subject_name"] = "Subject name is required";
    if (s.subjectCode.empty()) errors["subject_code"] = "Subject code is required";
    if (!utils::Validation::isValidSemester(s.semester)) errors["semester"] = "Semester must be between 1 and 8";

    // Uniqueness
    if (!s.subjectCode.empty()) {
        auto check = subjectRepo_.findByCode(s.subjectCode);
        if (check) errors["subject_code"] = "Subject code already exists";
    }

    if (!errors.empty()) {
        res.success = false;
        res.message = "Validation failed";
        res.errors = errors;
        return res;
    }

    int newId = 0;
    if (subjectRepo_.create(s, newId)) {
        s.id = newId;
        res.success = true;
        res.message = "Subject created successfully";
        res.data = s.toJson();
    } else {
        res.success = false;
        res.message = "Failed to save subject to database";
    }
    return res;
}

ServiceResult SubjectService::updateSubject(int id, const nlohmann::json& body) {
    ServiceResult res;
    auto existingOpt = subjectRepo_.findById(id);
    if (!existingOpt) {
        res.success = false;
        res.message = "Subject not found";
        return res;
    }

    models::Subject s = models::Subject::fromJson(body);
    s.id = id;
    s.subjectName = utils::Validation::trim(s.subjectName);
    s.subjectCode = utils::Validation::toUpper(utils::Validation::trim(s.subjectCode));
    s.branch = utils::Validation::toUpper(utils::Validation::trim(s.branch));
    s.section = utils::Validation::toUpper(utils::Validation::trim(s.section));
    s.facultyName = utils::Validation::trim(s.facultyName);

    nlohmann::json errors = nlohmann::json::object();
    if (s.subjectName.empty()) errors["subject_name"] = "Subject name is required";
    if (s.subjectCode.empty()) errors["subject_code"] = "Subject code is required";
    if (!utils::Validation::isValidSemester(s.semester)) errors["semester"] = "Semester must be between 1 and 8";

    if (!s.subjectCode.empty()) {
        auto check = subjectRepo_.findByCode(s.subjectCode);
        if (check && check->id != id) errors["subject_code"] = "Subject code already exists";
    }

    if (!errors.empty()) {
        res.success = false;
        res.message = "Validation failed";
        res.errors = errors;
        return res;
    }

    if (subjectRepo_.update(s)) {
        res.success = true;
        res.message = "Subject updated successfully";
        res.data = s.toJson();
    } else {
        res.success = false;
        res.message = "Failed to update subject in database";
    }
    return res;
}

ServiceResult SubjectService::deleteSubject(int id) {
    ServiceResult res;
    auto existing = subjectRepo_.findById(id);
    if (!existing) {
        res.success = false;
        res.message = "Subject not found";
        return res;
    }

    if (subjectRepo_.deleteById(id)) {
        res.success = true;
        res.message = "Subject deleted successfully";
    } else {
        res.success = false;
        res.message = "Failed to delete subject";
    }
    return res;
}

} // namespace services
} // namespace attendx

