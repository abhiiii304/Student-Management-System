#pragma once
#include "../repositories/SubjectRepository.h"
#include "ClassService.h" // for ServiceResult
#include "json.hpp"
#include <string>
#include <vector>
#include <optional>

namespace attendx {
namespace services {

class SubjectService {
public:
    explicit SubjectService(repositories::SubjectRepository& subjectRepo);

    std::vector<models::Subject> getAllSubjects(
        const std::string& search = "",
        const std::string& branch = "",
        int semester = 0,
        int classId = 0
    );

    std::optional<models::Subject> getSubjectById(int id);
    ServiceResult createSubject(const nlohmann::json& body);
    ServiceResult updateSubject(int id, const nlohmann::json& body);
    ServiceResult deleteSubject(int id);

private:
    repositories::SubjectRepository& subjectRepo_;
};

} // namespace services
} // namespace attendx

