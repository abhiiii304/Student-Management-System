#include "AuthUtils.h"
#include "Sha256.h"
#include "ResponseUtils.h"

namespace attendx {
namespace utils {

std::unordered_map<std::string, SessionData> AuthUtils::sessions_;
std::mutex AuthUtils::mutex_;

std::string AuthUtils::createSession(int userId, const std::string& username, const std::string& role) {
    std::lock_guard<std::mutex> lock(mutex_);
    std::string token = Sha256::generateToken();
    SessionData session;
    session.userId = userId;
    session.username = username;
    session.role = role;
    session.expiresAt = std::chrono::system_clock::now() + std::chrono::hours(24);

    sessions_[token] = session;
    return token;
}

bool AuthUtils::validateSession(const std::string& token, SessionData& outData) {
    if (token.empty()) return false;
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = sessions_.find(token);
    if (it == sessions_.end()) return false;

    if (std::chrono::system_clock::now() > it->second.expiresAt) {
        sessions_.erase(it);
        return false;
    }

    outData = it->second;
    return true;
}

void AuthUtils::invalidateSession(const std::string& token) {
    std::lock_guard<std::mutex> lock(mutex_);
    sessions_.erase(token);
}

std::string AuthUtils::extractToken(const httplib::Request& req) {
    if (req.has_header("Authorization")) {
        std::string auth = req.get_header_value("Authorization");
        const std::string prefix = "Bearer ";
        if (auth.rfind(prefix, 0) == 0) {
            return auth.substr(prefix.length());
        }
    }
    // Also check Cookie "attendx_token"
    if (req.has_header("Cookie")) {
        std::string cookie = req.get_header_value("Cookie");
        const std::string key = "attendx_token=";
        auto pos = cookie.find(key);
        if (pos != std::string::npos) {
            auto end = cookie.find(";", pos);
            if (end == std::string::npos) end = cookie.length();
            return cookie.substr(pos + key.length(), end - (pos + key.length()));
        }
    }
    return "";
}

bool AuthUtils::requireAuth(const httplib::Request& req, httplib::Response& res, SessionData& outData) {
    std::string token = extractToken(req);
    if (!validateSession(token, outData)) {
        ResponseUtils::sendUnauthorized(res, "Access denied. Valid authentication token required.");
        return false;
    }
    return true;
}

} // namespace utils
} // namespace attendx

