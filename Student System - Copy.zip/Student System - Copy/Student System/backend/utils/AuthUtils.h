#pragma once
#include "httplib.h"
#include <string>
#include <unordered_map>
#include <mutex>
#include <chrono>

namespace attendx {
namespace utils {

struct SessionData {
    int userId;
    std::string username;
    std::string role;
    std::chrono::system_clock::time_point expiresAt;
};

class AuthUtils {
public:
    static std::string createSession(int userId, const std::string& username, const std::string& role);
    static bool validateSession(const std::string& token, SessionData& outData);
    static void invalidateSession(const std::string& token);
    static std::string extractToken(const httplib::Request& req);
    static bool requireAuth(const httplib::Request& req, httplib::Response& res, SessionData& outData);

private:
    static std::unordered_map<std::string, SessionData> sessions_;
    static std::mutex mutex_;
};

} // namespace utils
} // namespace attendx

