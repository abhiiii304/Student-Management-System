#include "ResponseUtils.h"

namespace attendx {
namespace utils {

void ResponseUtils::sendSuccess(httplib::Response& res, const std::string& message, const nlohmann::json& data, int statusCode) {
    nlohmann::json body;
    body["success"] = true;
    body["message"] = message;
    body["data"] = data;

    res.status = statusCode;
    res.set_content(body.dump(), "application/json");
}

void ResponseUtils::sendCreated(httplib::Response& res, const std::string& message, const nlohmann::json& data) {
    sendSuccess(res, message, data, 201);
}

void ResponseUtils::sendError(httplib::Response& res, const std::string& message, const nlohmann::json& errors, int statusCode) {
    nlohmann::json body;
    body["success"] = false;
    body["message"] = message;
    body["errors"] = errors;

    res.status = statusCode;
    res.set_content(body.dump(), "application/json");
}

void ResponseUtils::sendNotFound(httplib::Response& res, const std::string& message) {
    sendError(res, message, nlohmann::json::object(), 404);
}

void ResponseUtils::sendConflict(httplib::Response& res, const std::string& message) {
    sendError(res, message, nlohmann::json::object(), 409);
}

void ResponseUtils::sendUnauthorized(httplib::Response& res, const std::string& message) {
    sendError(res, message, nlohmann::json::object(), 401);
}

void ResponseUtils::sendServerError(httplib::Response& res, const std::string& message) {
    sendError(res, message, nlohmann::json::object(), 500);
}

} // namespace utils
} // namespace attendx

