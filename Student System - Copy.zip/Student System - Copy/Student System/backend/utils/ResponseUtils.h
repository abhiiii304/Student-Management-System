#pragma once
#include "httplib.h"
#include "json.hpp"
#include <string>

namespace attendx {
namespace utils {

class ResponseUtils {
public:
    static void sendSuccess(httplib::Response& res, const std::string& message, const nlohmann::json& data = nlohmann::json::object(), int statusCode = 200);
    static void sendCreated(httplib::Response& res, const std::string& message, const nlohmann::json& data = nlohmann::json::object());
    static void sendError(httplib::Response& res, const std::string& message, const nlohmann::json& errors = nlohmann::json::object(), int statusCode = 400);
    static void sendNotFound(httplib::Response& res, const std::string& message = "Resource not found");
    static void sendConflict(httplib::Response& res, const std::string& message = "Resource conflict detected");
    static void sendUnauthorized(httplib::Response& res, const std::string& message = "Authentication required");
    static void sendServerError(httplib::Response& res, const std::string& message = "Internal server error occurred");
};

} // namespace utils
} // namespace attendx

