#include "Sha256.h"
#include <sstream>
#include <iomanip>
#include <random>
#include <chrono>

#if defined(__APPLE__)
#include <CommonCrypto/CommonDigest.h>
#elif defined(_WIN32)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <bcrypt.h>
#pragma comment(lib, "bcrypt.lib")
#else
#include <functional>
#endif

namespace attendx {
namespace utils {

std::string Sha256::hash(const std::string& input) {
#if defined(__APPLE__)
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(input.data(), static_cast<CC_LONG>(input.size()), digest);
    std::ostringstream oss;
    for (int i = 0; i < CC_SHA256_DIGEST_LENGTH; ++i) {
        oss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(digest[i]);
    }
    return oss.str();
#elif defined(_WIN32)
    BCRYPT_ALG_HANDLE hAlg = NULL;
    BCRYPT_HASH_HANDLE hHash = NULL;
    unsigned char digest[32] = {0};
    if (BCryptOpenAlgorithmProvider(&hAlg, BCRYPT_SHA256_ALGORITHM, NULL, 0) >= 0) {
        if (BCryptCreateHash(hAlg, &hHash, NULL, 0, NULL, 0, 0) >= 0) {
            BCryptHashData(hHash, (PUCHAR)input.data(), (ULONG)input.size(), 0);
            BCryptFinishHash(hHash, digest, sizeof(digest), 0);
            BCryptDestroyHash(hHash);
        }
        BCryptCloseAlgorithmProvider(hAlg, 0);
    }
    std::ostringstream oss;
    for (int i = 0; i < 32; ++i) {
        oss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(digest[i]);
    }
    return oss.str();
#else
    // Fallback hash implementation
    std::hash<std::string> hasher;
    size_t h = hasher(input);
    std::ostringstream oss;
    oss << std::hex << std::setw(16) << std::setfill('0') << h;
    return oss.str();
#endif
}

std::string Sha256::generateSalt(size_t length) {
    const char charset[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<size_t> dis(0, sizeof(charset) - 2);

    std::string salt;
    salt.reserve(length);
    for (size_t i = 0; i < length; ++i) {
        salt += charset[dis(gen)];
    }
    return salt;
}

std::string Sha256::hashPassword(const std::string& password, const std::string& salt) {
    return hash(password + "$" + salt);
}

bool Sha256::verifyPassword(const std::string& password, const std::string& salt, const std::string& expectedHash) {
    return hashPassword(password, salt) == expectedHash;
}

std::string Sha256::generateToken() {
    auto now = std::chrono::system_clock::now().time_since_epoch().count();
    return hash(std::to_string(now) + "_" + generateSalt(24));
}

} // namespace utils
} // namespace attendx

