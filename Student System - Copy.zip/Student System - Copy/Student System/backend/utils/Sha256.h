#pragma once
#include <string>

namespace attendx {
namespace utils {

class Sha256 {
public:
    static std::string hash(const std::string& input);
    static std::string generateSalt(size_t length = 16);
    static std::string hashPassword(const std::string& password, const std::string& salt);
    static bool verifyPassword(const std::string& password, const std::string& salt, const std::string& hash);
    static std::string generateToken();
};

} // namespace utils
} // namespace attendx

