#include "Validation.h"
#include <algorithm>
#include <cctype>

namespace attendx {
namespace utils {

bool Validation::isValidEmail(const std::string& email) {
    if (email.empty()) return true; // Optional field
    const std::regex pattern(R"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)");
    return std::regex_match(email, pattern);
}

bool Validation::isValidPhone(const std::string& phone) {
    if (phone.empty()) return true; // Optional field
    const std::regex pattern(R"(^\+?[0-9\s\-()]{7,20}$)");
    return std::regex_match(phone, pattern);
}

bool Validation::isValidSemester(int semester) {
    return semester >= 1 && semester <= 8;
}

bool Validation::isValidStatus(const std::string& status) {
    return status == "Present" || status == "Absent" || status == "Late";
}

bool Validation::isValidDate(const std::string& dateStr) {
    const std::regex pattern(R"(^\d{4}-\d{2}-\d{2}$)");
    if (!std::regex_match(dateStr, pattern)) return false;
    int year = std::stoi(dateStr.substr(0, 4));
    int month = std::stoi(dateStr.substr(5, 2));
    int day = std::stoi(dateStr.substr(8, 2));
    if (year < 2000 || year > 2100) return false;
    if (month < 1 || month > 12) return false;
    if (day < 1 || day > 31) return false;
    return true;
}

std::string Validation::trim(const std::string& str) {
    size_t first = str.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return "";
    size_t last = str.find_last_not_of(" \t\r\n");
    return str.substr(first, (last - first + 1));
}

std::string Validation::toUpper(const std::string& str) {
    std::string result = str;
    std::transform(result.begin(), result.end(), result.begin(), ::toupper);
    return result;
}

} // namespace utils
} // namespace attendx

