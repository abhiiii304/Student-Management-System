#pragma once
#include <string>
#include <vector>
#include <regex>

namespace attendx {
namespace utils {

struct ValidationResult {
    bool valid = true;
    std::vector<std::string> errors;

    void addError(const std::string& err) {
        valid = false;
        errors.push_back(err);
    }
};

class Validation {
public:
    static bool isValidEmail(const std::string& email);
    static bool isValidPhone(const std::string& phone);
    static bool isValidSemester(int semester);
    static bool isValidStatus(const std::string& status);
    static bool isValidDate(const std::string& dateStr); // YYYY-MM-DD
    static std::string trim(const std::string& str);
    static std::string toUpper(const std::string& str);
};

} // namespace utils
} // namespace attendx

