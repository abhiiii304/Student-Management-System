/**
 * ATTENDX — Centralized API Client & Utilities
 */

const API = {
  baseUrl: '',

  getToken() {
    return localStorage.getItem('attendx_token') || '';
  },

  setToken(token) {
    if (token) {
      localStorage.setItem('attendx_token', token);
    } else {
      localStorage.removeItem('attendx_token');
    }
  },

  getUser() {
    const u = localStorage.getItem('attendx_user');
    try {
      return u ? JSON.parse(u) : null;
    } catch (e) {
      return null;
    }
  },

  setUser(user) {
    if (user) {
      localStorage.setItem('attendx_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('attendx_user');
    }
  },

  async request(endpoint, options = {}) {
    const url = endpoint.startsWith('http') ? endpoint : `${this.baseUrl}${endpoint}`;
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers,
    };

    const token = this.getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    try {
      const response = await fetch(url, {
        ...options,
        headers,
      });

      // Handle 401 Unauthorized (except on login page)
      if (response.status === 401 && !window.location.pathname.includes('login')) {
        this.setToken(null);
        this.setUser(null);
        window.location.href = '/login.html';
        return { success: false, message: 'Session expired' };
      }

      // Check if response is JSON or blob (e.g. CSV)
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        const json = await response.json();
        return json;
      } else if (contentType && contentType.includes('text/csv')) {
        const blob = await response.blob();
        return { success: true, blob };
      }

      const text = await response.text();
      return { success: response.ok, data: text };
    } catch (err) {
      console.error('[API Error]:', err);
      showToast('Network error: Unable to connect to server', 'error');
      return { success: false, message: 'Network connection failed' };
    }
  },

  get(endpoint, params = {}) {
    const query = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null && v !== '') {
        query.append(k, v);
      }
    }
    const qStr = query.toString();
    const url = qStr ? `${endpoint}?${qStr}` : endpoint;
    return this.request(url, { method: 'GET' });
  },

  post(endpoint, body = {}) {
    return this.request(endpoint, {
      method: 'POST',
      body: JSON.stringify(body),
    });
  },

  put(endpoint, body = {}) {
    return this.request(endpoint, {
      method: 'PUT',
      body: JSON.stringify(body),
    });
  },

  delete(endpoint, params = {}) {
    const query = new URLSearchParams(params).toString();
    const url = query ? `${endpoint}?${query}` : endpoint;
    return this.request(url, { method: 'DELETE' });
  },

  async downloadCsv(endpoint, params = {}, defaultFilename = 'report.csv') {
    const query = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null && v !== '') {
        query.append(k, v);
      }
    }
    const url = `${endpoint}?${query.toString()}`;
    const token = this.getToken();
    const headers = token ? { Authorization: `Bearer ${token}` } : {};

    try {
      const res = await fetch(url, { headers });
      if (!res.ok) throw new Error('Download failed');
      const blob = await res.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = defaultFilename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(downloadUrl);
      showToast('Report downloaded successfully', 'success');
    } catch (e) {
      showToast('Failed to download report', 'error');
    }
  }
};

/**
 * Toast Notifications
 */
function showToast(message, type = 'info', duration = 3500) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  
  let iconSvg = '';
  if (type === 'success') {
    iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#22C55E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`;
  } else if (type === 'error') {
    iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>`;
  } else if (type === 'warning') {
    iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>`;
  } else {
    iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#4F8CFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`;
  }

  toast.innerHTML = `
    <div style="flex-shrink:0;">${iconSvg}</div>
    <div style="flex:1;">${escapeHtml(message)}</div>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.transition = 'opacity 0.25s ease, transform 0.25s ease';
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    setTimeout(() => toast.remove(), 250);
  }, duration);
}

function escapeHtml(text) {
  if (!text) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function debounce(func, delay = 300) {
  let timer;
  return function (...args) {
    clearTimeout(timer);
    timer = setTimeout(() => func.apply(this, args), delay);
  };
}

function formatPercentage(num) {
  if (num === null || num === undefined || isNaN(num)) return '0.0%';
  return `${parseFloat(num).toFixed(1)}%`;
}

function getStatusBadge(status) {
  if (status === 'Present') {
    return `<span class="badge badge-success">Present</span>`;
  } else if (status === 'Absent') {
    return `<span class="badge badge-danger">Absent</span>`;
  } else if (status === 'Late') {
    return `<span class="badge badge-warning">Late</span>`;
  }
  return `<span class="badge badge-neutral">${escapeHtml(status || 'N/A')}</span>`;
}

function getAttendancePill(percentage) {
  const p = parseFloat(percentage) || 0;
  if (p >= 75) {
    return `<span class="badge badge-success">${p.toFixed(1)}%</span>`;
  } else {
    return `<span class="badge badge-danger" title="Low Attendance Alert (<75%)">${p.toFixed(1)}% (Low)</span>`;
  }
}

