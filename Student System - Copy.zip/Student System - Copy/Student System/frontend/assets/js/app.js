/**
 * ATTENDX — Global Layout & Navigation Controller
 */

document.addEventListener('DOMContentLoaded', () => {
  initLayout();
  checkAuth();
  updateLiveDate();
});

function initLayout() {
  const sidebar = document.querySelector('.sidebar');
  const collapseBtn = document.querySelector('.collapse-btn');
  const mobileToggle = document.querySelector('.mobile-toggle-btn');

  // Sidebar collapse toggle for desktop
  if (collapseBtn && sidebar) {
    // Restore collapsed state
    const isCollapsed = localStorage.getItem('attendx_sidebar_collapsed') === 'true';
    if (isCollapsed) {
      sidebar.classList.add('collapsed');
      document.body.classList.add('sidebar-collapsed');
    }

    collapseBtn.addEventListener('click', () => {
      sidebar.classList.toggle('collapsed');
      document.body.classList.toggle('sidebar-collapsed');
      localStorage.setItem('attendx_sidebar_collapsed', sidebar.classList.contains('collapsed'));
    });
  }

  // Mobile menu toggle
  if (mobileToggle && sidebar) {
    mobileToggle.addEventListener('click', (e) => {
      e.stopPropagation();
      sidebar.classList.toggle('mobile-open');
    });

    document.addEventListener('click', (e) => {
      if (sidebar.classList.contains('mobile-open') && !sidebar.contains(e.target) && e.target !== mobileToggle) {
        sidebar.classList.remove('mobile-open');
      }
    });
  }

  // Active navigation link highlighting
  const currentPath = window.location.pathname.toLowerCase();
  const navItems = document.querySelectorAll('.nav-item');
  navItems.forEach(item => {
    const href = item.getAttribute('href').toLowerCase();
    if (currentPath === href || (href === '/' && (currentPath === '' || currentPath === '/' || currentPath.endsWith('index.html')))) {
      item.classList.add('active');
    } else if (href !== '/' && currentPath.includes(href.replace('.html', ''))) {
      item.classList.add('active');
    } else {
      item.classList.remove('active');
    }
  });

  // Logout button
  const logoutBtn = document.querySelector('.logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async () => {
      if (confirm('Are you sure you want to sign out?')) {
        await API.post('/api/auth/logout');
        API.setToken(null);
        API.setUser(null);
        showToast('Signed out successfully', 'info');
        setTimeout(() => {
          window.location.href = '/login.html';
        }, 300);
      }
    });
  }

  // Quick Seed Button in topbar (if present)
  const seedBtn = document.querySelector('.quick-seed-btn');
  if (seedBtn) {
    seedBtn.addEventListener('click', async () => {
      if (confirm('Populate database with demo students, classes, subjects, and attendance history?')) {
        seedBtn.disabled = true;
        seedBtn.innerHTML = `<span class="spinner" style="width:14px;height:14px;"></span> Seeding...`;
        const res = await API.post('/api/seed?force=true');
        if (res.success) {
          showToast(res.message || 'Demo data loaded successfully!', 'success');
          setTimeout(() => window.location.reload(), 1000);
        } else {
          showToast(res.message || 'Seeding failed', 'error');
          seedBtn.disabled = false;
          seedBtn.innerHTML = `<span>⚡</span> Load Demo Data`;
        }
      }
    });
  }
}

async function checkAuth() {
  const path = window.location.pathname.toLowerCase();
  if (path.includes('login')) return;

  const token = API.getToken();
  if (!token) {
    // If not logged in, redirect to login page
    window.location.href = '/login.html';
    return;
  }

  const res = await API.get('/api/auth/me');
  if (res.success && res.data) {
    API.setUser(res.data);
    const userNameEl = document.querySelector('.user-name');
    const userRoleEl = document.querySelector('.user-role');
    const avatarEl = document.querySelector('.avatar');

    if (userNameEl) userNameEl.textContent = res.data.username || 'Administrator';
    if (userRoleEl) userRoleEl.textContent = (res.data.role || 'Admin').toUpperCase();
    if (avatarEl && res.data.username) {
      avatarEl.textContent = res.data.username.charAt(0).toUpperCase();
    }
  } else {
    API.setToken(null);
    window.location.href = '/login.html';
  }
}

function updateLiveDate() {
  const dateEl = document.getElementById('live-date-display');
  if (dateEl) {
    const now = new Date();
    const options = { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' };
    dateEl.textContent = now.toLocaleDateString('en-US', options);
  }
}

// Modal helper functions
function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('open');
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('open');
  }
}

