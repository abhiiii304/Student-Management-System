/**
 * ATTENDX — Attendance Management Controller
 */

let currentAttendanceRecords = new Map(); // studentId -> 'Present' | 'Absent' | 'Late'
let studentList = [];
let isEditingExisting = false;

document.addEventListener('DOMContentLoaded', () => {
  initAttendanceControls();
  loadClassOptions();
  loadSubjectOptions();
});

function initAttendanceControls() {
  const dateInput = document.getElementById('att-date');
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.value = today;
    dateInput.max = today;
  }

  // Load button
  const loadBtn = document.getElementById('load-attendance-btn');
  if (loadBtn) {
    loadBtn.addEventListener('click', loadAttendanceRoster);
  }

  // Bulk status buttons
  const markAllPresentBtn = document.getElementById('mark-all-present-btn');
  const markAllAbsentBtn = document.getElementById('mark-all-absent-btn');
  const resetAttendanceBtn = document.getElementById('reset-attendance-btn');

  if (markAllPresentBtn) {
    markAllPresentBtn.addEventListener('click', () => setAllStatus('Present'));
  }
  if (markAllAbsentBtn) {
    markAllAbsentBtn.addEventListener('click', () => setAllStatus('Absent'));
  }
  if (resetAttendanceBtn) {
    resetAttendanceBtn.addEventListener('click', () => {
      studentList.forEach(s => currentAttendanceRecords.set(s.id, 'Present'));
      renderAttendanceTable();
      updateAttendanceSummary();
    });
  }

  // Save attendance
  const saveBtn = document.getElementById('save-attendance-btn');
  if (saveBtn) {
    saveBtn.addEventListener('click', saveAttendance);
  }

  // Search students inside roster
  const searchInput = document.getElementById('roster-search');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const q = e.target.value.toLowerCase().trim();
      filterRoster(q);
    });
  }
}

async function loadClassOptions() {
  const select = document.getElementById('att-class-select');
  if (!select) return;

  const res = await API.get('/api/classes');
  if (res.success && res.data) {
    select.innerHTML = '<option value="">-- Select Class --</option>' +
      res.data.map(c => `
        <option value="${c.id}" data-branch="${c.branch}" data-semester="${c.semester}" data-section="${c.section}">
          ${c.branch} - Semester ${c.semester} (Sec ${c.section}) [${c.academic_year || 'Current'}]
        </option>
      `).join('');
  }
}

async function loadSubjectOptions() {
  const select = document.getElementById('att-subject-select');
  if (!select) return;

  const res = await API.get('/api/subjects');
  if (res.success && res.data) {
    select.innerHTML = '<option value="">-- Select Subject --</option>' +
      res.data.map(s => `
        <option value="${s.id}" data-class-id="${s.class_id || ''}" data-branch="${s.branch}" data-semester="${s.semester}" data-section="${s.section}">
          ${s.subject_code} - ${s.subject_name} (${s.faculty_name || 'Faculty'})
        </option>
      `).join('');
  }
}

async function loadAttendanceRoster() {
  const classSelect = document.getElementById('att-class-select');
  const subjectSelect = document.getElementById('att-subject-select');
  const dateInput = document.getElementById('att-date');

  const classId = classSelect ? classSelect.value : '';
  const subjectId = subjectSelect ? subjectSelect.value : '';
  const date = dateInput ? dateInput.value : '';

  if (!classId) {
    showToast('Please select a class first', 'warning');
    return;
  }
  if (!subjectId) {
    showToast('Please select a subject first', 'warning');
    return;
  }
  if (!date) {
    showToast('Please select an attendance date', 'warning');
    return;
  }

  const selectedOpt = classSelect.options[classSelect.selectedIndex];
  const branch = selectedOpt.getAttribute('data-branch') || '';
  const semester = selectedOpt.getAttribute('data-semester') || '';
  const section = selectedOpt.getAttribute('data-section') || '';

  const tbody = document.getElementById('attendance-table-body');
  tbody.innerHTML = `
    <tr>
      <td colspan="4" style="text-align: center; padding: 2.5rem;">
        <div style="display:flex;align-items:center;justify-content:center;gap:0.75rem;">
          <div class="spinner"></div>
          <span style="color:var(--text-muted);">Fetching students and previous attendance records...</span>
        </div>
      </td>
    </tr>
  `;

  // 1. Fetch Students belonging to this class
  const studentsRes = await API.get('/api/students', {
    branch,
    semester,
    section,
    limit: 200
  });

  if (!studentsRes.success || !studentsRes.data || !studentsRes.data.students || studentsRes.data.students.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="4">
          <div class="empty-state">
            <div class="empty-title">No Students Enrolled</div>
            <div class="empty-desc">There are no active students in ${branch} Sem ${semester} Sec ${section}. Add students or choose another class.</div>
            <a href="/students.html" class="btn btn-secondary btn-sm">Go to Student Management</a>
          </div>
        </td>
      </tr>
    `;
    studentList = [];
    currentAttendanceRecords.clear();
    updateAttendanceSummary();
    return;
  }

  studentList = studentsRes.data.students;

  // 2. Check if attendance already exists for this subject and date
  const existingRes = await API.get('/api/attendance', {
    subject_id: subjectId,
    date: date
  });

  currentAttendanceRecords.clear();
  isEditingExisting = false;

  const existingMap = new Map();
  if (existingRes.success && existingRes.data && existingRes.data.length > 0) {
    existingRes.data.forEach(item => {
      existingMap.set(item.student_id, item.status);
    });
    isEditingExisting = true;
  }

  // Prepopulate statuses
  studentList.forEach(s => {
    if (existingMap.has(s.id)) {
      currentAttendanceRecords.set(s.id, existingMap.get(s.id));
    } else {
      currentAttendanceRecords.set(s.id, 'Present'); // Default Present
    }
  });

  const banner = document.getElementById('attendance-status-banner');
  if (banner) {
    if (isEditingExisting) {
      banner.style.display = 'block';
      banner.className = 'demo-credentials-box';
      banner.style.border = '1px solid rgba(245, 158, 11, 0.4)';
      banner.style.background = 'rgba(245, 158, 11, 0.08)';
      banner.innerHTML = `
        <span style="color:var(--warning);font-weight:700;">Notice:</span>
        Attendance records for <strong>${escapeHtml(date)}</strong> already exist. Modifying records below will update previously saved entries.
      `;
    } else {
      banner.style.display = 'none';
    }
  }

  // Enable action controls
  document.getElementById('attendance-actions-card').style.display = 'block';
  renderAttendanceTable();
  updateAttendanceSummary();
}

function renderAttendanceTable() {
  const tbody = document.getElementById('attendance-table-body');
  if (!tbody) return;

  tbody.innerHTML = studentList.map(s => {
    const status = currentAttendanceRecords.get(s.id) || 'Present';
    return `
      <tr data-student-id="${s.id}" data-search-text="${(s.name + ' ' + s.roll_number + ' ' + s.enrollment_id).toLowerCase()}">
        <td style="font-weight:600;font-family:monospace;color:var(--accent-secondary);">${escapeHtml(s.enrollment_id)}</td>
        <td style="font-weight:600;">${escapeHtml(s.roll_number || '—')}</td>
        <td>
          <div style="font-weight:600;color:var(--text-primary);">${escapeHtml(s.name)}</div>
          <div style="font-size:0.75rem;color:var(--text-muted);">${escapeHtml(s.email || '')}</div>
        </td>
        <td>
          <div class="status-btn-group">
            <button type="button" class="status-opt-btn ${status === 'Present' ? 'active present' : ''}" onclick="setStatus(${s.id}, 'Present')">
              Present
            </button>
            <button type="button" class="status-opt-btn ${status === 'Late' ? 'active late' : ''}" onclick="setStatus(${s.id}, 'Late')">
              Late
            </button>
            <button type="button" class="status-opt-btn ${status === 'Absent' ? 'active absent' : ''}" onclick="setStatus(${s.id}, 'Absent')">
              Absent
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

function setStatus(studentId, newStatus) {
  currentAttendanceRecords.set(studentId, newStatus);
  const row = document.querySelector(`tr[data-student-id="${studentId}"]`);
  if (row) {
    const btns = row.querySelectorAll('.status-opt-btn');
    btns.forEach(b => {
      b.className = 'status-opt-btn';
      if (b.textContent.trim().toLowerCase() === newStatus.toLowerCase()) {
        b.classList.add('active', newStatus.toLowerCase());
      }
    });
  }
  updateAttendanceSummary();
}

function setAllStatus(newStatus) {
  studentList.forEach(s => {
    currentAttendanceRecords.set(s.id, newStatus);
  });
  renderAttendanceTable();
  updateAttendanceSummary();
}

function updateAttendanceSummary() {
  let present = 0, absent = 0, late = 0;
  currentAttendanceRecords.forEach(status => {
    if (status === 'Present') present++;
    else if (status === 'Absent') absent++;
    else if (status === 'Late') late++;
  });

  const total = currentAttendanceRecords.size;
  const pct = total > 0 ? (present / total) * 100 : 0;

  const totalEl = document.getElementById('sum-total');
  const presEl = document.getElementById('sum-present');
  const absEl = document.getElementById('sum-absent');
  const lateEl = document.getElementById('sum-late');
  const pctEl = document.getElementById('sum-percentage');

  if (totalEl) totalEl.textContent = total;
  if (presEl) presEl.textContent = present;
  if (absEl) absEl.textContent = absent;
  if (lateEl) lateEl.textContent = late;
  if (pctEl) pctEl.textContent = `${pct.toFixed(1)}%`;
}

function filterRoster(q) {
  const rows = document.querySelectorAll('#attendance-table-body tr');
  rows.forEach(r => {
    const text = r.getAttribute('data-search-text') || '';
    if (!q || text.includes(q)) {
      r.style.display = '';
    } else {
      r.style.display = 'none';
    }
  });
}

async function saveAttendance() {
  const classSelect = document.getElementById('att-class-select');
  const subjectSelect = document.getElementById('att-subject-select');
  const dateInput = document.getElementById('att-date');

  const classId = classSelect ? parseInt(classSelect.value, 10) : 0;
  const subjectId = subjectSelect ? parseInt(subjectSelect.value, 10) : 0;
  const date = dateInput ? dateInput.value : '';

  if (!classId || !subjectId || !date) {
    showToast('Class, Subject, and Date are required', 'warning');
    return;
  }

  if (currentAttendanceRecords.size === 0) {
    showToast('No students loaded in roster to save', 'warning');
    return;
  }

  const saveBtn = document.getElementById('save-attendance-btn');
  saveBtn.disabled = true;
  saveBtn.innerHTML = `<span class="spinner" style="width:14px;height:14px;"></span> Saving to Database...`;

  const records = [];
  currentAttendanceRecords.forEach((status, studentId) => {
    records.push({
      student_id: studentId,
      status: status
    });
  });

  const payload = {
    class_id: classId,
    subject_id: subjectId,
    attendance_date: date,
    records: records
  };

  const res = await API.post('/api/attendance/bulk', payload);
  saveBtn.disabled = false;
  saveBtn.innerHTML = `Save Attendance`;

  if (res.success) {
    showToast(res.message || 'Attendance records saved successfully!', 'success');
    isEditingExisting = true;
    const banner = document.getElementById('attendance-status-banner');
    if (banner) {
      banner.style.display = 'block';
      banner.className = 'demo-credentials-box';
      banner.style.border = '1px solid rgba(34, 197, 94, 0.4)';
      banner.style.background = 'rgba(34, 197, 94, 0.08)';
      banner.innerHTML = `
        <span style="color:var(--success);font-weight:700;">Saved:</span>
        Attendance successfully recorded for <strong>${records.length} students</strong> on <strong>${escapeHtml(date)}</strong>.
      `;
    }
  } else {
    showToast(res.message || 'Failed to save attendance', 'error');
  }
}

