/**
 * ATTENDX — Classes & Subjects Management Controller
 */

let activeTab = 'classes';
let isEditingClass = false;
let editingClassId = null;
let isEditingSubject = false;
let editingSubjectId = null;

document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  loadClasses();
  loadSubjects();
  setupClassForm();
  setupSubjectForm();
  setupDeleteHandlers();
});

function initTabs() {
  const tabBtns = document.querySelectorAll('.tab-btn');
  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeTab = btn.dataset.tab;

      if (activeTab === 'classes') {
        document.getElementById('classes-section').style.display = 'block';
        document.getElementById('subjects-section').style.display = 'none';
      } else {
        document.getElementById('classes-section').style.display = 'none';
        document.getElementById('subjects-section').style.display = 'block';
      }
    });
  });

  // Search boxes
  const classSearch = document.getElementById('class-search');
  if (classSearch) {
    classSearch.addEventListener('input', debounce((e) => {
      loadClasses(e.target.value.trim());
    }, 300));
  }

  const subjectSearch = document.getElementById('subject-search');
  if (subjectSearch) {
    subjectSearch.addEventListener('input', debounce((e) => {
      loadSubjects(e.target.value.trim());
    }, 300));
  }
}

async function loadClasses(search = '') {
  const tbody = document.getElementById('classes-tbody');
  if (!tbody) return;

  const res = await API.get('/api/classes', { search });
  if (!res.success || !res.data || res.data.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7">
          <div class="empty-state">
            <div class="empty-title">No Classes Found</div>
            <div class="empty-desc">Create your first class section or load demo data.</div>
            <button class="btn btn-primary" onclick="openAddClassModal()">+ Create Class</button>
          </div>
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = res.data.map(c => `
    <tr>
      <td style="font-size: 0.8rem; color: var(--text-muted); font-family: monospace;">#${c.id}</td>
      <td style="font-weight: 700; color: var(--accent-primary);">${escapeHtml(c.branch)}</td>
      <td style="font-weight: 600;">Semester ${c.semester}</td>
      <td style="font-weight: 600;"><span class="badge badge-neutral">Section ${escapeHtml(c.section)}</span></td>
      <td>${escapeHtml(c.academic_year || 'Current')}</td>
      <td>
        <span style="font-weight:600;color:var(--text-primary);">${c.student_count || 0}</span> students &bull;
        <span style="font-weight:600;color:var(--accent-secondary);">${c.subject_count || 0}</span> subjects
      </td>
      <td>
        <div class="table-actions">
          <button class="btn btn-secondary btn-sm" onclick="viewClassDetails(${c.id})">View</button>
          <button class="btn btn-secondary btn-sm" onclick="openEditClassModal(${c.id})">Edit</button>
          <button class="btn btn-outline-danger btn-sm" onclick="deleteClassConfirm(${c.id})">Delete</button>
        </div>
      </td>
    </tr>
  `).join('');

  // Also update class select inside subject form modal
  updateClassDropdowns(res.data);
}

async function loadSubjects(search = '') {
  const tbody = document.getElementById('subjects-tbody');
  if (!tbody) return;

  const res = await API.get('/api/subjects', { search });
  if (!res.success || !res.data || res.data.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="8">
          <div class="empty-state">
            <div class="empty-title">No Subjects Found</div>
            <div class="empty-desc">Add academic subjects and assign faculty.</div>
            <button class="btn btn-primary" onclick="openAddSubjectModal()">+ Add Subject</button>
          </div>
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = res.data.map(s => `
    <tr>
      <td style="font-weight:700;font-family:monospace;color:var(--accent-secondary);">${escapeHtml(s.subject_code)}</td>
      <td>
        <div style="font-weight:600;color:var(--text-primary);">${escapeHtml(s.subject_name)}</div>
      </td>
      <td style="color:var(--text-secondary);">${escapeHtml(s.faculty_name || 'Unassigned')}</td>
      <td><span class="badge badge-neutral">${escapeHtml(s.branch)}</span></td>
      <td>Sem ${s.semester}</td>
      <td>${escapeHtml(s.section || 'All')}</td>
      <td>
        ${s.total_sessions > 0 ? getAttendancePill(s.average_attendance) : '<span style="color:var(--text-muted);font-size:0.8rem;">No sessions</span>'}
      </td>
      <td>
        <div class="table-actions">
          <button class="btn btn-secondary btn-sm" onclick="viewSubjectDetails(${s.id})">View</button>
          <button class="btn btn-secondary btn-sm" onclick="openEditSubjectModal(${s.id})">Edit</button>
          <button class="btn btn-outline-danger btn-sm" onclick="deleteSubjectConfirm(${s.id})">Delete</button>
        </div>
      </td>
    </tr>
  `).join('');
}

function updateClassDropdowns(classes) {
  const select = document.getElementById('m-subject-class');
  if (!select) return;
  select.innerHTML = '<option value="">-- No Specific Class Assigned --</option>' +
    classes.map(c => `
      <option value="${c.id}">
        ${c.branch} Sem ${c.semester} Sec ${c.section} (${c.academic_year || 'Current'})
      </option>
    `).join('');
}

/* Class Form */
function openAddClassModal() {
  isEditingClass = false;
  editingClassId = null;
  document.getElementById('class-modal-title').textContent = 'Create New Class';
  document.getElementById('class-modal-form').reset();
  openModal('class-modal');
}

async function openEditClassModal(id) {
  isEditingClass = true;
  editingClassId = id;
  document.getElementById('class-modal-title').textContent = 'Edit Class Details';

  const res = await API.get(`/api/classes/${id}`);
  if (res.success && res.data) {
    const c = res.data;
    document.getElementById('m-class-branch').value = c.branch;
    document.getElementById('m-class-semester').value = c.semester;
    document.getElementById('m-class-section').value = c.section;
    document.getElementById('m-class-year').value = c.academic_year || '';
    openModal('class-modal');
  }
}

function setupClassForm() {
  const form = document.getElementById('class-modal-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      branch: document.getElementById('m-class-branch').value.trim(),
      semester: parseInt(document.getElementById('m-class-semester').value, 10),
      section: document.getElementById('m-class-section').value.trim(),
      academic_year: document.getElementById('m-class-year').value.trim(),
    };

    let res;
    if (isEditingClass && editingClassId) {
      res = await API.put(`/api/classes/${editingClassId}`, payload);
    } else {
      res = await API.post('/api/classes', payload);
    }

    if (res.success) {
      showToast(res.message || 'Class saved successfully', 'success');
      closeModal('class-modal');
      loadClasses();
    } else {
      showToast(res.message || 'Failed to save class', 'error');
    }
  });
}

/* Subject Form */
function openAddSubjectModal() {
  isEditingSubject = false;
  editingSubjectId = null;
  document.getElementById('subject-modal-title').textContent = 'Add New Subject';
  document.getElementById('subject-modal-form').reset();
  openModal('subject-modal');
}

async function openEditSubjectModal(id) {
  isEditingSubject = true;
  editingSubjectId = id;
  document.getElementById('subject-modal-title').textContent = 'Edit Subject';

  const res = await API.get(`/api/subjects/${id}`);
  if (res.success && res.data) {
    const s = res.data;
    document.getElementById('m-subject-name').value = s.subject_name;
    document.getElementById('m-subject-code').value = s.subject_code;
    document.getElementById('m-subject-branch').value = s.branch || 'CSE';
    document.getElementById('m-subject-semester').value = s.semester;
    document.getElementById('m-subject-section').value = s.section || '';
    document.getElementById('m-subject-faculty').value = s.faculty_name || '';
    if (s.class_id) document.getElementById('m-subject-class').value = s.class_id;
    openModal('subject-modal');
  }
}

function setupSubjectForm() {
  const form = document.getElementById('subject-modal-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const classVal = document.getElementById('m-subject-class').value;
    const payload = {
      subject_name: document.getElementById('m-subject-name').value.trim(),
      subject_code: document.getElementById('m-subject-code').value.trim(),
      branch: document.getElementById('m-subject-branch').value.trim(),
      semester: parseInt(document.getElementById('m-subject-semester').value, 10),
      section: document.getElementById('m-subject-section').value.trim(),
      faculty_name: document.getElementById('m-subject-faculty').value.trim(),
      class_id: classVal ? parseInt(classVal, 10) : 0,
    };

    let res;
    if (isEditingSubject && editingSubjectId) {
      res = await API.put(`/api/subjects/${editingSubjectId}`, payload);
    } else {
      res = await API.post('/api/subjects', payload);
    }

    if (res.success) {
      showToast(res.message || 'Subject saved successfully', 'success');
      closeModal('subject-modal');
      loadSubjects();
    } else {
      showToast(res.message || 'Failed to save subject', 'error');
    }
  });
}

/* Details Modals */
async function viewClassDetails(id) {
  const res = await API.get(`/api/classes/${id}`);
  if (!res.success || !res.data) return;
  const c = res.data;
  document.getElementById('v-class-title').textContent = `${c.branch} - Sem ${c.semester} Sec ${c.section}`;
  document.getElementById('v-class-students-count').textContent = c.student_count || 0;
  document.getElementById('v-class-subjects-count').textContent = c.subject_count || 0;
  document.getElementById('v-class-year').textContent = c.academic_year || 'Current';

  // Load students for this class
  const stRes = await API.get('/api/students', { branch: c.branch, semester: c.semester, section: c.section, limit: 100 });
  const stListEl = document.getElementById('v-class-student-list');
  if (stListEl) {
    if (stRes.success && stRes.data && stRes.data.students && stRes.data.students.length > 0) {
      stListEl.innerHTML = stRes.data.students.map(s => `
        <div style="display:flex;justify-content:space-between;padding:0.4rem 0;border-bottom:1px solid var(--border-subtle);font-size:0.85rem;">
          <div><strong>${escapeHtml(s.name)}</strong> (${escapeHtml(s.roll_number)})</div>
          <div>${s.total_classes > 0 ? getAttendancePill(s.attendance_percentage) : 'No data'}</div>
        </div>
      `).join('');
    } else {
      stListEl.innerHTML = '<div style="color:var(--text-muted);font-size:0.85rem;padding:0.5rem 0;">No students enrolled yet.</div>';
    }
  }

  openModal('class-detail-modal');
}

async function viewSubjectDetails(id) {
  const res = await API.get(`/api/subjects/${id}`);
  if (!res.success || !res.data) return;
  const s = res.data;
  document.getElementById('v-subject-title').textContent = `${s.subject_code} - ${s.subject_name}`;
  document.getElementById('v-subject-faculty').textContent = s.faculty_name || 'Unassigned';
  document.getElementById('v-subject-branch-sem').textContent = `${s.branch} Sem ${s.semester} (Sec ${s.section || 'All'})`;
  document.getElementById('v-subject-students-count').textContent = s.student_count || 0;
  document.getElementById('v-subject-sessions-count').textContent = s.total_sessions || 0;
  document.getElementById('v-subject-avg-att').textContent = `${s.average_attendance.toFixed(1)}%`;
  openModal('subject-detail-modal');
}

/* Delete handlers */
let itemToDelete = null;

function deleteClassConfirm(id) {
  itemToDelete = { type: 'class', id };
  document.getElementById('delete-item-desc').textContent = 'class and remove its subject associations';
  openModal('generic-delete-modal');
}

function deleteSubjectConfirm(id) {
  itemToDelete = { type: 'subject', id };
  document.getElementById('delete-item-desc').textContent = 'subject and its related attendance logs';
  openModal('generic-delete-modal');
}

function setupDeleteHandlers() {
  const btn = document.getElementById('confirm-generic-delete-btn');
  if (!btn) return;
  btn.addEventListener('click', async () => {
    if (!itemToDelete) return;
    btn.disabled = true;
    let res;
    if (itemToDelete.type === 'class') {
      res = await API.delete(`/api/classes/${itemToDelete.id}`);
    } else {
      res = await API.delete(`/api/subjects/${itemToDelete.id}`);
    }
    btn.disabled = false;
    closeModal('generic-delete-modal');

    if (res.success) {
      showToast(res.message || 'Deleted successfully', 'success');
      if (itemToDelete.type === 'class') loadClasses();
      else loadSubjects();
    } else {
      showToast(res.message || 'Failed to delete', 'error');
    }
  });
}

