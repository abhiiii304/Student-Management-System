/**
 * ATTENDX — Dashboard Controller
 */

let trendsChart = null;
let distributionChart = null;

document.addEventListener('DOMContentLoaded', () => {
  loadDashboardStats();
  loadAttendanceTrends('daily');
  loadAttendanceDistribution();
  loadRecentActivity();
  loadLowAttendanceAlerts();
  setupTrendButtons();
});

async function loadDashboardStats() {
  const res = await API.get('/api/dashboard/stats');
  if (res.success && res.data) {
    const s = res.data;
    document.getElementById('stat-total-students').textContent = s.total_students || 0;
    document.getElementById('stat-today-present').textContent = s.today_present || 0;
    document.getElementById('stat-today-absent').textContent = s.today_absent || 0;
    document.getElementById('stat-overall-rate').textContent = `${(s.overall_attendance_rate || 0).toFixed(1)}%`;
    document.getElementById('stat-total-classes').textContent = s.total_classes || 0;
    document.getElementById('stat-total-subjects').textContent = s.total_subjects || 0;
  }
}

function setupTrendButtons() {
  const btns = document.querySelectorAll('.trend-range-btn');
  btns.forEach(btn => {
    btn.addEventListener('click', () => {
      btns.forEach(b => b.classList.remove('btn-primary'));
      btns.forEach(b => b.classList.add('btn-secondary'));
      btn.classList.remove('btn-secondary');
      btn.classList.add('btn-primary');

      const range = btn.dataset.range || 'daily';
      loadAttendanceTrends(range);
    });
  });
}

async function loadAttendanceTrends(range = 'daily') {
  const res = await API.get('/api/dashboard/attendance-trends', { range });
  const ctx = document.getElementById('attendanceTrendsChart');
  if (!ctx) return;

  const labels = [];
  const presentData = [];
  const absentData = [];
  const lateData = [];

  if (res.success && res.data && res.data.length > 0) {
    res.data.forEach(item => {
      labels.push(item.date);
      presentData.push(item.present);
      absentData.push(item.absent);
      lateData.push(item.late);
    });
  }

  if (trendsChart) {
    trendsChart.destroy();
  }

  if (labels.length === 0) {
    // Show empty indicator on chart canvas
    labels.push('No Data');
    presentData.push(0);
  }

  trendsChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Present',
          data: presentData,
          backgroundColor: '#22C55E',
          borderRadius: 4,
        },
        {
          label: 'Late',
          data: lateData,
          backgroundColor: '#F59E0B',
          borderRadius: 4,
        },
        {
          label: 'Absent',
          data: absentData,
          backgroundColor: '#EF4444',
          borderRadius: 4,
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'top',
          labels: {
            color: '#94A3B8',
            font: { family: 'inherit', size: 12 }
          }
        },
        tooltip: {
          backgroundColor: '#151D30',
          titleColor: '#F8FAFC',
          bodyColor: '#94A3B8',
          borderColor: '#273449',
          borderWidth: 1,
          padding: 10
        }
      },
      scales: {
        x: {
          stacked: true,
          grid: { color: 'rgba(39, 52, 73, 0.4)' },
          ticks: { color: '#64748B' }
        },
        y: {
          stacked: true,
          grid: { color: 'rgba(39, 52, 73, 0.4)' },
          ticks: { color: '#64748B', precision: 0 }
        }
      }
    }
  });
}

async function loadAttendanceDistribution() {
  const res = await API.get('/api/dashboard/attendance-distribution');
  const ctx = document.getElementById('attendanceDistChart');
  if (!ctx) return;

  let present = 0, absent = 0, late = 0;
  if (res.success && res.data) {
    present = res.data.present || 0;
    absent = res.data.absent || 0;
    late = res.data.late || 0;
  }

  if (distributionChart) {
    distributionChart.destroy();
  }

  const hasData = (present + absent + late) > 0;
  const chartData = hasData ? [present, absent, late] : [1];
  const chartColors = hasData ? ['#22C55E', '#EF4444', '#F59E0B'] : ['#273449'];
  const chartLabels = hasData ? ['Present', 'Absent', 'Late'] : ['No Data'];

  distributionChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: chartLabels,
      datasets: [{
        data: chartData,
        backgroundColor: chartColors,
        borderColor: '#151D30',
        borderWidth: 3,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '72%',
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            color: '#94A3B8',
            font: { family: 'inherit', size: 12 },
            padding: 15
          }
        },
        tooltip: {
          enabled: hasData,
          backgroundColor: '#151D30',
          titleColor: '#F8FAFC',
          bodyColor: '#94A3B8',
          borderColor: '#273449',
          borderWidth: 1,
        }
      }
    }
  });
}

async function loadRecentActivity() {
  const res = await API.get('/api/dashboard/recent-activity', { limit: 8 });
  const tbody = document.getElementById('recent-activity-tbody');
  if (!tbody) return;

  if (!res.success || !res.data || res.data.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="4" style="text-align: center; color: var(--text-muted); padding: 2rem;">
          No recent activity recorded yet.
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = res.data.map(item => `
    <tr>
      <td>
        <div style="font-weight: 600; color: var(--text-primary);">${escapeHtml(item.student_name)}</div>
        <div style="font-size: 0.75rem; color: var(--text-muted);">${escapeHtml(item.roll_number || item.enrollment_id)}</div>
      </td>
      <td>
        <div style="font-weight: 500;">${escapeHtml(item.subject_name)}</div>
        <div style="font-size: 0.75rem; color: var(--text-muted);">${escapeHtml(item.subject_code)}</div>
      </td>
      <td style="color: var(--text-secondary); font-size: 0.85rem;">${escapeHtml(item.attendance_date)}</td>
      <td>${getStatusBadge(item.status)}</td>
    </tr>
  `).join('');
}

async function loadLowAttendanceAlerts() {
  const res = await API.get('/api/reports/low-attendance', { threshold: 75.0 });
  const container = document.getElementById('low-attendance-container');
  if (!container) return;

  if (!res.success || !res.data || res.data.length === 0) {
    container.innerHTML = `
      <div style="padding: 1.5rem; text-align: center; color: var(--text-muted); font-size: 0.85rem;">
        <span style="color: var(--success); font-size: 1.25rem; display: block; margin-bottom: 0.25rem;">✓</span>
        Great job! No students are currently below the 75% attendance threshold.
      </div>
    `;
    return;
  }

  container.innerHTML = res.data.slice(0, 6).map(s => `
    <div style="display: flex; align-items: center; justify-content: space-between; padding: 0.75rem 0; border-bottom: 1px solid var(--border-subtle);">
      <div>
        <a href="/students.html?search=${encodeURIComponent(s.roll_number || s.name)}" style="font-weight: 600; font-size: 0.875rem; color: var(--text-primary); display: block;">
          ${escapeHtml(s.name)}
        </a>
        <div style="font-size: 0.75rem; color: var(--text-muted);">
          Roll: ${escapeHtml(s.roll_number)} &bull; Sem ${s.semester} (${escapeHtml(s.branch)}-${escapeHtml(s.section)})
        </div>
      </div>
      <div style="text-align: right;">
        <span class="badge badge-danger" style="font-weight: 700;">${s.attendance_percentage.toFixed(1)}%</span>
        <div style="font-size: 0.7rem; color: var(--text-muted); margin-top: 2px;">
          ${s.present_classes}/${s.total_classes} classes
        </div>
      </div>
    </div>
  `).join('');
}

