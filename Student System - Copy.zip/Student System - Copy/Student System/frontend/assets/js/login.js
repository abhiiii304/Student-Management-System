/**
 * ATTENDX — Login Page Controller
 */

document.addEventListener('DOMContentLoaded', () => {
  const token = API.getToken();
  if (token) {
    // If already logged in, redirect to dashboard
    window.location.href = '/';
    return;
  }

  const form = document.getElementById('login-form');
  const demoBtn = document.getElementById('fill-demo-btn');
  const togglePassBtn = document.getElementById('toggle-password-btn');

  if (demoBtn) {
    demoBtn.addEventListener('click', () => {
      document.getElementById('username').value = 'admin';
      document.getElementById('password').value = 'Admin@123';
      showToast('Demo administrator credentials filled', 'info', 2000);
    });
  }

  if (togglePassBtn) {
    togglePassBtn.addEventListener('click', () => {
      const passInput = document.getElementById('password');
      if (passInput.type === 'password') {
        passInput.type = 'text';
        togglePassBtn.textContent = 'Hide';
      } else {
        passInput.type = 'password';
        togglePassBtn.textContent = 'Show';
      }
    });
  }

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = document.getElementById('login-submit-btn');
      const errBox = document.getElementById('login-error-msg');
      if (errBox) errBox.style.display = 'none';

      submitBtn.disabled = true;
      submitBtn.innerHTML = `<span class="spinner" style="width:14px;height:14px;"></span> Authenticating...`;

      const username = document.getElementById('username').value.trim();
      const password = document.getElementById('password').value;

      const res = await API.post('/api/auth/login', { username, password });

      submitBtn.disabled = false;
      submitBtn.innerHTML = `Sign In &rarr;`;

      if (res.success && res.data && res.data.token) {
        API.setToken(res.data.token);
        API.setUser(res.data.user);
        showToast('Login successful! Redirecting...', 'success', 1500);
        setTimeout(() => {
          window.location.href = '/';
        }, 500);
      } else {
        if (errBox) {
          errBox.style.display = 'block';
          errBox.textContent = res.message || 'Invalid username or password';
        }
        showToast(res.message || 'Authentication failed', 'error');
      }
    });
  }
});

