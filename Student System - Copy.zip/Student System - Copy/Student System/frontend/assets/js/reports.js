/**
 * ATTENDX — Reports & Analytics Controller
 */

let currentReportData = [];

document.addEventListener('DOMContentLoaded', () => {
  initReportFilters();
  loadReportClassesAndSubjects();
  generateReport();
});

function initReportFilters() {
  const form = document.getElementById('report-filter-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      generateReport();
    });
  }

  const exportBtn = document.getElementById('export-csv-btn');
  if (exportBtn) {
    exportBtn.addEventListener('click', exportCsv);
  }

  const printBtn = document.getElementById('print-report-btn');
  if (printBtn) {
    printBtn.addEventListener('click', () => {
      window.print();
    });
  }

  // Type change resets or configures date inputs
  const typeSelect = document.getElementById('report-type');
  if (typeSelect) {
    typeSelect.addEventListener('change', () => {
      const val = typeSelect.value;
      const dailyGroup = document.getElementById('daily-date-group');
      const monthlyGroup = document.getElementById('monthly-date-group');
      const rangeGroup = document.getElementById('range-date-group');

      if (dailyGroup) dailyGroup.style.display = val === 'daily' ? 'block' : 'none';
      if (monthlyGroup) monthlyGroup.style.display = val === 'monthly' ? 'block' : 'none';
      if (rangeGroup) rangeGroup.style.display = (val !== 'daily' && val !== 'monthly') ? 'grid' : 'none';
    });
  }
}

async function loadReportClassesAndSubjects() {
  const classSelect = document.getElementById('rep-class');
  const subjectSelect = document.getElementById('rep-subject');

  if (classSelect) {
    const res = await API.get('/api/classes');
    if (res.success && res.data) {
      classSelect.innerHTML = '<option value="">All Classes</option>' +
        res.data.map(c => `<option value="${c.id}">${c.branch} Sem ${c.semester} (${c.section})</option>`).join('');
    }
  }

  if (subjectSelect) {
    const res = await API.get('/api/subjects');
    if (res.success && res.data) {
      subjectSelect.innerHTML = '<option value="">All Subjects</option>' +
        res.data.map(s => `<option value="${s.id}">${s.subject_code} - ${s.subject_name}</option>`).join('');
    }
  }
}

async function generateReport() {
  const reportType = document.getElementById('report-type').value;
  const classId = document.getElementById('rep-class').value;
  const subjectId = document.getElementById('rep-subject').value;
  const startDate = document.getElementById('rep-start-date').value;
  const endDate = document.getElementById('rep-end-date').value;
  const singleDate = document.getElementById('rep-single-date').value;
  const singleMonth = document.getElementById('rep-single-month').value;

  const tbody = document.getElementById('report-tbody');
  const thead = document.getElementById('report-thead');
  tbody.innerHTML = `
    <tr>
      <td colspan="8" style="text-align: center; padding: 2.5rem;">
        <div style="display:flex;align-items:center;justify-content:center;gap:0.75rem;">
          <div class="spinner"></div>
          <span style="color:var(--text-muted);">Generating ${reportType} report from database...</span>
        </div>
      </td>
    </tr>
  `;

  let endpoint = '/api/reports/student';
  let params = { class_id: classId, subject_id: subjectId };

  if (reportType === 'class') {
    endpoint = '/api/reports/class';
    params.start_date = startDate;
    params.end_date = endDate;
  } else if (reportType === 'subject') {
    endpoint = '/api/reports/subject';
    params.start_date = startDate;
    params.end_date = endDate;
  } else if (reportType === 'daily') {
    endpoint = '/api/reports/daily';
    params.date = singleDate;
  } else if (reportType === 'monthly') {
    endpoint = '/api/reports/monthly';
    params.month = singleMonth;
  } else if (reportType === 'low-attendance') {
    endpoint = '/api/reports/low-attendance';
    params.threshold = 75.0;
  } else {
    // student-wise
    params.start_date = startDate;
    params.end_date = endDate;
  }

  const res = await API.get(endpoint, params);

  if (!res.success || !res.data || res.data.length === 0) {
    currentReportData = [];
    tbody.innerHTML = `
      <tr>
        <td colspan="8">
          <div class="empty-state">
            <div class="empty-title">No Records Found</div>
            <div class="empty-desc">No attendance entries matched the selected filter criteria. Try broadening your date range or filters.</div>
          </div>
        </td>
      </tr>
    `;
    updateSummaryCards(0, 0, 0, 0, 0);
    return;
  }

  currentReportData = res.data;
  renderReportTable(reportType, currentReportData);
  computeAndRenderSummary(reportType, currentReportData);
}

function renderReportTable(reportType, data) {
  const thead = document.getElementById('report-thead');
  const tbody = document.getElementById('report-tbody');

  if (reportType === 'class') {
    thead.innerHTML = `
      <tr>
        <th>Class ID</th>
        <th>Branch</th>
        <th>Semester</th>
        <th>Section</th>
        <th>Enrolled</th>
        <th>Total Records</th>
        <th>Present</th>
        <th>Attendance %</th>
      </tr>
    `;
    tbody.innerHTML = data.map(item => `
      <tr>
        <td style="font-family:monospace;color:var(--text-muted);">#${item.class_id}</td>
        <td style="font-weight:700;color:var(--accent-primary);">${escapeHtml(item.branch)}</td>
        <td>Sem ${item.semester}</td>
        <td><span class="badge badge-neutral">Sec ${escapeHtml(item.section)}</span></td>
        <td>${item.enrolled_students || 0}</td>
        <td>${item.total_classes || 0}</td>
        <td style="color:var(--success);font-weight:600;">${item.present || 0}</td>
        <td>${getAttendancePill(item.attendance_percentage)}</td>
      </tr>
    `).join('');
  } else if (reportType === 'subject') {
    thead.innerHTML = `
      <tr>
        <th>Code</th>
        <th>Subject Name</th>
        <th>Faculty</th>
        <th>Branch/Sem</th>
        <th>Total Sessions</th>
        <th>Total Entries</th>
        <th>Present</th>
        <th>Average %</th>
      </tr>
    `;
    tbody.innerHTML = data.map(item => `
      <tr>
        <td style="font-weight:700;font-family:monospace;color:var(--accent-secondary);">${escapeHtml(item.subject_code)}</td>
        <td style="font-weight:600;">${escapeHtml(item.subject_name)}</td>
        <td style="color:var(--text-secondary);">${escapeHtml(item.faculty_name || 'N/A')}</td>
        <td>${escapeHtml(item.branch)} Sem ${item.semester}</td>
        <td>${item.total_sessions || 0}</td>
        <td>${item.total_classes || 0}</td>
        <td style="color:var(--success);font-weight:600;">${item.present || 0}</td>
        <td>${getAttendancePill(item.attendance_percentage)}</td>
      </tr>
    `).join('');
  } else if (reportType === 'daily') {
    thead.innerHTML = `
      <tr>
        <th>Date</th>
        <th>Roll No</th>
        <th>Student Name</th>
        <th>Branch / Class</th>
        <th>Subject</th>
        <th>Status</th>
      </tr>
    `;
    tbody.innerHTML = data.map(item => `
      <tr>
        <td>${escapeHtml(item.attendance_date)}</td>
        <td style="font-weight:600;">${escapeHtml(item.roll_number || item.enrollment_id)}</td>
        <td style="font-weight:600;">${escapeHtml(item.student_name)}</td>
        <td>${escapeHtml(item.branch)} Sem ${item.semester} (${escapeHtml(item.section)})</td>
        <td>${escapeHtml(item.subject_code)} - ${escapeHtml(item.subject_name)}</td>
        <td>${getStatusBadge(item.status)}</td>
      </tr>
    `).join('');
  } else {
    // Default Student-wise or Low-attendance report
    thead.innerHTML = `
      <tr>
        <th>Enrollment</th>
        <th>Roll No</th>
        <th>Student Name</th>
        <th>Subject</th>
        <th>Total Classes</th>
        <th>Present</th>
        <th>Absent</th>
        <th>Late</th>
        <th>Attendance %</th>
      </tr>
    `;
    tbody.innerHTML = data.map(item => {
      const pct = item.attendance_percentage || 0;
      const isLow = pct < 75.0;
      return `
        <tr style="${isLow ? 'background: rgba(239, 68, 68, 0.05);' : ''}">
          <td style="font-weight:600;font-family:monospace;color:var(--accent-secondary);">${escapeHtml(item.enrollment_id)}</td>
          <td style="font-weight:600;">${escapeHtml(item.roll_number || '—')}</td>
          <td>
            <div style="font-weight:600;color:var(--text-primary);">${escapeHtml(item.student_name || item.name)}</div>
            <div style="font-size:0.75rem;color:var(--text-muted);">${escapeHtml(item.branch)} Sem ${item.semester} (${escapeHtml(item.section)})</div>
          </td>
          <td>${escapeHtml(item.subject_name ? `${item.subject_code} - ${item.subject_name}` : 'All Subjects')}</td>
          <td style="font-weight:600;">${item.total_classes || 0}</td>
          <td style="color:var(--success);font-weight:600;">${item.present !== undefined ? item.present : item.present_classes || 0}</td>
          <td style="color:var(--danger);font-weight:600;">${item.absent !== undefined ? item.absent : item.absent_classes || 0}</td>
          <td style="color:var(--warning);font-weight:600;">${item.late !== undefined ? item.late : item.late_classes || 0}</td>
          <td>${getAttendancePill(pct)}</td>
        </tr>
      `;
    }).join('');
  }
}

function computeAndRenderSummary(reportType, data) {
  let totalRecords = 0;
  let presentCount = 0;
  let absentCount = 0;
  let lateCount = 0;

  if (reportType === 'daily') {
    totalRecords = data.length;
    data.forEach(item => {
      if (item.status === 'Present') presentCount++;
      else if (item.status === 'Absent') absentCount++;
      else if (item.status === 'Late') lateCount++;
    });
  } else {
    data.forEach(item => {
      const tot = item.total_classes || 0;
      const pres = item.present !== undefined ? item.present : (item.present_classes || 0);
      const abs = item.absent !== undefined ? item.absent : (item.absent_classes || 0);
      const late = item.late !== undefined ? item.late : (item.late_classes || 0);

      totalRecords += tot;
      presentCount += pres;
      absentCount += abs;
      lateCount += late;
    });
  }

  const avgRate = totalRecords > 0 ? (presentCount / totalRecords) * 100 : 0;
  updateSummaryCards(totalRecords, avgRate, presentCount, absentCount, lateCount);
}

function updateSummaryCards(total, avg, pres, abs, late) {
  document.getElementById('rep-total-records').textContent = total;
  document.getElementById('rep-avg-rate').textContent = `${avg.toFixed(1)}%`;
  document.getElementById('rep-present-count').textContent = pres;
  document.getElementById('rep-absent-count').textContent = abs;
  document.getElementById('rep-late-count').textContent = late;
}

function exportCsv() {
  const reportType = document.getElementById('report-type').value;
  const classId = document.getElementById('rep-class').value;
  const subjectId = document.getElementById('rep-subject').value;
  const startDate = document.getElementById('rep-start-date').value;
  const endDate = document.getElementById('rep-end-date').value;
  const date = document.getElementById('rep-single-date').value;
  const month = document.getElementById('rep-single-month').value;

  API.downloadCsv('/api/reports/export', {
    type: reportType,
    class_id: classId,
    subject_id: subjectId,
    start_date: startDate,
    end_date: endDate,
    date: date,
    month: month
  }, `attendx_${reportType}_report.csv`);
}

