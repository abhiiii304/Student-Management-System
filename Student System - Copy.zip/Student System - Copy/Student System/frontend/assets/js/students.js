/**
 * ATTENDX — Student Management Controller
 */

let currentPage = 1;
let currentLimit = 15;
let currentSearch = '';
let currentBranch = '';
let currentSection = '';
let currentSemester = '';
let isEditing = false;
let editingStudentId = null;

document.addEventListener('DOMContentLoaded', () => {
  initStudentFilters();
  loadStudents();
  setupStudentForm();
  setupDeleteModal();

  // Check URL query parameters (e.g. ?search=...)
  const params = new URLSearchParams(window.location.search);
  if (params.has('search')) {
    const sInput = document.getElementById('student-search');
    if (sInput) {
      sInput.value = params.get('search');
      currentSearch = params.get('search');
      loadStudents();
    }
  }
});

function initStudentFilters() {
  const searchInput = document.getElementById('student-search');
  const branchFilter = document.getElementById('filter-branch');
  const sectionFilter = document.getElementById('filter-section');
  const semFilter = document.getElementById('filter-semester');
  const resetBtn = document.getElementById('reset-filters-btn');
  const pageSizeSelect = document.getElementById('page-size-select');

  if (searchInput) {
    searchInput.addEventListener('input', debounce((e) => {
      currentSearch = e.target.value.trim();
      currentPage = 1;
      loadStudents();
    }, 300));
  }

  if (branchFilter) {
    branchFilter.addEventListener('change', (e) => {
      currentBranch = e.target.value;
      currentPage = 1;
      loadStudents();
    });
  }

  if (sectionFilter) {
    sectionFilter.addEventListener('change', (e) => {
      currentSection = e.target.value;
      currentPage = 1;
      loadStudents();
    });
  }

  if (semFilter) {
    semFilter.addEventListener('change', (e) => {
      currentSemester = e.target.value;
      currentPage = 1;
      loadStudents();
    });
  }

  if (pageSizeSelect) {
    pageSizeSelect.addEventListener('change', (e) => {
      currentLimit = parseInt(e.target.value, 10) || 15;
      currentPage = 1;
      loadStudents();
    });
  }

  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      if (searchInput) searchInput.value = '';
      if (branchFilter) branchFilter.value = '';
      if (sectionFilter) sectionFilter.value = '';
      if (semFilter) semFilter.value = '';
      currentSearch = '';
      currentBranch = '';
      currentSection = '';
      currentSemester = '';
      currentPage = 1;
      loadStudents();
    });
  }
}

async function loadStudents() {
  const tbody = document.getElementById('students-table-body');
  const totalCountEl = document.getElementById('total-student-count');
  if (!tbody) return;

  tbody.innerHTML = `
    <tr>
      <td colspan="9" style="text-align: center; padding: 3rem;">
        <div style="display: flex; align-items: center; justify-content: center; gap: 0.75rem;">
          <div class="spinner"></div>
          <span style="color: var(--text-muted);">Loading students from database...</span>
        </div>
      </td>
    </tr>
  `;

  const params = {
    search: currentSearch,
    branch: currentBranch,
    section: currentSection,
    semester: currentSemester,
    limit: currentLimit,
    page: currentPage
  };

  const res = await API.get('/api/students', params);

  if (!res.success || !res.data || !res.data.students || res.data.students.length === 0) {
    if (totalCountEl) totalCountEl.textContent = '0 students';
    tbody.innerHTML = `
      <tr>
        <td colspan="9">
          <div class="empty-state">
            <svg class="empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
              <circle cx="9" cy="7" r="4"></circle>
              <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
              <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
            </svg>
            <div class="empty-title">No Students Found</div>
            <div class="empty-desc">
              ${currentSearch || currentBranch || currentSection || currentSemester 
                ? 'No student matches your current search or filter criteria. Try resetting filters.' 
                : 'Get started by adding student profiles or load demo records.'}
            </div>
            <button class="btn btn-primary" onclick="openAddStudentModal()">
              <span>+</span> Add Student
            </button>
          </div>
        </td>
      </tr>
    `;
    renderPagination(0, currentLimit, currentPage);
    return;
  }

  const { students, total, total_pages } = res.data;
  if (totalCountEl) totalCountEl.textContent = `${total} student${total !== 1 ? 's' : ''}`;

  tbody.innerHTML = students.map(s => `
    <tr>
      <td style="font-size: 0.8rem; color: var(--text-muted); font-family: monospace;">#${s.id}</td>
      <td style="font-weight: 600; font-family: monospace; color: var(--accent-secondary);">${escapeHtml(s.enrollment_id)}</td>
      <td>
        <div style="font-weight: 600; color: var(--text-primary);">${escapeHtml(s.name)}</div>
        <div style="font-size: 0.75rem; color: var(--text-muted);">${escapeHtml(s.email || 'No email provided')}</div>
      </td>
      <td style="font-weight: 500;">${escapeHtml(s.roll_number || '—')}</td>
      <td><span class="badge badge-neutral">${escapeHtml(s.branch)}</span></td>
      <td>${escapeHtml(s.section)}</td>
      <td>Sem ${s.semester}</td>
      <td>
        ${s.total_classes > 0 ? getAttendancePill(s.attendance_percentage) : '<span style="color:var(--text-muted);font-size:0.8rem;">No records</span>'}
      </td>
      <td>
        <div class="table-actions">
          <button class="btn btn-secondary btn-sm" onclick="viewStudentDetails(${s.id})" title="View Profile">
            View
          </button>
          <button class="btn btn-secondary btn-sm" onclick="openEditStudentModal(${s.id})" title="Edit Details">
            Edit
          </button>
          <button class="btn btn-outline-danger btn-sm" onclick="confirmDeleteStudent(${s.id}, '${escapeHtml(s.name)}')" title="Delete Student">
            Delete
          </button>
        </div>
      </td>
    </tr>
  `).join('');

  renderPagination(total, currentLimit, currentPage);
}

function renderPagination(total, limit, page) {
  const container = document.getElementById('pagination-container');
  if (!container) return;

  const totalPages = Math.ceil(total / limit) || 1;
  const start = total === 0 ? 0 : (page - 1) * limit + 1;
  const end = Math.min(page * limit, total);

  container.innerHTML = `
    <div style="font-size: 0.85rem; color: var(--text-muted);">
      Showing <span style="color: var(--text-primary); font-weight: 600;">${start}</span> to <span style="color: var(--text-primary); font-weight: 600;">${end}</span> of <span style="color: var(--text-primary); font-weight: 600;">${total}</span> entries
    </div>
    <div style="display: flex; gap: 0.4rem;">
      <button class="btn btn-secondary btn-sm" ${page <= 1 ? 'disabled style="opacity:0.5;cursor:not-allowed;"' : ''} onclick="goToPage(${page - 1})">
        &larr; Prev
      </button>
      <div style="display: flex; align-items: center; padding: 0 0.5rem; font-size: 0.85rem; color: var(--text-secondary);">
        Page ${page} of ${totalPages}
      </div>
      <button class="btn btn-secondary btn-sm" ${page >= totalPages ? 'disabled style="opacity:0.5;cursor:not-allowed;"' : ''} onclick="goToPage(${page + 1})">
        Next &rarr;
      </button>
    </div>
  `;
}

function goToPage(page) {
  currentPage = page;
  loadStudents();
}

function setupStudentForm() {
  const form = document.getElementById('student-modal-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = form.querySelector('button[type="submit"]');
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = `<span class="spinner" style="width:14px;height:14px;"></span> Saving...`;

    const payload = {
      enrollment_id: document.getElementById('m-student-enrollment').value.trim(),
      name: document.getElementById('m-student-name').value.trim(),
      roll_number: document.getElementById('m-student-roll').value.trim(),
      branch: document.getElementById('m-student-branch').value.trim(),
      section: document.getElementById('m-student-section').value.trim(),
      semester: parseInt(document.getElementById('m-student-semester').value, 10),
      email: document.getElementById('m-student-email').value.trim(),
      phone: document.getElementById('m-student-phone').value.trim(),
    };

    let res;
    if (isEditing && editingStudentId) {
      res = await API.put(`/api/students/${editingStudentId}`, payload);
    } else {
      res = await API.post('/api/students', payload);
    }

    btn.disabled = false;
    btn.innerHTML = originalText;

    if (res.success) {
      showToast(res.message || 'Student saved successfully', 'success');
      closeModal('student-form-modal');
      loadStudents();
    } else {
      let errText = res.message || 'Validation failed';
      if (res.errors && typeof res.errors === 'object') {
        const errs = Object.values(res.errors);
        if (errs.length > 0) errText = errs.join(', ');
      }
      showToast(errText, 'error');
    }
  });
}

function openAddStudentModal() {
  isEditing = false;
  editingStudentId = null;
  document.getElementById('student-modal-title').textContent = 'Add New Student';
  document.getElementById('student-modal-form').reset();
  openModal('student-form-modal');
}

async function openEditStudentModal(id) {
  isEditing = true;
  editingStudentId = id;
  document.getElementById('student-modal-title').textContent = 'Edit Student Details';

  const res = await API.get(`/api/students/${id}`);
  if (res.success && res.data) {
    const s = res.data;
    document.getElementById('m-student-enrollment').value = s.enrollment_id || '';
    document.getElementById('m-student-name').value = s.name || '';
    document.getElementById('m-student-roll').value = s.roll_number || '';
    document.getElementById('m-student-branch').value = s.branch || 'CSE';
    document.getElementById('m-student-section').value = s.section || 'A';
    document.getElementById('m-student-semester').value = s.semester || 1;
    document.getElementById('m-student-email').value = s.email || '';
    document.getElementById('m-student-phone').value = s.phone || '';
    openModal('student-form-modal');
  } else {
    showToast('Failed to load student details', 'error');
  }
}

async function viewStudentDetails(id) {
  const res = await API.get(`/api/students/${id}`);
  if (!res.success || !res.data) {
    showToast('Could not load student profile', 'error');
    return;
  }

  const s = res.data;
  document.getElementById('v-student-name').textContent = s.name;
  document.getElementById('v-student-enrollment').textContent = s.enrollment_id;
  document.getElementById('v-student-roll').textContent = s.roll_number || 'N/A';
  document.getElementById('v-student-branch').textContent = `${s.branch} - Sec ${s.section}`;
  document.getElementById('v-student-semester').textContent = `Semester ${s.semester}`;
  document.getElementById('v-student-email').textContent = s.email || 'N/A';
  document.getElementById('v-student-phone').textContent = s.phone || 'N/A';

  document.getElementById('v-student-classes-count').textContent = s.total_classes;
  document.getElementById('v-student-present-count').textContent = s.present_classes;
  document.getElementById('v-student-absent-count').textContent = s.absent_classes;
  document.getElementById('v-student-late-count').textContent = s.late_classes;
  document.getElementById('v-student-rate').textContent = `${s.attendance_percentage.toFixed(1)}%`;

  // Fetch student subject breakdown
  const attRes = await API.get(`/api/reports/student`, { student_id: s.id });
  const attTable = document.getElementById('v-student-att-tbody');
  if (attTable) {
    if (attRes.success && attRes.data && attRes.data.length > 0) {
      attTable.innerHTML = attRes.data.map(item => `
        <tr>
          <td>
            <div style="font-weight:600;">${escapeHtml(item.subject_name)}</div>
            <div style="font-size:0.75rem;color:var(--text-muted);">${escapeHtml(item.subject_code)}</div>
          </td>
          <td>${item.total_classes}</td>
          <td style="color:var(--success);">${item.present}</td>
          <td style="color:var(--danger);">${item.absent}</td>
          <td style="color:var(--warning);">${item.late}</td>
          <td>${getAttendancePill(item.attendance_percentage)}</td>
        </tr>
      `).join('');
    } else {
      attTable.innerHTML = `<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:1.5rem;">No subject attendance recorded yet.</td></tr>`;
    }
  }

  openModal('student-view-modal');
}

let studentToDeleteId = null;

function confirmDeleteStudent(id, name) {
  studentToDeleteId = id;
  const nameEl = document.getElementById('delete-student-name');
  if (nameEl) nameEl.textContent = name;
  openModal('student-delete-modal');
}

function setupDeleteModal() {
  const confirmBtn = document.getElementById('confirm-delete-student-btn');
  if (confirmBtn) {
    confirmBtn.addEventListener('click', async () => {
      if (!studentToDeleteId) return;

      confirmBtn.disabled = true;
      confirmBtn.innerHTML = `<span class="spinner" style="width:14px;height:14px;"></span> Deleting...`;

      const res = await API.delete(`/api/students/${studentToDeleteId}`);
      confirmBtn.disabled = false;
      confirmBtn.innerHTML = `Delete Student`;
      closeModal('student-delete-modal');

      if (res.success) {
        showToast(res.message || 'Student removed successfully', 'success');
        loadStudents();
      } else {
        showToast(res.message || 'Failed to delete student', 'error');
      }
    });
  }
}

