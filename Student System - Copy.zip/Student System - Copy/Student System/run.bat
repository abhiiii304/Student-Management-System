@echo off
title ATTENDX — Smart Student Attendance Management System
echo ==========================================================
echo   ATTENDX — Smart Student Attendance Management System
echo   Enterprise Academic Intelligence Platform
echo ==========================================================
echo Starting AttendX Server...
python run_attendx.py %*
pause
