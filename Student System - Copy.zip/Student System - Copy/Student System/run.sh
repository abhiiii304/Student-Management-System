#!/bin/bash
set -e

echo "=========================================================="
echo "  ATTENDX — Smart Student Attendance Management System    "
echo "  Enterprise Academic Intelligence Platform (C++ / SQLite)"
echo "=========================================================="

PORT=${PORT:-8080}
HOST=${HOST:-0.0.0.0}
DB_PATH=${DB_PATH:-database/attendx.db}

# Check if binary exists or build is requested
if [ ! -f "attendx_server" ] && [ ! -f "attendx_server.exe" ] || [ "$1" == "--build" ]; then
    echo "[AttendX] Building C++ backend using CMake..."
    cmake -B build -S .
    cmake --build build --config Release
    if [ -f "build/Release/attendx_server.exe" ]; then
        cp build/Release/attendx_server.exe ./
    elif [ -f "build/attendx_server" ]; then
        cp build/attendx_server ./
    fi
fi

# Pass arguments to the binary
echo "[AttendX] Launching server on http://localhost:${PORT}"
echo "[AttendX] Default Administrator Credentials:"
echo "          Username: admin"
echo "          Password: Admin@123"
echo "----------------------------------------------------------"

if [ -f "./attendx_server.exe" ]; then
    exec ./attendx_server.exe --port "$PORT" --host "$HOST" --db "$DB_PATH" "$@"
else
    exec ./attendx_server --port "$PORT" --host "$HOST" --db "$DB_PATH" "$@"
fi
