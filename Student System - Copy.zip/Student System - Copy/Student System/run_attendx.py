import os
import sys
import json
import sqlite3
import hashlib
import uuid
import datetime
import mimetypes
import re
import argparse
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

# Configuration defaults
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")
DB_DIR = os.path.join(BASE_DIR, "database")
DEFAULT_DB_PATH = os.path.join(DB_DIR, "attendx.db")

# In-memory sessions
sessions = {}

def get_current_timestamp():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

def hash_password(password, salt):
    return hashlib.sha256(f"{password}${salt}".encode("utf-8")).hexdigest()

def get_db_connection(db_path):
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn

def init_database(db_path):
    os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
    conn = get_db_connection(db_path)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            salt TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'admin',
            created_at TEXT NOT NULL
        );
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS classes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            branch TEXT NOT NULL,
            semester INTEGER NOT NULL,
            section TEXT NOT NULL,
            academic_year TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            UNIQUE(branch, semester, section)
        );
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            enrollment_id TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            roll_number TEXT UNIQUE,
            branch TEXT NOT NULL,
            section TEXT NOT NULL,
            semester INTEGER NOT NULL,
            email TEXT,
            phone TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            deleted_at TEXT NULL
        );
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS subjects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject_name TEXT NOT NULL,
            subject_code TEXT UNIQUE NOT NULL,
            branch TEXT,
            semester INTEGER NOT NULL,
            section TEXT,
            faculty_name TEXT,
            class_id INTEGER REFERENCES classes(id) ON DELETE SET NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
            subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
            class_id INTEGER REFERENCES classes(id) ON DELETE SET NULL,
            attendance_date TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            UNIQUE(student_id, subject_id, attendance_date)
        );
    """)

    # Performance indexes
    cur.execute("CREATE INDEX IF NOT EXISTS idx_att_date ON attendance(attendance_date);")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_att_student ON attendance(student_id);")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_att_subject ON attendance(subject_id);")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_students_cohort ON students(branch, semester, section);")

    # Seed admin if missing
    cur.execute("SELECT id FROM users WHERE username = 'admin';")
    if not cur.fetchone():
        salt = "gYtuQih9KwvnqtOL"
        pwd_hash = hash_password("Admin@123", salt)
        cur.execute(
            "INSERT INTO users (username, password_hash, salt, role, created_at) VALUES (?, ?, ?, 'admin', ?);",
            ("admin", pwd_hash, salt, get_current_timestamp())
        )
        conn.commit()

    conn.close()

def seed_demo_data(db_path, force=False):
    conn = get_db_connection(db_path)
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM students WHERE deleted_at IS NULL;")
    active_count = cur.fetchone()[0]
    if not force and active_count >= 10:
        conn.close()
        return False, f"Database already contains data ({active_count} students). Skipping seed."

    # Classes
    classes_data = [
        ("CSE", 6, "A", "2026-2027"),
        ("CSE", 6, "B", "2026-2027"),
        ("IT", 6, "A", "2026-2027"),
        ("ECE", 4, "A", "2026-2027")
    ]
    class_ids = []
    now = get_current_timestamp()
    for branch, sem, sec, yr in classes_data:
        cur.execute("SELECT id FROM classes WHERE branch=? AND semester=? AND section=?", (branch, sem, sec))
        row = cur.fetchone()
        if row:
            class_ids.append(row["id"])
        else:
            cur.execute("INSERT INTO classes (branch, semester, section, academic_year, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
                        (branch, sem, sec, yr, now, now))
            class_ids.append(cur.lastrowid)

    # Subjects
    subjects_data = [
        ("Advanced Database Systems", "CS601", "CSE", 6, "A", "Dr. Rajesh Sharma", 0),
        ("Cloud Computing & DevOps", "CS602", "CSE", 6, "A", "Prof. Ananya Iyer", 0),
        ("Artificial Intelligence & ML", "CS603", "CSE", 6, "A", "Dr. Vikram Seth", 0),
        ("Information Security", "CS604", "CSE", 6, "B", "Prof. Meera Nair", 1),
        ("Web Technologies", "IT601", "IT", 6, "A", "Dr. Arvind Patel", 2),
        ("Signals and Systems", "EC401", "ECE", 4, "A", "Dr. Kavita Menon", 3)
    ]
    subject_ids = []
    for name, code, branch, sem, sec, faculty, class_idx in subjects_data:
        cur.execute("SELECT id FROM subjects WHERE subject_code=?", (code,))
        row = cur.fetchone()
        if row:
            subject_ids.append(row["id"])
        else:
            cid = class_ids[class_idx] if class_idx < len(class_ids) else None
            cur.execute("""
                INSERT INTO subjects (subject_name, subject_code, branch, semester, section, faculty_name, class_id, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (name, code, branch, sem, sec, faculty, cid, now, now))
            subject_ids.append(cur.lastrowid)

    # Students
    students_data = [
        ("EN2024001", "Aarav Sharma", "CS-01", "CSE", "A", 6, "aarav.sharma@attendx.edu", "+91 98765 43210"),
        ("EN2024002", "Diya Patel", "CS-02", "CSE", "A", 6, "diya.patel@attendx.edu", "+91 98765 43211"),
        ("EN2024003", "Rohan Verma", "CS-03", "CSE", "A", 6, "rohan.verma@attendx.edu", "+91 98765 43212"),
        ("EN2024004", "Ananya Deshmukh", "CS-04", "CSE", "A", 6, "ananya.d@attendx.edu", "+91 98765 43213"),
        ("EN2024005", "Kabir Mehta", "CS-05", "CSE", "A", 6, "kabir.mehta@attendx.edu", "+91 98765 43214"),
        ("EN2024006", "Sneha Kulkarni", "CS-06", "CSE", "A", 6, "sneha.k@attendx.edu", "+91 98765 43215"),
        ("EN2024007", "Aditya Nair", "CS-07", "CSE", "A", 6, "aditya.nair@attendx.edu", "+91 98765 43216"),
        ("EN2024008", "Pooja Reddy", "CS-08", "CSE", "A", 6, "pooja.reddy@attendx.edu", "+91 98765 43217"),
        ("EN2024009", "Varun Chopra", "CS-09", "CSE", "A", 6, "varun.c@attendx.edu", "+91 98765 43218"),
        ("EN2024010", "Isha Mukherjee", "CS-10", "CSE", "A", 6, "isha.m@attendx.edu", "+91 98765 43219"),
        ("EN2024011", "Rhea Sengupta", "CS-11", "CSE", "B", 6, "rhea.s@attendx.edu", "+91 98765 43220"),
        ("EN2024012", "Siddharth Rao", "CS-12", "CSE", "B", 6, "siddharth.r@attendx.edu", "+91 98765 43221"),
        ("EN2024013", "Tanvi Joshi", "CS-13", "CSE", "B", 6, "tanvi.j@attendx.edu", "+91 98765 43222"),
        ("EN2024014", "Manish Pandey", "CS-14", "CSE", "B", 6, "manish.p@attendx.edu", "+91 98765 43223"),
        ("EN2024015", "Kiran Bhat", "CS-15", "CSE", "B", 6, "kiran.b@attendx.edu", "+91 98765 43224"),
        ("EN2024016", "Nikhil Pillai", "IT-01", "IT", "A", 6, "nikhil.p@attendx.edu", "+91 98765 43225"),
        ("EN2024017", "Shruti Gupta", "IT-02", "IT", "A", 6, "shruti.g@attendx.edu", "+91 98765 43226"),
        ("EN2024018", "Gaurav Roy", "IT-03", "IT", "A", 6, "gaurav.roy@attendx.edu", "+91 98765 43227"),
        ("EN2024019", "Mehak Jain", "IT-04", "IT", "A", 6, "mehak.j@attendx.edu", "+91 98765 43228"),
        ("EN2024020", "Abhishek Das", "IT-05", "IT", "A", 6, "abhishek.d@attendx.edu", "+91 98765 43229"),
        ("EN2024021", "Pranav Bansal", "EC-01", "ECE", "A", 4, "pranav.b@attendx.edu", "+91 98765 43230"),
        ("EN2024022", "Tara Raman", "EC-02", "ECE", "A", 4, "tara.r@attendx.edu", "+91 98765 43231"),
        ("EN2024023", "Kunal Singhania", "EC-03", "ECE", "A", 4, "kunal.s@attendx.edu", "+91 98765 43232"),
        ("EN2024024", "Ritu Agrawal", "EC-04", "ECE", "A", 4, "ritu.a@attendx.edu", "+91 98765 43233")
    ]
    student_ids = []
    for enroll, name, roll, branch, sec, sem, email, phone in students_data:
        cur.execute("SELECT id FROM students WHERE enrollment_id=?", (enroll,))
        row = cur.fetchone()
        if row:
            student_ids.append(row["id"])
        else:
            cur.execute("""
                INSERT INTO students (enrollment_id, name, roll_number, branch, section, semester, email, phone, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (enroll, name, roll, branch, sec, sem, email, phone, now, now))
            student_ids.append(cur.lastrowid)

    # Attendance history
    dates = [
        "2026-11-17", "2026-11-18", "2026-11-19", "2026-11-20", "2026-11-21", "2026-11-22", "2026-11-23"
    ]
    for date in dates:
        for i in range(10):
            sid = student_ids[i]
            for sub_idx in range(3):
                sub_id = subject_ids[sub_idx]
                cid = class_ids[0]
                if i == 2:
                    status = "Present" if date in ("2026-11-18", "2026-11-21") else "Absent"
                elif i == 8:
                    status = "Present" if date in ("2026-11-17", "2026-11-20") else "Absent"
                elif i == 5:
                    status = "Late" if date in ("2026-11-19", "2026-11-22") else "Present"
                else:
                    status = "Absent" if (date == "2026-11-19" and i % 4 == 0) else "Present"

                cur.execute("""
                    INSERT INTO attendance (student_id, subject_id, class_id, attendance_date, status, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(student_id, subject_id, attendance_date)
                    DO UPDATE SET status=excluded.status, class_id=excluded.class_id, updated_at=excluded.updated_at
                """, (sid, sub_id, cid, date, status, now, now))

    conn.commit()
    conn.close()
    return True, f"Demo dataset seeded successfully ({len(students_data)} students, {len(classes_data)} classes, {len(subjects_data)} subjects, attendance records)."

class AttendXHandler(BaseHTTPRequestHandler):
    db_path = DEFAULT_DB_PATH
    static_dir = FRONTEND_DIR

    def log_message(self, format, *args):
        # Clean logging
        sys.stderr.write(f"[AttendX] {self.address_string()} - {format % args}\n")

    def send_json(self, status, success, message, data=None, errors=None, extra_headers=None):
        payload = {"success": success, "message": message}
        if data is not None:
            payload["data"] = data
        if errors is not None:
            payload["errors"] = errors
        body = json.dumps(payload, default=str).encode("utf-8")

        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def send_csv(self, csv_content, filename):
        body = csv_content.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/csv; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def extract_token(self):
        auth = self.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            return auth[7:].strip()
        cookies = self.headers.get("Cookie", "")
        for part in cookies.split(";"):
            part = part.strip()
            if part.startswith("attendx_token="):
                return part[len("attendx_token="):].strip()
        return ""

    def get_session(self):
        token = self.extract_token()
        if token and token in sessions:
            sess = sessions[token]
            if sess["expiresAt"] > datetime.datetime.now():
                return sess
        return None

    def require_auth(self):
        sess = self.get_session()
        if not sess:
            self.send_json(401, False, "Authentication required. Please log in.")
            return None
        return sess

    def read_json_body(self):
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        raw = self.rfile.read(length).decode("utf-8")
        return json.loads(raw)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def serve_static(self, path):
        if path in ("/", "/index.html"):
            filepath = os.path.join(self.static_dir, "index.html")
        elif path in ("/students", "/students.html"):
            filepath = os.path.join(self.static_dir, "students.html")
        elif path in ("/attendance", "/attendance.html"):
            filepath = os.path.join(self.static_dir, "attendance.html")
        elif path in ("/classes", "/classes.html"):
            filepath = os.path.join(self.static_dir, "classes.html")
        elif path in ("/reports", "/reports.html"):
            filepath = os.path.join(self.static_dir, "reports.html")
        elif path in ("/login", "/login.html"):
            filepath = os.path.join(self.static_dir, "login.html")
        elif path.startswith("/assets/"):
            rel = path[len("/assets/"):].replace("/", os.sep)
            filepath = os.path.join(self.static_dir, "assets", rel)
        else:
            filepath = os.path.join(self.static_dir, path.lstrip("/").replace("/", os.sep))

        if not os.path.exists(filepath) or os.path.isdir(filepath):
            self.send_response(404)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(b"<h1>404 Not Found</h1><p>The requested file was not found.</p>")
            return

        mime_type, _ = mimetypes.guess_type(filepath)
        if not mime_type:
            mime_type = "application/octet-stream"

        with open(filepath, "rb") as f:
            content = f.read()

        self.send_response(200)
        self.send_header("Content-Type", mime_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(content)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = {k: v[0] for k, v in parse_qs(parsed.query).items()}

        if not path.startswith("/api/"):
            self.serve_static(path)
            return

        conn = get_db_connection(self.db_path)
        cur = conn.cursor()

        try:
            # 1. GET /api/auth/me
            if path == "/api/auth/me":
                sess = self.get_session()
                if not sess:
                    self.send_json(401, False, "User not authenticated")
                else:
                    self.send_json(200, True, "User authenticated", {
                        "id": sess["userId"],
                        "username": sess["username"],
                        "role": sess["role"]
                    })
                return

            # 2. GET /api/dashboard/stats
            if path == "/api/dashboard/stats":
                today = params.get("date", datetime.datetime.now().strftime("%Y-%m-%d"))
                cur.execute("SELECT COUNT(*) FROM students WHERE deleted_at IS NULL;")
                total_students = cur.fetchone()[0]

                cur.execute("SELECT COUNT(*) FROM classes;")
                total_classes = cur.fetchone()[0]

                cur.execute("SELECT COUNT(*) FROM subjects;")
                total_subjects = cur.fetchone()[0]

                cur.execute("SELECT COUNT(*) FROM attendance WHERE attendance_date = ?;", (today,))
                today_records = cur.fetchone()[0]
                query_date = today
                if today_records == 0:
                    cur.execute("SELECT MAX(attendance_date) FROM attendance;")
                    latest = cur.fetchone()[0]
                    if latest:
                        query_date = latest

                cur.execute("""
                    SELECT 
                        SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS present,
                        SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) AS absent,
                        SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) AS late
                    FROM attendance
                    WHERE attendance_date = ?;
                """, (query_date,))
                st_row = cur.fetchone()
                pres = st_row["present"] or 0
                ab = st_row["absent"] or 0
                late = st_row["late"] or 0

                cur.execute("SELECT COUNT(id) AS total, SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS present FROM attendance;")
                rate_row = cur.fetchone()
                all_total = rate_row["total"] or 0
                all_pres = rate_row["present"] or 0
                rate = (all_pres / all_total * 100.0) if all_total > 0 else 0.0

                self.send_json(200, True, "Dashboard stats retrieved", {
                    "total_students": total_students,
                    "total_classes": total_classes,
                    "total_subjects": total_subjects,
                    "today_present": pres,
                    "today_absent": ab,
                    "today_late": late,
                    "overall_attendance_rate": round(rate, 2),
                    "stats_date": query_date
                })
                return

            # 3. GET /api/dashboard/recent-activity
            if path == "/api/dashboard/recent-activity":
                limit = int(params.get("limit", 10))
                cur.execute("""
                    SELECT a.id, a.student_id, a.subject_id, a.class_id, a.attendance_date, a.status, a.created_at, a.updated_at,
                           s.name AS student_name, s.enrollment_id, s.roll_number, s.branch, s.semester, s.section,
                           sub.subject_name, sub.subject_code
                    FROM attendance a
                    JOIN students s ON s.id = a.student_id
                    JOIN subjects sub ON sub.id = a.subject_id
                    ORDER BY a.updated_at DESC, a.id DESC
                    LIMIT ?;
                """, (limit,))
                rows = [dict(r) for r in cur.fetchall()]
                self.send_json(200, True, "Recent activity retrieved", rows)
                return

            # 4. GET /api/dashboard/attendance-trends
            if path == "/api/dashboard/attendance-trends":
                range_type = params.get("range", "daily")
                limit = int(params.get("limit", 7))
                if range_type == "monthly":
                    sql = """
                        SELECT 
                            SUBSTR(attendance_date, 1, 7) AS period,
                            SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS present,
                            SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) AS absent,
                            SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) AS late,
                            COUNT(id) AS total
                        FROM attendance
                        GROUP BY SUBSTR(attendance_date, 1, 7)
                        ORDER BY period DESC
                        LIMIT ?;
                    """
                else:
                    sql = """
                        SELECT 
                            attendance_date AS period,
                            SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS present,
                            SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) AS absent,
                            SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) AS late,
                            COUNT(id) AS total
                        FROM attendance
                        GROUP BY attendance_date
                        ORDER BY attendance_date DESC
                        LIMIT ?;
                    """
                cur.execute(sql, (limit,))
                pts = []
                for r in cur.fetchall():
                    tot = r["total"] or 0
                    p = r["present"] or 0
                    pct = (p / tot * 100.0) if tot > 0 else 0.0
                    pts.append({
                        "date": r["period"],
                        "present": p,
                        "absent": r["absent"] or 0,
                        "late": r["late"] or 0,
                        "percentage": round(pct, 1)
                    })
                pts.reverse()
                self.send_json(200, True, "Attendance trends retrieved", pts)
                return

            # 5. GET /api/dashboard/attendance-distribution
            if path == "/api/dashboard/attendance-distribution":
                cur.execute("""
                    SELECT 
                        COUNT(id) AS total,
                        SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS present,
                        SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) AS absent,
                        SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) AS late
                    FROM attendance;
                """)
                r = cur.fetchone()
                tot = r["total"] or 0
                p = r["present"] or 0
                pct = (p / tot * 100.0) if tot > 0 else 0.0
                self.send_json(200, True, "Attendance distribution retrieved", {
                    "total": tot,
                    "present": p,
                    "absent": r["absent"] or 0,
                    "late": r["late"] or 0,
                    "percentage": round(pct, 1)
                })
                return

            # 6. GET /api/students
            if path == "/api/students":
                search = params.get("search", "")
                branch = params.get("branch", "")
                section = params.get("section", "")
                sem = int(params.get("semester", 0))
                inc_del = params.get("include_deleted") == "true"
                limit = int(params.get("limit", 50))
                page = int(params.get("page", 1))
                offset = (page - 1) * limit if page > 0 else 0

                where = []
                prms = []
                if not inc_del:
                    where.append("s.deleted_at IS NULL")
                if search:
                    where.append("(s.name LIKE ? OR s.enrollment_id LIKE ? OR s.roll_number LIKE ? OR s.email LIKE ?)")
                    prms.extend([f"%{search}%"] * 4)
                if branch:
                    where.append("s.branch = ?")
                    prms.append(branch)
                if section:
                    where.append("s.section = ?")
                    prms.append(section)
                if sem > 0:
                    where.append("s.semester = ?")
                    prms.append(sem)

                where_str = ("WHERE " + " AND ".join(where)) if where else ""

                count_sql = f"SELECT COUNT(*) FROM students s {where_str};"
                cur.execute(count_sql, prms)
                total = cur.fetchone()[0]

                sql = f"""
                    SELECT s.id, s.enrollment_id, s.name, s.roll_number, s.branch, s.section, s.semester,
                           s.email, s.phone, s.created_at, s.updated_at, s.deleted_at,
                           COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id), 0) AS total_classes,
                           COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id AND a.status = 'Present'), 0) AS present_classes,
                           COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id AND a.status = 'Absent'), 0) AS absent_classes,
                           COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id AND a.status = 'Late'), 0) AS late_classes
                    FROM students s
                    {where_str}
                    ORDER BY s.semester ASC, s.branch ASC, s.section ASC, s.roll_number ASC
                    LIMIT ? OFFSET ?;
                """
                cur.execute(sql, prms + [limit, offset])
                items = []
                for r in cur.fetchall():
                    d = dict(r)
                    tot = d["total_classes"]
                    p = d["present_classes"]
                    d["attendance_percentage"] = round((p / tot * 100.0), 1) if tot > 0 else 0.0
                    items.append(d)

                total_pages = (total + limit - 1) // limit if limit > 0 else 1
                self.send_json(200, True, "Students retrieved successfully", {
                    "students": items,
                    "total": total,
                    "page": page,
                    "limit": limit,
                    "total_pages": total_pages
                })
                return

            # 7. GET /api/students/:id
            m = re.match(r"^/api/students/(\d+)$", path)
            if m:
                sid = int(m.group(1))
                cur.execute("""
                    SELECT s.id, s.enrollment_id, s.name, s.roll_number, s.branch, s.section, s.semester,
                           s.email, s.phone, s.created_at, s.updated_at, s.deleted_at,
                           COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id), 0) AS total_classes,
                           COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id AND a.status = 'Present'), 0) AS present_classes,
                           COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id AND a.status = 'Absent'), 0) AS absent_classes,
                           COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id AND a.status = 'Late'), 0) AS late_classes
                    FROM students s
                    WHERE s.id = ?;
                """, (sid,))
                r = cur.fetchone()
                if not r:
                    self.send_json(404, False, "Student not found")
                else:
                    d = dict(r)
                    tot = d["total_classes"]
                    p = d["present_classes"]
                    d["attendance_percentage"] = round((p / tot * 100.0), 1) if tot > 0 else 0.0
                    self.send_json(200, True, "Student details retrieved", d)
                return

            # 8. GET /api/classes
            if path == "/api/classes":
                search = params.get("search", "")
                branch = params.get("branch", "")
                sem = int(params.get("semester", 0))

                where = []
                prms = []
                if search:
                    where.append("(c.branch LIKE ? OR c.section LIKE ? OR c.academic_year LIKE ?)")
                    prms.extend([f"%{search}%"] * 3)
                if branch:
                    where.append("c.branch = ?")
                    prms.append(branch)
                if sem > 0:
                    where.append("c.semester = ?")
                    prms.append(sem)

                where_str = ("WHERE " + " AND ".join(where)) if where else ""
                sql = f"""
                    SELECT c.id, c.branch, c.semester, c.section, c.academic_year, c.created_at, c.updated_at,
                           (SELECT COUNT(*) FROM students s WHERE s.deleted_at IS NULL AND s.branch = c.branch AND s.semester = c.semester AND s.section = c.section) AS student_count,
                           (SELECT COUNT(*) FROM subjects sub WHERE sub.class_id = c.id OR (sub.branch = c.branch AND sub.semester = c.semester AND sub.section = c.section)) AS subject_count
                    FROM classes c
                    {where_str}
                    ORDER BY c.semester ASC, c.branch ASC, c.section ASC;
                """
                cur.execute(sql, prms)
                self.send_json(200, True, "Classes retrieved successfully", [dict(r) for r in cur.fetchall()])
                return

            # 9. GET /api/classes/:id
            m = re.match(r"^/api/classes/(\d+)$", path)
            if m:
                cid = int(m.group(1))
                cur.execute("""
                    SELECT c.id, c.branch, c.semester, c.section, c.academic_year, c.created_at, c.updated_at,
                           (SELECT COUNT(*) FROM students s WHERE s.deleted_at IS NULL AND s.branch = c.branch AND s.semester = c.semester AND s.section = c.section) AS student_count,
                           (SELECT COUNT(*) FROM subjects sub WHERE sub.class_id = c.id OR (sub.branch = c.branch AND sub.semester = c.semester AND sub.section = c.section)) AS subject_count
                    FROM classes c
                    WHERE c.id = ?;
                """, (cid,))
                r = cur.fetchone()
                if not r:
                    self.send_json(404, False, "Class not found")
                else:
                    self.send_json(200, True, "Class details retrieved", dict(r))
                return

            # 10. GET /api/subjects
            if path == "/api/subjects":
                search = params.get("search", "")
                branch = params.get("branch", "")
                sem = int(params.get("semester", 0))
                cid = int(params.get("class_id", 0))

                where = []
                prms = []
                if search:
                    where.append("(sub.subject_name LIKE ? OR sub.subject_code LIKE ? OR sub.faculty_name LIKE ?)")
                    prms.extend([f"%{search}%"] * 3)
                if branch:
                    where.append("sub.branch = ?")
                    prms.append(branch)
                if sem > 0:
                    where.append("sub.semester = ?")
                    prms.append(sem)
                if cid > 0:
                    where.append("sub.class_id = ?")
                    prms.append(cid)

                where_str = ("WHERE " + " AND ".join(where)) if where else ""
                sql = f"""
                    SELECT sub.id, sub.subject_name, sub.subject_code, sub.branch, sub.semester, sub.section,
                           sub.faculty_name, sub.class_id, sub.created_at, sub.updated_at,
                           (SELECT COUNT(DISTINCT s.id) FROM students s WHERE s.deleted_at IS NULL AND (
                               (sub.class_id IS NOT NULL AND s.branch = (SELECT c.branch FROM classes c WHERE c.id = sub.class_id) 
                                AND s.semester = (SELECT c.semester FROM classes c WHERE c.id = sub.class_id) 
                                AND s.section = (SELECT c.section FROM classes c WHERE c.id = sub.class_id))
                               OR (sub.class_id IS NULL AND s.branch = sub.branch AND s.semester = sub.semester AND (sub.section IS NULL OR sub.section = '' OR s.section = sub.section))
                           )) AS student_count,
                           (SELECT COUNT(DISTINCT a.attendance_date) FROM attendance a WHERE a.subject_id = sub.id) AS total_sessions,
                           (SELECT CAST(SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS REAL) / NULLIF(COUNT(a.id), 0) * 100.0 FROM attendance a WHERE a.subject_id = sub.id) AS average_attendance
                    FROM subjects sub
                    {where_str}
                    ORDER BY sub.semester ASC, sub.subject_code ASC;
                """
                cur.execute(sql, prms)
                items = []
                for r in cur.fetchall():
                    d = dict(r)
                    d["average_attendance"] = round(d["average_attendance"] or 0.0, 1)
                    items.append(d)
                self.send_json(200, True, "Subjects retrieved successfully", items)
                return

            # 11. GET /api/subjects/:id
            m = re.match(r"^/api/subjects/(\d+)$", path)
            if m:
                sub_id = int(m.group(1))
                cur.execute("SELECT * FROM subjects WHERE id = ?;", (sub_id,))
                r = cur.fetchone()
                if not r:
                    self.send_json(404, False, "Subject not found")
                else:
                    self.send_json(200, True, "Subject details retrieved", dict(r))
                return

            # 12. GET /api/attendance
            if path == "/api/attendance":
                date = params.get("date", "")
                sub_id = int(params.get("subject_id", 0))
                cid = int(params.get("class_id", 0))
                sid = int(params.get("student_id", 0))

                where = []
                prms = []
                if date:
                    where.append("a.attendance_date = ?")
                    prms.append(date)
                if sub_id > 0:
                    where.append("a.subject_id = ?")
                    prms.append(sub_id)
                if cid > 0:
                    where.append("(a.class_id = ? OR (s.branch = (SELECT c.branch FROM classes c WHERE c.id = ?) AND s.semester = (SELECT c.semester FROM classes c WHERE c.id = ?) AND s.section = (SELECT c.section FROM classes c WHERE c.id = ?)))")
                    prms.extend([cid, cid, cid, cid])
                if sid > 0:
                    where.append("a.student_id = ?")
                    prms.append(sid)

                where_str = ("WHERE " + " AND ".join(where)) if where else ""
                sql = f"""
                    SELECT a.id, a.student_id, a.subject_id, a.class_id, a.attendance_date, a.status, a.created_at, a.updated_at,
                           s.name AS student_name, s.enrollment_id, s.roll_number, s.branch, s.semester, s.section,
                           sub.subject_name, sub.subject_code
                    FROM attendance a
                    JOIN students s ON s.id = a.student_id
                    JOIN subjects sub ON sub.id = a.subject_id
                    {where_str}
                    ORDER BY a.attendance_date DESC, s.roll_number ASC, s.name ASC;
                """
                cur.execute(sql, prms)
                self.send_json(200, True, "Attendance records retrieved", [dict(r) for r in cur.fetchall()])
                return

            # 13. GET /api/attendance/summary
            if path == "/api/attendance/summary":
                date = params.get("date", "")
                sub_id = int(params.get("subject_id", 0))
                cid = int(params.get("class_id", 0))

                where = []
                prms = []
                if date:
                    where.append("attendance_date = ?")
                    prms.append(date)
                if sub_id > 0:
                    where.append("subject_id = ?")
                    prms.append(sub_id)
                if cid > 0:
                    where.append("class_id = ?")
                    prms.append(cid)

                where_str = ("WHERE " + " AND ".join(where)) if where else ""
                cur.execute(f"""
                    SELECT 
                        COUNT(id) AS total,
                        SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS present,
                        SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) AS absent,
                        SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) AS late
                    FROM attendance
                    {where_str};
                """, prms)
                r = cur.fetchone()
                tot = r["total"] or 0
                p = r["present"] or 0
                pct = (p / tot * 100.0) if tot > 0 else 0.0
                self.send_json(200, True, "Attendance summary calculated", {
                    "total": tot,
                    "present": p,
                    "absent": r["absent"] or 0,
                    "late": r["late"] or 0,
                    "percentage": round(pct, 1)
                })
                return

            # 14. GET /api/attendance/student/:student_id
            m = re.match(r"^/api/attendance/student/(\d+)$", path)
            if m:
                sid = int(m.group(1))
                cur.execute("""
                    SELECT a.id, a.student_id, a.subject_id, a.class_id, a.attendance_date, a.status, a.created_at, a.updated_at,
                           s.name AS student_name, s.enrollment_id, s.roll_number, s.branch, s.semester, s.section,
                           sub.subject_name, sub.subject_code
                    FROM attendance a
                    JOIN students s ON s.id = a.student_id
                    JOIN subjects sub ON sub.id = a.subject_id
                    WHERE a.student_id = ?
                    ORDER BY a.attendance_date DESC;
                """, (sid,))
                self.send_json(200, True, "Student attendance retrieved", [dict(r) for r in cur.fetchall()])
                return

            # 15. GET /api/reports/student
            if path == "/api/reports/student":
                sid = int(params.get("student_id", 0))
                cid = int(params.get("class_id", 0))
                sub_id = int(params.get("subject_id", 0))
                start_date = params.get("start_date", "")
                end_date = params.get("end_date", "")

                where = ["s.deleted_at IS NULL"]
                prms = []
                if sid > 0:
                    where.append("s.id = ?")
                    prms.append(sid)
                if sub_id > 0:
                    where.append("sub.id = ?")
                    prms.append(sub_id)
                if cid > 0:
                    where.append("s.branch = (SELECT c.branch FROM classes c WHERE c.id = ?) AND s.semester = (SELECT c.semester FROM classes c WHERE c.id = ?) AND s.section = (SELECT c.section FROM classes c WHERE c.id = ?)")
                    prms.extend([cid, cid, cid])
                if start_date:
                    where.append("(a.attendance_date IS NULL OR a.attendance_date >= ?)")
                    prms.append(start_date)
                if end_date:
                    where.append("(a.attendance_date IS NULL OR a.attendance_date <= ?)")
                    prms.append(end_date)

                where_str = "WHERE " + " AND ".join(where)
                sql = f"""
                    SELECT 
                        s.id AS student_id,
                        s.enrollment_id,
                        s.name AS student_name,
                        s.roll_number,
                        s.branch,
                        s.semester,
                        s.section,
                        sub.id AS subject_id,
                        sub.subject_name,
                        sub.subject_code,
                        COUNT(a.id) AS total_classes,
                        SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present,
                        SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent,
                        SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late
                    FROM students s
                    CROSS JOIN subjects sub
                    LEFT JOIN attendance a ON a.student_id = s.id AND a.subject_id = sub.id
                    {where_str}
                    GROUP BY s.id, sub.id HAVING total_classes > 0
                    ORDER BY s.roll_number ASC, sub.subject_code ASC;
                """
                cur.execute(sql, prms)
                rows = []
                for r in cur.fetchall():
                    d = dict(r)
                    tot = d["total_classes"]
                    p = d["present"]
                    pct = (p / tot * 100.0) if tot > 0 else 0.0
                    d["attendance_percentage"] = round(pct, 1)
                    d["is_low_attendance"] = pct < 75.0
                    rows.append(d)
                self.send_json(200, True, "Student attendance report generated", rows)
                return

            # 16. GET /api/reports/class
            if path == "/api/reports/class":
                cid = int(params.get("class_id", 0))
                start_date = params.get("start_date", "")
                end_date = params.get("end_date", "")

                where = []
                prms = []
                if cid > 0:
                    where.append("c.id = ?")
                    prms.append(cid)
                if start_date:
                    where.append("(a.attendance_date IS NULL OR a.attendance_date >= ?)")
                    prms.append(start_date)
                if end_date:
                    where.append("(a.attendance_date IS NULL OR a.attendance_date <= ?)")
                    prms.append(end_date)

                where_str = ("WHERE " + " AND ".join(where)) if where else ""
                sql = f"""
                    SELECT 
                        c.id AS class_id,
                        c.branch,
                        c.semester,
                        c.section,
                        COUNT(a.id) AS total_classes,
                        SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present,
                        SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent,
                        SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late,
                        COUNT(DISTINCT s.id) AS enrolled_students
                    FROM classes c
                    LEFT JOIN students s ON s.branch = c.branch AND s.semester = c.semester AND s.section = c.section AND s.deleted_at IS NULL
                    LEFT JOIN attendance a ON a.student_id = s.id
                    {where_str}
                    GROUP BY c.id
                    ORDER BY c.semester ASC, c.branch ASC, c.section ASC;
                """
                cur.execute(sql, prms)
                rows = []
                for r in cur.fetchall():
                    d = dict(r)
                    tot = d["total_classes"]
                    p = d["present"]
                    d["attendance_percentage"] = round((p / tot * 100.0), 1) if tot > 0 else 0.0
                    rows.append(d)
                self.send_json(200, True, "Class attendance report generated", rows)
                return

            # 17. GET /api/reports/subject
            if path == "/api/reports/subject":
                sub_id = int(params.get("subject_id", 0))
                start_date = params.get("start_date", "")
                end_date = params.get("end_date", "")

                where = []
                prms = []
                if sub_id > 0:
                    where.append("sub.id = ?")
                    prms.append(sub_id)
                if start_date:
                    where.append("(a.attendance_date IS NULL OR a.attendance_date >= ?)")
                    prms.append(start_date)
                if end_date:
                    where.append("(a.attendance_date IS NULL OR a.attendance_date <= ?)")
                    prms.append(end_date)

                where_str = ("WHERE " + " AND ".join(where)) if where else ""
                sql = f"""
                    SELECT 
                        sub.id AS subject_id,
                        sub.subject_name,
                        sub.subject_code,
                        sub.faculty_name,
                        sub.branch,
                        sub.semester,
                        COUNT(a.id) AS total_classes,
                        SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present,
                        SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent,
                        SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late,
                        COUNT(DISTINCT a.attendance_date) AS total_sessions
                    FROM subjects sub
                    LEFT JOIN attendance a ON a.subject_id = sub.id
                    {where_str}
                    GROUP BY sub.id
                    ORDER BY sub.semester ASC, sub.subject_code ASC;
                """
                cur.execute(sql, prms)
                rows = []
                for r in cur.fetchall():
                    d = dict(r)
                    tot = d["total_classes"]
                    p = d["present"]
                    d["attendance_percentage"] = round((p / tot * 100.0), 1) if tot > 0 else 0.0
                    rows.append(d)
                self.send_json(200, True, "Subject attendance report generated", rows)
                return

            # 18. GET /api/reports/daily
            if path == "/api/reports/daily":
                date = params.get("date", "")
                cid = int(params.get("class_id", 0))
                sub_id = int(params.get("subject_id", 0))

                where = []
                prms = []
                if date:
                    where.append("a.attendance_date = ?")
                    prms.append(date)
                if sub_id > 0:
                    where.append("a.subject_id = ?")
                    prms.append(sub_id)
                if cid > 0:
                    where.append("(a.class_id = ? OR (s.branch = (SELECT c.branch FROM classes c WHERE c.id = ?) AND s.semester = (SELECT c.semester FROM classes c WHERE c.id = ?) AND s.section = (SELECT c.section FROM classes c WHERE c.id = ?)))")
                    prms.extend([cid, cid, cid, cid])

                where_str = ("WHERE " + " AND ".join(where)) if where else ""
                sql = f"""
                    SELECT a.id, a.student_id, a.subject_id, a.class_id, a.attendance_date, a.status, a.created_at, a.updated_at,
                           s.name AS student_name, s.enrollment_id, s.roll_number, s.branch, s.semester, s.section,
                           sub.subject_name, sub.subject_code
                    FROM attendance a
                    JOIN students s ON s.id = a.student_id
                    JOIN subjects sub ON sub.id = a.subject_id
                    {where_str}
                    ORDER BY a.attendance_date DESC, s.roll_number ASC, s.name ASC;
                """
                cur.execute(sql, prms)
                self.send_json(200, True, "Daily report generated", [dict(r) for r in cur.fetchall()])
                return

            # 19. GET /api/reports/monthly
            if path == "/api/reports/monthly":
                month = params.get("month", "")
                cid = int(params.get("class_id", 0))
                sub_id = int(params.get("subject_id", 0))

                where = ["a.attendance_date LIKE ?"]
                prms = [f"{month}%"]
                if cid > 0:
                    where.append("a.class_id = ?")
                    prms.append(cid)
                if sub_id > 0:
                    where.append("a.subject_id = ?")
                    prms.append(sub_id)

                where_str = "WHERE " + " AND ".join(where)
                sql = f"""
                    SELECT 
                        s.id AS student_id,
                        s.enrollment_id,
                        s.name AS student_name,
                        s.roll_number,
                        sub.subject_name,
                        sub.subject_code,
                        COUNT(a.id) AS total_classes,
                        SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present,
                        SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent,
                        SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late
                    FROM attendance a
                    JOIN students s ON s.id = a.student_id
                    JOIN subjects sub ON sub.id = a.subject_id
                    {where_str}
                    GROUP BY s.id, sub.id
                    ORDER BY s.roll_number ASC, sub.subject_code ASC;
                """
                cur.execute(sql, prms)
                rows = []
                for r in cur.fetchall():
                    d = dict(r)
                    tot = d["total_classes"]
                    p = d["present"]
                    pct = (p / tot * 100.0) if tot > 0 else 0.0
                    d["attendance_percentage"] = round(pct, 1)
                    d["is_low_attendance"] = pct < 75.0
                    rows.append(d)
                self.send_json(200, True, "Monthly report generated", rows)
                return

            # 20. GET /api/reports/low-attendance
            if path == "/api/reports/low-attendance":
                threshold = float(params.get("threshold", 75.0))
                cur.execute("""
                    SELECT s.id, s.enrollment_id, s.name, s.roll_number, s.branch, s.section, s.semester,
                           s.email, s.phone, s.created_at, s.updated_at, s.deleted_at,
                           COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id), 0) AS total_classes,
                           COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id AND a.status = 'Present'), 0) AS present_classes,
                           COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id AND a.status = 'Absent'), 0) AS absent_classes,
                           COALESCE((SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id AND a.status = 'Late'), 0) AS late_classes
                    FROM students s
                    WHERE s.deleted_at IS NULL
                    ORDER BY s.semester ASC, s.branch ASC, s.section ASC, s.roll_number ASC;
                """)
                low = []
                for r in cur.fetchall():
                    d = dict(r)
                    tot = d["total_classes"]
                    if tot > 0:
                        pct = (d["present_classes"] / tot) * 100.0
                        if pct < threshold:
                            d["attendance_percentage"] = round(pct, 1)
                            low.append(d)
                self.send_json(200, True, "Low attendance students list", low)
                return

            # 21. GET /api/reports/export
            if path == "/api/reports/export":
                report_type = params.get("type", "student")
                cid = int(params.get("class_id", 0))
                sub_id = int(params.get("subject_id", 0))
                sid = int(params.get("student_id", 0))
                start_date = params.get("start_date", "")
                end_date = params.get("end_date", "")
                date = params.get("date", "")
                month = params.get("month", "")

                lines = []
                if report_type == "class":
                    lines.append("Class ID,Branch,Semester,Section,Enrolled Students,Total Records,Present,Absent,Late,Attendance %")
                    where = []
                    prms = []
                    if cid > 0: where.append("c.id = ?"); prms.append(cid)
                    if start_date: where.append("(a.attendance_date IS NULL OR a.attendance_date >= ?)"); prms.append(start_date)
                    if end_date: where.append("(a.attendance_date IS NULL OR a.attendance_date <= ?)"); prms.append(end_date)
                    w_str = ("WHERE " + " AND ".join(where)) if where else ""
                    cur.execute(f"""
                        SELECT c.id, c.branch, c.semester, c.section, COUNT(a.id) AS total,
                               SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS pres,
                               SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS abs,
                               SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late,
                               COUNT(DISTINCT s.id) AS enrolled
                        FROM classes c
                        LEFT JOIN students s ON s.branch = c.branch AND s.semester = c.semester AND s.section = c.section AND s.deleted_at IS NULL
                        LEFT JOIN attendance a ON a.student_id = s.id
                        {w_str}
                        GROUP BY c.id ORDER BY c.semester ASC, c.branch ASC, c.section ASC;
                    """, prms)
                    for r in cur.fetchall():
                        tot = r["total"] or 0
                        p = r["pres"] or 0
                        pct = (p / tot * 100.0) if tot > 0 else 0.0
                        lines.append(f'{r["id"]},"{r["branch"]}",{r["semester"]},"{r["section"]}",{r["enrolled"] or 0},{tot},{p},{r["abs"] or 0},{r["late"] or 0},{pct:.1f}%')

                elif report_type == "subject":
                    lines.append("Subject ID,Subject Code,Subject Name,Faculty,Branch,Semester,Sessions,Total Records,Present,Absent,Late,Attendance %")
                    where = []
                    prms = []
                    if sub_id > 0: where.append("sub.id = ?"); prms.append(sub_id)
                    if start_date: where.append("(a.attendance_date IS NULL OR a.attendance_date >= ?)"); prms.append(start_date)
                    if end_date: where.append("(a.attendance_date IS NULL OR a.attendance_date <= ?)"); prms.append(end_date)
                    w_str = ("WHERE " + " AND ".join(where)) if where else ""
                    cur.execute(f"""
                        SELECT sub.id, sub.subject_code, sub.subject_name, sub.faculty_name, sub.branch, sub.semester,
                               COUNT(a.id) AS total,
                               SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS pres,
                               SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS abs,
                               SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late,
                               COUNT(DISTINCT a.attendance_date) AS sessions
                        FROM subjects sub
                        LEFT JOIN attendance a ON a.subject_id = sub.id
                        {w_str}
                        GROUP BY sub.id ORDER BY sub.semester ASC, sub.subject_code ASC;
                    """, prms)
                    for r in cur.fetchall():
                        tot = r["total"] or 0
                        p = r["pres"] or 0
                        pct = (p / tot * 100.0) if tot > 0 else 0.0
                        lines.append(f'{r["id"]},"{r["subject_code"]}","{r["subject_name"]}","{r["faculty_name"] or ""}","{r["branch"] or ""}",{r["semester"]},{r["sessions"] or 0},{tot},{p},{r["abs"] or 0},{r["late"] or 0},{pct:.1f}%')

                elif report_type == "daily":
                    lines.append("ID,Date,Enrollment ID,Roll Number,Student Name,Branch,Semester,Section,Subject Code,Subject Name,Status")
                    where = []
                    prms = []
                    if date: where.append("a.attendance_date = ?"); prms.append(date)
                    if sub_id > 0: where.append("a.subject_id = ?"); prms.append(sub_id)
                    if cid > 0:
                        where.append("(a.class_id = ? OR (s.branch = (SELECT c.branch FROM classes c WHERE c.id = ?) AND s.semester = (SELECT c.semester FROM classes c WHERE c.id = ?) AND s.section = (SELECT c.section FROM classes c WHERE c.id = ?)))")
                        prms.extend([cid, cid, cid, cid])
                    w_str = ("WHERE " + " AND ".join(where)) if where else ""
                    cur.execute(f"""
                        SELECT a.id, a.attendance_date, s.enrollment_id, s.roll_number, s.name, s.branch, s.semester, s.section,
                               sub.subject_code, sub.subject_name, a.status
                        FROM attendance a
                        JOIN students s ON s.id = a.student_id
                        JOIN subjects sub ON sub.id = a.subject_id
                        {w_str} ORDER BY a.attendance_date DESC, s.roll_number ASC;
                    """, prms)
                    for r in cur.fetchall():
                        lines.append(f'{r["id"]},"{r["attendance_date"]}","{r["enrollment_id"]}","{r["roll_number"] or ""}","{r["name"]}","{r["branch"]}",{r["semester"]},"{r["section"]}","{r["subject_code"]}","{r["subject_name"]}","{r["status"]}"')

                else:
                    lines.append("Enrollment ID,Roll Number,Student Name,Branch,Semester,Section,Subject Code,Subject Name,Total Classes,Present,Absent,Late,Attendance %,Status")
                    where = ["s.deleted_at IS NULL"]
                    prms = []
                    if sid > 0: where.append("s.id = ?"); prms.append(sid)
                    if sub_id > 0: where.append("sub.id = ?"); prms.append(sub_id)
                    if cid > 0:
                        where.append("s.branch = (SELECT c.branch FROM classes c WHERE c.id = ?) AND s.semester = (SELECT c.semester FROM classes c WHERE c.id = ?) AND s.section = (SELECT c.section FROM classes c WHERE c.id = ?)")
                        prms.extend([cid, cid, cid])
                    if start_date: where.append("(a.attendance_date IS NULL OR a.attendance_date >= ?)"); prms.append(start_date)
                    if end_date: where.append("(a.attendance_date IS NULL OR a.attendance_date <= ?)"); prms.append(end_date)
                    w_str = "WHERE " + " AND ".join(where)
                    cur.execute(f"""
                        SELECT s.enrollment_id, s.roll_number, s.name, s.branch, s.semester, s.section,
                               sub.subject_code, sub.subject_name, COUNT(a.id) AS total,
                               SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS pres,
                               SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS abs,
                               SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late
                        FROM students s
                        CROSS JOIN subjects sub
                        LEFT JOIN attendance a ON a.student_id = s.id AND a.subject_id = sub.id
                        {w_str}
                        GROUP BY s.id, sub.id HAVING total > 0
                        ORDER BY s.roll_number ASC, sub.subject_code ASC;
                    """, prms)
                    for r in cur.fetchall():
                        tot = r["total"] or 0
                        p = r["pres"] or 0
                        pct = (p / tot * 100.0) if tot > 0 else 0.0
                        status_str = "Critical" if pct < 75.0 else ("Warning" if pct < 80.0 else "Normal")
                        lines.append(f'"{r["enrollment_id"]}","{r["roll_number"] or ""}","{r["name"]}","{r["branch"]}",{r["semester"]},"{r["section"]}","{r["subject_code"]}","{r["subject_name"]}",{tot},{p},{r["abs"] or 0},{r["late"] or 0},{pct:.1f}%,{status_str}')

                self.send_csv("\n".join(lines) + "\n", f"attendx_report_{report_type}.csv")
                return

            self.send_json(404, False, f"API endpoint not found: {path}")

        finally:
            conn.close()

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = {k: v[0] for k, v in parse_qs(parsed.query).items()}

        conn = get_db_connection(self.db_path)
        cur = conn.cursor()

        try:
            # 1. POST /api/auth/login
            if path == "/api/auth/login":
                body = self.read_json_body()
                username = body.get("username", "")
                password = body.get("password", "")

                cur.execute("SELECT id, username, password_hash, salt, role FROM users WHERE username = ?;", (username,))
                user = cur.fetchone()
                if not user:
                    self.send_json(401, False, "Invalid username or password")
                    return

                calc_hash = hash_password(password, user["salt"])
                if calc_hash != user["password_hash"]:
                    self.send_json(401, False, "Invalid username or password")
                    return

                token = uuid.uuid4().hex
                sessions[token] = {
                    "userId": user["id"],
                    "username": user["username"],
                    "role": user["role"],
                    "expiresAt": datetime.datetime.now() + datetime.timedelta(days=7)
                }

                cookie_val = f"attendx_token={token}; Path=/; HttpOnly; SameSite=Lax"
                self.send_json(200, True, "Login successful", {
                    "token": token,
                    "user": {
                        "id": user["id"],
                        "username": user["username"],
                        "role": user["role"]
                    }
                }, extra_headers={"Set-Cookie": cookie_val})
                return

            # 2. POST /api/auth/logout
            if path == "/api/auth/logout":
                token = self.extract_token()
                if token and token in sessions:
                    del sessions[token]
                cookie_val = "attendx_token=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT"
                self.send_json(200, True, "Logged out successfully", extra_headers={"Set-Cookie": cookie_val})
                return

            # 3. POST /api/auth/change-password
            if path == "/api/auth/change-password":
                sess = self.require_auth()
                if not sess: return
                body = self.read_json_body()
                old_pass = body.get("old_password", "")
                new_pass = body.get("new_password", "")

                cur.execute("SELECT password_hash, salt FROM users WHERE id = ?;", (sess["userId"],))
                u = cur.fetchone()
                if not u or hash_password(old_pass, u["salt"]) != u["password_hash"]:
                    self.send_json(400, False, "Incorrect old password")
                    return

                new_salt = uuid.uuid4().hex[:16]
                new_hash = hash_password(new_pass, new_salt)
                cur.execute("UPDATE users SET password_hash = ?, salt = ? WHERE id = ?;", (new_hash, new_salt, sess["userId"]))
                conn.commit()
                self.send_json(200, True, "Password changed successfully")
                return

            # 4. POST /api/seed
            if path == "/api/seed":
                force = params.get("force") == "true"
                ok, msg = seed_demo_data(self.db_path, force=force)
                self.send_json(200 if ok else 400, ok, msg)
                return

            # 5. POST /api/students
            if path == "/api/students":
                sess = self.require_auth()
                if not sess: return
                body = self.read_json_body()
                now = get_current_timestamp()
                cur.execute("""
                    INSERT INTO students (enrollment_id, name, roll_number, branch, section, semester, email, phone, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                """, (
                    body.get("enrollment_id"), body.get("name"), body.get("roll_number"),
                    body.get("branch"), body.get("section"), body.get("semester", 1),
                    body.get("email", ""), body.get("phone", ""), now, now
                ))
                conn.commit()
                new_id = cur.lastrowid
                body["id"] = new_id
                self.send_json(201, True, "Student registered successfully", body)
                return

            # 6. POST /api/students/:id/restore
            m = re.match(r"^/api/students/(\d+)/restore$", path)
            if m:
                sess = self.require_auth()
                if not sess: return
                sid = int(m.group(1))
                now = get_current_timestamp()
                cur.execute("UPDATE students SET deleted_at = NULL, updated_at = ? WHERE id = ?;", (now, sid))
                conn.commit()
                self.send_json(200, True, "Student restored successfully")
                return

            # 7. POST /api/classes
            if path == "/api/classes":
                sess = self.require_auth()
                if not sess: return
                body = self.read_json_body()
                now = get_current_timestamp()
                cur.execute("""
                    INSERT INTO classes (branch, semester, section, academic_year, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?);
                """, (body.get("branch"), body.get("semester"), body.get("section"), body.get("academic_year", ""), now, now))
                conn.commit()
                body["id"] = cur.lastrowid
                self.send_json(201, True, "Class cohort created successfully", body)
                return

            # 8. POST /api/subjects
            if path == "/api/subjects":
                sess = self.require_auth()
                if not sess: return
                body = self.read_json_body()
                now = get_current_timestamp()
                cur.execute("""
                    INSERT INTO subjects (subject_name, subject_code, branch, semester, section, faculty_name, class_id, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
                """, (
                    body.get("subject_name"), body.get("subject_code"), body.get("branch", ""),
                    body.get("semester", 1), body.get("section", ""), body.get("faculty_name", ""),
                    body.get("class_id"), now, now
                ))
                conn.commit()
                body["id"] = cur.lastrowid
                self.send_json(201, True, "Subject registered successfully", body)
                return

            # 9. POST /api/attendance (Single record)
            if path == "/api/attendance":
                sess = self.require_auth()
                if not sess: return
                body = self.read_json_body()
                now = get_current_timestamp()
                cur.execute("""
                    INSERT INTO attendance (student_id, subject_id, class_id, attendance_date, status, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(student_id, subject_id, attendance_date)
                    DO UPDATE SET status=excluded.status, class_id=excluded.class_id, updated_at=excluded.updated_at;
                """, (
                    body["student_id"], body["subject_id"], body.get("class_id"),
                    body["attendance_date"], body["status"], now, now
                ))
                conn.commit()
                body["id"] = cur.lastrowid
                self.send_json(201, True, "Attendance logged successfully", body)
                return

            # 10. POST /api/attendance/bulk
            if path == "/api/attendance/bulk":
                sess = self.require_auth()
                if not sess: return
                body = self.read_json_body()
                records = body.get("records", [])
                now = get_current_timestamp()
                updated_count = 0
                inserted_count = 0
                for rec in records:
                    cur.execute("SELECT id FROM attendance WHERE student_id = ? AND subject_id = ? AND attendance_date = ?;",
                                (rec["student_id"], rec["subject_id"], rec["attendance_date"]))
                    exists = cur.fetchone() is not None

                    cur.execute("""
                        INSERT INTO attendance (student_id, subject_id, class_id, attendance_date, status, created_at, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                        ON CONFLICT(student_id, subject_id, attendance_date)
                        DO UPDATE SET status=excluded.status, class_id=excluded.class_id, updated_at=excluded.updated_at;
                    """, (
                        rec["student_id"], rec["subject_id"], rec.get("class_id"),
                        rec["attendance_date"], rec["status"], now, now
                    ))
                    if exists: updated_count += 1
                    else: inserted_count += 1
                conn.commit()
                self.send_json(200, True, f"Attendance saved ({inserted_count} recorded, {updated_count} updated)", {
                    "inserted": inserted_count,
                    "updated": updated_count
                })
                return

            self.send_json(404, False, f"API endpoint not found: {path}")

        except Exception as e:
            self.send_json(500, False, str(e))
        finally:
            conn.close()

    def do_PUT(self):
        parsed = urlparse(self.path)
        path = parsed.path
        conn = get_db_connection(self.db_path)
        cur = conn.cursor()

        try:
            sess = self.require_auth()
            if not sess: return
            body = self.read_json_body()
            now = get_current_timestamp()

            # PUT /api/students/:id
            m = re.match(r"^/api/students/(\d+)$", path)
            if m:
                sid = int(m.group(1))
                cur.execute("""
                    UPDATE students
                    SET enrollment_id=?, name=?, roll_number=?, branch=?, section=?, semester=?, email=?, phone=?, updated_at=?
                    WHERE id=?;
                """, (
                    body.get("enrollment_id"), body.get("name"), body.get("roll_number"),
                    body.get("branch"), body.get("section"), body.get("semester"),
                    body.get("email"), body.get("phone"), now, sid
                ))
                conn.commit()
                body["id"] = sid
                self.send_json(200, True, "Student updated successfully", body)
                return

            # PUT /api/classes/:id
            m = re.match(r"^/api/classes/(\d+)$", path)
            if m:
                cid = int(m.group(1))
                cur.execute("""
                    UPDATE classes
                    SET branch=?, semester=?, section=?, academic_year=?, updated_at=?
                    WHERE id=?;
                """, (body.get("branch"), body.get("semester"), body.get("section"), body.get("academic_year"), now, cid))
                conn.commit()
                body["id"] = cid
                self.send_json(200, True, "Class updated successfully", body)
                return

            # PUT /api/subjects/:id
            m = re.match(r"^/api/subjects/(\d+)$", path)
            if m:
                sub_id = int(m.group(1))
                cur.execute("""
                    UPDATE subjects
                    SET subject_name=?, subject_code=?, branch=?, semester=?, section=?, faculty_name=?, class_id=?, updated_at=?
                    WHERE id=?;
                """, (
                    body.get("subject_name"), body.get("subject_code"), body.get("branch"),
                    body.get("semester"), body.get("section"), body.get("faculty_name"),
                    body.get("class_id"), now, sub_id
                ))
                conn.commit()
                body["id"] = sub_id
                self.send_json(200, True, "Subject updated successfully", body)
                return

            # PUT /api/attendance/:id
            m = re.match(r"^/api/attendance/(\d+)$", path)
            if m:
                aid = int(m.group(1))
                status = body.get("status")
                cur.execute("UPDATE attendance SET status=?, updated_at=? WHERE id=?;", (status, now, aid))
                conn.commit()
                self.send_json(200, True, "Attendance entry updated successfully", {"id": aid, "status": status})
                return

            self.send_json(404, False, f"API endpoint not found: {path}")

        except Exception as e:
            self.send_json(500, False, str(e))
        finally:
            conn.close()

    def do_DELETE(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = {k: v[0] for k, v in parse_qs(parsed.query).items()}
        conn = get_db_connection(self.db_path)
        cur = conn.cursor()

        try:
            sess = self.require_auth()
            if not sess: return
            now = get_current_timestamp()

            # DELETE /api/students/:id
            m = re.match(r"^/api/students/(\d+)$", path)
            if m:
                sid = int(m.group(1))
                hard = params.get("hard") == "true"
                if hard:
                    cur.execute("DELETE FROM students WHERE id = ?;", (sid,))
                else:
                    cur.execute("UPDATE students SET deleted_at = ?, updated_at = ? WHERE id = ?;", (now, now, sid))
                conn.commit()
                self.send_json(200, True, "Student deleted successfully")
                return

            # DELETE /api/classes/:id
            m = re.match(r"^/api/classes/(\d+)$", path)
            if m:
                cid = int(m.group(1))
                cur.execute("DELETE FROM classes WHERE id = ?;", (cid,))
                conn.commit()
                self.send_json(200, True, "Class deleted successfully")
                return

            # DELETE /api/subjects/:id
            m = re.match(r"^/api/subjects/(\d+)$", path)
            if m:
                sub_id = int(m.group(1))
                cur.execute("DELETE FROM subjects WHERE id = ?;", (sub_id,))
                conn.commit()
                self.send_json(200, True, "Subject deleted successfully")
                return

            self.send_json(404, False, f"API endpoint not found: {path}")

        except Exception as e:
            self.send_json(500, False, str(e))
        finally:
            conn.close()

def main():
    parser = argparse.ArgumentParser(description="ATTENDX — Smart Student Attendance Management System")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8080")), help="HTTP server port")
    parser.add_argument("--host", type=str, default=os.environ.get("HOST", "0.0.0.0"), help="HTTP host bind address")
    parser.add_argument("--db", type=str, default=os.environ.get("DB_PATH", DEFAULT_DB_PATH), help="SQLite database path")
    parser.add_argument("--static", type=str, default=os.environ.get("STATIC_DIR", FRONTEND_DIR), help="Frontend static assets directory")
    parser.add_argument("--seed", action="store_true", help="Seed database with demo dataset on startup")
    args = parser.parse_args()

    print("==========================================================")
    print("  ATTENDX — Smart Student Attendance Management System    ")
    print("  Enterprise Academic Intelligence Platform               ")
    print("==========================================================")

    init_database(args.db)

    if args.seed:
        print("[AttendX] Seeding demo dataset...")
        ok, msg = seed_demo_data(args.db, force=True)
        print(f"[AttendX] {msg}")

    AttendXHandler.db_path = args.db
    AttendXHandler.static_dir = args.static

    server_address = (args.host, args.port)
    httpd = HTTPServer(server_address, AttendXHandler)

    display_host = "localhost" if args.host in ("0.0.0.0", "127.0.0.1", "") else args.host
    print(f"[AttendX] Server listening on http://{display_host}:{args.port}")
    print("[AttendX] Default Administrator Credentials:")
    print("          Username: admin")
    print("          Password: Admin@123")
    print("[AttendX] Ready for connections...")
    print("----------------------------------------------------------")

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[AttendX] Shutting down server gracefully...")
        httpd.server_close()

if __name__ == "__main__":
    main()
