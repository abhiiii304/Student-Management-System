#define CROW_USE_BOOST 0
#define ASIO_STANDALONE
#include "third_party/Crow-1.2.0/include/crow.h"
#include <iostream>

int main() {
    crow::SimpleApp app;
    CROW_ROUTE(app, "/")([](){
        return "Hello world";
    });
    std::cout << "Crow compiled successfully!" << std::endl;
    return 0;
}
