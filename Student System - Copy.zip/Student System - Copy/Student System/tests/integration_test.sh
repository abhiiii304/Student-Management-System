#!/bin/bash
set -e

PORT=8089
HOST="127.0.0.1"
BASE_URL="http://${HOST}:${PORT}"
DB_TEST="database/test_attendx.db"

rm -f "$DB_TEST"

echo "=========================================================="
echo "  ATTENDX — Complete Automated Integration Test Suite    "
echo "=========================================================="

# Start server in background
./attendx_server --port "$PORT" --host "$HOST" --db "$DB_TEST" --seed &
SERVER_PID=$!

cleanup() {
    echo "Stopping test server (PID $SERVER_PID)..."
    kill "$SERVER_PID" 2>/dev/null || true
    wait "$SERVER_PID" 2>/dev/null || true
    rm -f "$DB_TEST"
}
trap cleanup EXIT

# Wait for server to bind
sleep 2

PASSED=0
FAILED=0

assert_test() {
    local name="$1"
    local condition="$2"
    if eval "$condition"; then
        echo "  [PASS] $name"
        PASSED=$((PASSED + 1))
    else
        echo "  [FAIL] $name"
        FAILED=$((FAILED + 1))
    fi
}

echo "\n--- 1. Testing Static HTML & Asset Delivery ---"
STATUS_ROOT=$(curl -s -o /dev/null -w "%{http_code}" "$BASE_URL/")
assert_test "GET / serves index.html (200)" "[ '$STATUS_ROOT' = '200' ]"

STATUS_STUDENTS=$(curl -s -o /dev/null -w "%{http_code}" "$BASE_URL/students")
assert_test "GET /students serves students.html (200)" "[ '$STATUS_STUDENTS' = '200' ]"

STATUS_ATT=$(curl -s -o /dev/null -w "%{http_code}" "$BASE_URL/attendance")
assert_test "GET /attendance serves attendance.html (200)" "[ '$STATUS_ATT' = '200' ]"

STATUS_CLASSES=$(curl -s -o /dev/null -w "%{http_code}" "$BASE_URL/classes")
assert_test "GET /classes serves classes.html (200)" "[ '$STATUS_CLASSES' = '200' ]"

STATUS_REPORTS=$(curl -s -o /dev/null -w "%{http_code}" "$BASE_URL/reports")
assert_test "GET /reports serves reports.html (200)" "[ '$STATUS_REPORTS' = '200' ]"

STATUS_LOGIN=$(curl -s -o /dev/null -w "%{http_code}" "$BASE_URL/login")
assert_test "GET /login serves login.html (200)" "[ '$STATUS_LOGIN' = '200' ]"

STATUS_CSS=$(curl -s -o /dev/null -w "%{http_code}" "$BASE_URL/assets/css/styles.css")
assert_test "GET /assets/css/styles.css delivered (200)" "[ '$STATUS_CSS' = '200' ]"

echo "\n--- 2. Testing Authentication & Session Security ---"
# Invalid credentials check
LOGIN_FAIL_RESP=$(curl -s -X POST "$BASE_URL/api/auth/login" -H "Content-Type: application/json" -d '{"username":"admin","password":"WrongPassword"}')
assert_test "Login with invalid password rejected (401)" "echo '$LOGIN_FAIL_RESP' | grep -q '\"success\":false'"

# Valid credentials check
LOGIN_RESP=$(curl -s -X POST "$BASE_URL/api/auth/login" -H "Content-Type: application/json" -d '{"username":"admin","password":"Admin@123"}')
assert_test "Login with demo credentials succeeds" "echo '$LOGIN_RESP' | grep -q '\"success\":true'"

TOKEN=$(echo "$LOGIN_RESP" | grep -o '"token":"[^"]*' | cut -d'"' -f4)
assert_test "Auth token extracted" "[ -n '$TOKEN' ]"

# Test /api/auth/me
ME_RESP=$(curl -s "$BASE_URL/api/auth/me" -H "Authorization: Bearer $TOKEN")
assert_test "Auth check /api/auth/me returns admin profile" "echo '$ME_RESP' | grep -q '\"username\":\"admin\"'"

echo "\n--- 3. Testing Dashboard Analytics ---"
STATS_RESP=$(curl -s "$BASE_URL/api/dashboard/stats")
assert_test "Dashboard stats returns total_students >= 20" "echo '$STATS_RESP' | grep -q '\"total_students\":24'"
assert_test "Dashboard stats returns active classes" "echo '$STATS_RESP' | grep -q '\"total_classes\":4'"
assert_test "Dashboard stats returns active subjects" "echo '$STATS_RESP' | grep -q '\"total_subjects\":6'"

TRENDS_RESP=$(curl -s "$BASE_URL/api/dashboard/attendance-trends?range=daily")
assert_test "Attendance trends endpoint returns series data" "echo '$TRENDS_RESP' | grep -q '\"date\"'"

DIST_RESP=$(curl -s "$BASE_URL/api/dashboard/attendance-distribution")
assert_test "Attendance distribution returns present and absent counts" "echo '$DIST_RESP' | grep -q '\"present\"'"

RECENT_RESP=$(curl -s "$BASE_URL/api/dashboard/recent-activity?limit=5")
assert_test "Recent activity returns latest entries" "echo '$RECENT_RESP' | grep -q '\"student_name\"'"

echo "\n--- 4. Testing Student Management CRUD ---"
# Create student
NEW_STUDENT_RESP=$(curl -s -X POST "$BASE_URL/api/students" -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"enrollment_id":"EN999999","name":"Integration Test Student","roll_number":"CS-99","branch":"CSE","section":"A","semester":6,"email":"test.student@attendx.edu","phone":"+91 99999 88888"}')
assert_test "Student created successfully (201)" "echo '$NEW_STUDENT_RESP' | grep -q '\"success\":true'"

STUDENT_ID=$(echo "$NEW_STUDENT_RESP" | grep -o '"id":[0-9]*' | head -n 1 | cut -d':' -f2)
assert_test "Created Student ID obtained" "[ -n '$STUDENT_ID' ]"

# Read student by ID
GET_STUDENT=$(curl -s "$BASE_URL/api/students/$STUDENT_ID")
assert_test "Read student details by ID" "echo '$GET_STUDENT' | grep -q '\"name\":\"Integration Test Student\"'"

# Update student
UPDATE_STUDENT=$(curl -s -X PUT "$BASE_URL/api/students/$STUDENT_ID" -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"enrollment_id":"EN999999","name":"Integration Test Student Updated","roll_number":"CS-99","branch":"CSE","section":"A","semester":6,"email":"test.updated@attendx.edu"}')
assert_test "Update student details" "echo '$UPDATE_STUDENT' | grep -q '\"name\":\"Integration Test Student Updated\"'"

# Search student
SEARCH_STUDENT=$(curl -s "$BASE_URL/api/students?search=Integration")
assert_test "Search student by name" "echo '$SEARCH_STUDENT' | grep -q 'Integration Test Student Updated'"

# Duplicate enrollment ID rejection
DUP_STUDENT=$(curl -s -X POST "$BASE_URL/api/students" -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"enrollment_id":"EN999999","name":"Duplicate Student","roll_number":"CS-100","branch":"CSE","section":"A","semester":6}')
assert_test "Duplicate enrollment ID prevented" "echo '$DUP_STUDENT' | grep -q 'already exists'"

# Soft delete student
DEL_STUDENT=$(curl -s -X DELETE "$BASE_URL/api/students/$STUDENT_ID" -H "Authorization: Bearer $TOKEN")
assert_test "Soft delete student succeeds" "echo '$DEL_STUDENT' | grep -q '\"success\":true'"

# Verify student not in active list
LIST_ACTIVE=$(curl -s "$BASE_URL/api/students?search=EN999999")
assert_test "Deleted student excluded from active search" "! echo '$LIST_ACTIVE' | grep -q '\"total\":1'"

# Restore student
RESTORE_STUDENT=$(curl -s -X POST "$BASE_URL/api/students/$STUDENT_ID/restore" -H "Authorization: Bearer $TOKEN")
assert_test "Restore soft-deleted student" "echo '$RESTORE_STUDENT' | grep -q '\"success\":true'"

echo "\n--- 5. Testing Classes and Subjects Management ---"
# Create Class
NEW_CLASS=$(curl -s -X POST "$BASE_URL/api/classes" -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"branch":"AI-DS","semester":4,"section":"A","academic_year":"2026-2027"}')
assert_test "Create new academic class cohort" "echo '$NEW_CLASS' | grep -q '\"success\":true'"
CLASS_ID=$(echo "$NEW_CLASS" | grep -o '"id":[0-9]*' | head -n 1 | cut -d':' -f2)

# Create Subject
NEW_SUB=$(curl -s -X POST "$BASE_URL/api/subjects" -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d "{\"subject_name\":\"Machine Learning Systems\",\"subject_code\":\"AI401\",\"branch\":\"AI-DS\",\"semester\":4,\"section\":\"A\",\"faculty_name\":\"Dr. Alan Turing\",\"class_id\":$CLASS_ID}")
assert_test "Create curriculum subject with class assignment" "echo '$NEW_SUB' | grep -q '\"success\":true'"
SUB_ID=$(echo "$NEW_SUB" | grep -o '"id":[0-9]*' | head -n 1 | cut -d':' -f2)

echo "\n--- 6. Testing Attendance Operations & Duplicate Prevention ---"
# Mark single attendance
ATT_RECORD=$(curl -s -X POST "$BASE_URL/api/attendance" -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d "{\"student_id\":$STUDENT_ID,\"subject_id\":$SUB_ID,\"class_id\":$CLASS_ID,\"attendance_date\":\"2026-11-23\",\"status\":\"Present\"}")
assert_test "Record individual student attendance" "echo '$ATT_RECORD' | grep -q '\"success\":true'"

# Re-recording same student, subject, date updates record (no duplicate error)
ATT_RE_RECORD=$(curl -s -X POST "$BASE_URL/api/attendance" -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d "{\"student_id\":$STUDENT_ID,\"subject_id\":$SUB_ID,\"class_id\":$CLASS_ID,\"attendance_date\":\"2026-11-23\",\"status\":\"Late\"}")
assert_test "Duplicate attendance upserts status gracefully" "echo '$ATT_RE_RECORD' | grep -q '\"status\":\"Late\"'"

# Bulk mark attendance
BULK_ATT=$(curl -s -X POST "$BASE_URL/api/attendance/bulk" -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d "{\"subject_id\":$SUB_ID,\"class_id\":$CLASS_ID,\"attendance_date\":\"2026-11-22\",\"records\":[{\"student_id\":$STUDENT_ID,\"status\":\"Present\"}]}")
assert_test "Bulk attendance processing" "echo '$BULK_ATT' | grep -q '\"success\":true'"

echo "\n--- 7. Testing Reports, Analytics & CSV Export ---"
REP_STUDENT=$(curl -s "$BASE_URL/api/reports/student?student_id=$STUDENT_ID")
assert_test "Student-wise attendance calculation report" "echo '$REP_STUDENT' | grep -q '\"attendance_percentage\"'"

REP_LOW=$(curl -s "$BASE_URL/api/reports/low-attendance?threshold=75")
assert_test "Low attendance threshold filter identifies students < 75%" "echo '$REP_LOW' | grep -q '\"success\":true'"

CSV_EXPORT=$(curl -s "$BASE_URL/api/reports/export?type=student")
assert_test "CSV export contains valid CSV headers and rows" "echo '$CSV_EXPORT' | grep -q 'Enrollment ID,Roll Number,Student Name'"

echo "\n=========================================================="
echo "  TEST SUMMARY: $PASSED passed, $FAILED failed"
echo "=========================================================="

if [ "$FAILED" -eq 0 ]; then
    echo "  ALL TESTS PASSED WITH 100% SUCCESS!"
    exit 0
else
    echo "  SOME TESTS FAILED!"
    exit 1
fi

