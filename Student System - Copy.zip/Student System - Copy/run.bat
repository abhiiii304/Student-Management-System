@echo off
title ATTENDX — Smart Student Attendance Management System
cd /d "%~dp0\Student System"
echo Starting AttendX Server...
python run_attendx.py %*
pause
